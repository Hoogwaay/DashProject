#!/usr/bin/env bash
set -e

API_PORT=${API_PORT:-3001}
FRONTEND_PORT=${FRONTEND_PORT:-5000}

cleanup() {
  if [[ -n "${API_PID:-}" ]] && kill -0 "$API_PID" 2>/dev/null; then
    kill "$API_PID" 2>/dev/null || true
  fi
  if [[ -n "${WEB_PID:-}" ]] && kill -0 "$WEB_PID" 2>/dev/null; then
    kill "$WEB_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

echo "[dev] Building API server..."
pnpm --filter @workspace/api-server run build

echo "[dev] Starting API server on port $API_PORT..."
PORT=$API_PORT NODE_ENV=development node --enable-source-maps artifacts/api-server/dist/index.mjs &
API_PID=$!

# Wait briefly for API to come up before launching the frontend dev server
for i in {1..30}; do
  if curl -sf "http://localhost:$API_PORT/api/healthz" >/dev/null 2>&1; then
    echo "[dev] API is healthy"
    break
  fi
  sleep 0.5
done

echo "[dev] Starting frontend on port $FRONTEND_PORT..."
PORT=$FRONTEND_PORT BASE_PATH=/ API_PROXY_TARGET="http://localhost:$API_PORT" \
  pnpm --filter @workspace/diary run dev &
WEB_PID=$!

wait -n "$API_PID" "$WEB_PID"
