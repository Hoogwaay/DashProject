#!/usr/bin/env bash
set -euo pipefail

export NODE_ENV=production
export PORT="${PORT:-5000}"
export STATIC_DIR="${STATIC_DIR:-$(pwd)/artifacts/diary/dist/public}"

echo "[start] Serving on port $PORT (static: $STATIC_DIR)"
exec node --enable-source-maps artifacts/api-server/dist/index.mjs
