#!/usr/bin/env bash
set -euo pipefail

echo "[build] Installing dependencies..."
pnpm install --frozen-lockfile

echo "[build] Building API server..."
pnpm --filter @workspace/api-server run build

echo "[build] Building frontend..."
PORT=5000 BASE_PATH=/ pnpm --filter @workspace/diary run build

echo "[build] Done"
