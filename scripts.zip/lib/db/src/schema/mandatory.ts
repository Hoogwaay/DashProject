import { pgTable, serial, text, integer, numeric, boolean, timestamp } from "drizzle-orm/pg-core";

export const mandatoryExpensesTable = pgTable("mandatory_expenses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  dueDay: integer("due_day").notNull(),
  category: text("category"),
  color: text("color"),
  icon: text("icon"),
  currency: text("currency").notNull().default("USD"),
  active: boolean("active").notNull().default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const mandatoryPaymentsTable = pgTable("mandatory_payments", {
  id: serial("id").primaryKey(),
  expenseId: integer("expense_id").notNull(),
  paidAt: timestamp("paid_at", { withTimezone: true }).notNull().defaultNow(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  notes: text("notes"),
});

export type MandatoryExpenseRow = typeof mandatoryExpensesTable.$inferSelect;
export type InsertMandatoryExpenseRow = typeof mandatoryExpensesTable.$inferInsert;
export type MandatoryPaymentRow = typeof mandatoryPaymentsTable.$inferSelect;
export type InsertMandatoryPaymentRow = typeof mandatoryPaymentsTable.$inferInsert;
