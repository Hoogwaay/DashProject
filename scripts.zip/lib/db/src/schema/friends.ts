import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const friendsTable = pgTable("friends", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull().default("friend"),
  email: text("email"),
  status: text("status").notNull().default("active"),
  color: text("color"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type FriendRow = typeof friendsTable.$inferSelect;
export type InsertFriendRow = typeof friendsTable.$inferInsert;
