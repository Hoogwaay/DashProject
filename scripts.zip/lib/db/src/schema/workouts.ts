import { pgTable, serial, text, integer, numeric, timestamp } from "drizzle-orm/pg-core";

export const workoutSessionsTable = pgTable("workout_sessions", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  name: text("name").notNull(),
  notes: text("notes"),
  durationMin: integer("duration_min"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workoutExercisesTable = pgTable("workout_exercises", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  name: text("name").notNull(),
  sets: integer("sets").notNull().default(3),
  reps: integer("reps").notNull().default(10),
  weightKg: numeric("weight_kg", { precision: 6, scale: 2 }),
  position: integer("position").notNull().default(0),
  notes: text("notes"),
});

export const workShiftsTable = pgTable("work_shifts", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id"),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  hourlyRate: numeric("hourly_rate", { precision: 14, scale: 2 }),
  fixedAmount: numeric("fixed_amount", { precision: 14, scale: 2 }),
  hours: numeric("hours", { precision: 6, scale: 2 }),
  earned: numeric("earned", { precision: 14, scale: 2 }),
  notes: text("notes"),
});

export type WorkoutSessionRow = typeof workoutSessionsTable.$inferSelect;
export type InsertWorkoutSessionRow = typeof workoutSessionsTable.$inferInsert;
export type WorkoutExerciseRow = typeof workoutExercisesTable.$inferSelect;
export type InsertWorkoutExerciseRow = typeof workoutExercisesTable.$inferInsert;
export type WorkShiftRow = typeof workShiftsTable.$inferSelect;
export type InsertWorkShiftRow = typeof workShiftsTable.$inferInsert;
