import { pgTable, serial, text, integer, numeric, timestamp } from "drizzle-orm/pg-core";

export const knowledgeNotesTable = pgTable("knowledge_notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull().default(""),
  color: text("color"),
  tags: text("tags"),
  x: numeric("x", { precision: 10, scale: 2 }),
  y: numeric("y", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const knowledgeLinksTable = pgTable("knowledge_links", {
  id: serial("id").primaryKey(),
  fromNoteId: integer("from_note_id").notNull(),
  toNoteId: integer("to_note_id").notNull(),
  label: text("label"),
});

export type KnowledgeNoteRow = typeof knowledgeNotesTable.$inferSelect;
export type InsertKnowledgeNoteRow = typeof knowledgeNotesTable.$inferInsert;
export type KnowledgeLinkRow = typeof knowledgeLinksTable.$inferSelect;
export type InsertKnowledgeLinkRow = typeof knowledgeLinksTable.$inferInsert;
