import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const boardsTable = pgTable("boards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  color: text("color"),
  ownerLabel: text("owner_label").notNull().default("me"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const boardColumnsTable = pgTable("board_columns", {
  id: serial("id").primaryKey(),
  boardId: integer("board_id").notNull(),
  name: text("name").notNull(),
  position: integer("position").notNull().default(0),
  color: text("color"),
});

export const boardCardsTable = pgTable("board_cards", {
  id: serial("id").primaryKey(),
  columnId: integer("column_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  position: integer("position").notNull().default(0),
  priority: text("priority").notNull().default("medium"),
  assigneeFriendId: integer("assignee_friend_id"),
  dueDate: timestamp("due_date", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const boardMembersTable = pgTable("board_members", {
  id: serial("id").primaryKey(),
  boardId: integer("board_id").notNull(),
  friendId: integer("friend_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type BoardRow = typeof boardsTable.$inferSelect;
export type InsertBoardRow = typeof boardsTable.$inferInsert;
export type BoardColumnRow = typeof boardColumnsTable.$inferSelect;
export type InsertBoardColumnRow = typeof boardColumnsTable.$inferInsert;
export type BoardCardRow = typeof boardCardsTable.$inferSelect;
export type InsertBoardCardRow = typeof boardCardsTable.$inferInsert;
export type BoardMemberRow = typeof boardMembersTable.$inferSelect;
