import { pgTable, serial, text, numeric, date, timestamp, integer } from "drizzle-orm/pg-core";

export const debtsTable = pgTable("debts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull(),
  originalAmount: numeric("original_amount", { precision: 14, scale: 2 }).notNull(),
  paidAmount: numeric("paid_amount", { precision: 14, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("USD"),
  lender: text("lender"),
  dueDate: date("due_date"),
  aprPct: numeric("apr_pct", { precision: 6, scale: 2 }),
  color: text("color"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const debtPaymentsTable = pgTable("debt_payments", {
  id: serial("id").primaryKey(),
  debtId: integer("debt_id").notNull(),
  paidAt: timestamp("paid_at", { withTimezone: true }).notNull().defaultNow(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  notes: text("notes"),
});

export type DebtRow = typeof debtsTable.$inferSelect;
export type InsertDebtRow = typeof debtsTable.$inferInsert;
export type DebtPaymentRow = typeof debtPaymentsTable.$inferSelect;
export type InsertDebtPaymentRow = typeof debtPaymentsTable.$inferInsert;
