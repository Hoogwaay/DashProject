import { Router, type IRouter } from "express";
import {
  db,
  boardsTable,
  boardColumnsTable,
  boardCardsTable,
  boardMembersTable,
  friendsTable,
} from "@workspace/db";
import {
  CreateBoardBody,
  UpdateBoardBody,
  CreateBoardColumnBody,
  CreateBoardCardBody,
  UpdateBoardCardBody,
  AddBoardMemberBody,
} from "@workspace/api-zod";
import { asc, desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function boardSummary(row: typeof boardsTable.$inferSelect, cardCount: number, memberCount: number) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    color: row.color,
    ownerLabel: row.ownerLabel,
    createdAt: row.createdAt.toISOString(),
    cardCount,
    memberCount,
  };
}

function cardOut(
  row: typeof boardCardsTable.$inferSelect,
  friend?: { name: string; color: string | null } | null,
) {
  return {
    id: row.id,
    columnId: row.columnId,
    title: row.title,
    description: row.description,
    position: row.position,
    priority: row.priority,
    assigneeFriendId: row.assigneeFriendId,
    assigneeName: friend?.name ?? null,
    assigneeColor: friend?.color ?? null,
    dueDate: row.dueDate ? row.dueDate.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
  };
}

async function lookupFriend(id: number | null) {
  if (!id) return null;
  const [f] = await db.select().from(friendsTable).where(eq(friendsTable.id, id));
  return f ? { name: f.name, color: f.color } : null;
}

async function loadBoardDetail(id: number) {
  const [board] = await db.select().from(boardsTable).where(eq(boardsTable.id, id));
  if (!board) return null;
  const columns = await db
    .select()
    .from(boardColumnsTable)
    .where(eq(boardColumnsTable.boardId, id))
    .orderBy(asc(boardColumnsTable.position));
  const colIds = columns.map((c) => c.id);
  const cards = colIds.length
    ? await db
        .select()
        .from(boardCardsTable)
        .orderBy(asc(boardCardsTable.position))
    : [];
  const allFriends = await db.select().from(friendsTable);
  const friendById = new Map(allFriends.map((f) => [f.id, f]));
  const cardsForCol = (cid: number) =>
    cards
      .filter((c) => c.columnId === cid)
      .map((c) => cardOut(c, c.assigneeFriendId ? friendById.get(c.assigneeFriendId) ?? null : null));
  const memberRows = await db
    .select({
      id: boardMembersTable.id,
      boardId: boardMembersTable.boardId,
      friendId: boardMembersTable.friendId,
      friendName: friendsTable.name,
      friendColor: friendsTable.color,
    })
    .from(boardMembersTable)
    .leftJoin(friendsTable, eq(friendsTable.id, boardMembersTable.friendId))
    .where(eq(boardMembersTable.boardId, id));
  return {
    id: board.id,
    name: board.name,
    description: board.description,
    color: board.color,
    ownerLabel: board.ownerLabel,
    createdAt: board.createdAt.toISOString(),
    columns: columns.map((c) => ({
      id: c.id,
      boardId: c.boardId,
      name: c.name,
      position: c.position,
      color: c.color,
      cards: cardsForCol(c.id),
    })),
    members: memberRows.map((m) => ({
      id: m.id,
      boardId: m.boardId,
      friendId: m.friendId,
      friendName: m.friendName ?? "Unknown",
      friendColor: m.friendColor ?? null,
    })),
  };
}

router.get("/boards", async (_req, res) => {
  const boards = await db.select().from(boardsTable).orderBy(desc(boardsTable.createdAt));
  const allCards = await db.select().from(boardCardsTable);
  const allCols = await db.select().from(boardColumnsTable);
  const allMembers = await db.select().from(boardMembersTable);
  res.json(
    boards.map((b) => {
      const colIds = allCols.filter((c) => c.boardId === b.id).map((c) => c.id);
      const cardCount = allCards.filter((c) => colIds.includes(c.columnId)).length;
      const memberCount = allMembers.filter((m) => m.boardId === b.id).length;
      return boardSummary(b, cardCount, memberCount);
    }),
  );
});

router.post("/boards", async (req, res) => {
  const body = CreateBoardBody.parse(req.body);
  const [board] = await db
    .insert(boardsTable)
    .values({
      name: body.name,
      description: body.description ?? null,
      color: body.color ?? null,
    })
    .returning();
  await db.insert(boardColumnsTable).values([
    { boardId: board.id, name: "Backlog", position: 0, color: "#9CA3AF" },
    { boardId: board.id, name: "In Progress", position: 1, color: "#A89BF5" },
    { boardId: board.id, name: "Done", position: 2, color: "#7CF0BD" },
  ]);
  const detail = await loadBoardDetail(board.id);
  res.status(201).json(detail);
});

router.get("/boards/:id", async (req, res) => {
  const id = Number(req.params.id);
  const detail = await loadBoardDetail(id);
  if (!detail) {
    res.status(404).json({ error: "Board not found" });
    return;
  }
  res.json(detail);
});

router.patch("/boards/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateBoardBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.name) updates.name = body.name;
  if (body.description !== undefined) updates.description = body.description;
  if (body.color !== undefined) updates.color = body.color;
  const [row] = await db.update(boardsTable).set(updates).where(eq(boardsTable.id, id)).returning();
  if (!row) {
    res.status(404).json({ error: "Board not found" });
    return;
  }
  res.json(boardSummary(row, 0, 0));
});

router.delete("/boards/:id", async (req, res) => {
  const id = Number(req.params.id);
  const cols = await db.select().from(boardColumnsTable).where(eq(boardColumnsTable.boardId, id));
  for (const c of cols) {
    await db.delete(boardCardsTable).where(eq(boardCardsTable.columnId, c.id));
  }
  await db.delete(boardColumnsTable).where(eq(boardColumnsTable.boardId, id));
  await db.delete(boardMembersTable).where(eq(boardMembersTable.boardId, id));
  await db.delete(boardsTable).where(eq(boardsTable.id, id));
  res.status(204).end();
});

router.post("/boards/:id/columns", async (req, res) => {
  const boardId = Number(req.params.id);
  const body = CreateBoardColumnBody.parse(req.body);
  const existing = await db
    .select()
    .from(boardColumnsTable)
    .where(eq(boardColumnsTable.boardId, boardId));
  const position = body.position ?? existing.length;
  const [row] = await db
    .insert(boardColumnsTable)
    .values({
      boardId,
      name: body.name,
      position,
      color: body.color ?? null,
    })
    .returning();
  res.status(201).json({ ...row, cards: [] });
});

router.delete("/boards/columns/:columnId", async (req, res) => {
  const columnId = Number(req.params.columnId);
  await db.delete(boardCardsTable).where(eq(boardCardsTable.columnId, columnId));
  await db.delete(boardColumnsTable).where(eq(boardColumnsTable.id, columnId));
  res.status(204).end();
});

router.post("/boards/:id/cards", async (req, res) => {
  const body = CreateBoardCardBody.parse(req.body);
  const existing = await db
    .select()
    .from(boardCardsTable)
    .where(eq(boardCardsTable.columnId, body.columnId));
  const position = existing.length;
  const [row] = await db
    .insert(boardCardsTable)
    .values({
      columnId: body.columnId,
      title: body.title,
      description: body.description ?? null,
      position,
      priority: body.priority ?? "medium",
      assigneeFriendId: body.assigneeFriendId ?? null,
      dueDate: body.dueDate ? new Date(body.dueDate as unknown as string) : null,
    })
    .returning();
  res.status(201).json(cardOut(row, await lookupFriend(row.assigneeFriendId)));
});

router.patch("/boards/cards/:cardId", async (req, res) => {
  const cardId = Number(req.params.cardId);
  const body = UpdateBoardCardBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.columnId !== undefined && body.columnId !== null) updates.columnId = body.columnId;
  if (body.title) updates.title = body.title;
  if (body.description !== undefined) updates.description = body.description;
  if (body.position !== undefined && body.position !== null) updates.position = body.position;
  if (body.priority !== undefined && body.priority !== null) updates.priority = body.priority;
  if (body.assigneeFriendId !== undefined) updates.assigneeFriendId = body.assigneeFriendId;
  if (body.dueDate !== undefined)
    updates.dueDate = body.dueDate ? new Date(body.dueDate as unknown as string) : null;
  const [row] = await db
    .update(boardCardsTable)
    .set(updates)
    .where(eq(boardCardsTable.id, cardId))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Card not found" });
    return;
  }
  res.json(cardOut(row, await lookupFriend(row.assigneeFriendId)));
});

router.delete("/boards/cards/:cardId", async (req, res) => {
  const cardId = Number(req.params.cardId);
  await db.delete(boardCardsTable).where(eq(boardCardsTable.id, cardId));
  res.status(204).end();
});

router.post("/boards/:id/members", async (req, res) => {
  const boardId = Number(req.params.id);
  const body = AddBoardMemberBody.parse(req.body);
  const [row] = await db
    .insert(boardMembersTable)
    .values({ boardId, friendId: body.friendId })
    .returning();
  const [friend] = await db.select().from(friendsTable).where(eq(friendsTable.id, body.friendId));
  res.status(201).json({
    id: row.id,
    boardId: row.boardId,
    friendId: row.friendId,
    friendName: friend?.name ?? "Unknown",
    friendColor: friend?.color ?? null,
  });
});

router.delete("/boards/members/:memberId", async (req, res) => {
  const id = Number(req.params.memberId);
  await db.delete(boardMembersTable).where(eq(boardMembersTable.id, id));
  res.status(204).end();
});

export default router;
