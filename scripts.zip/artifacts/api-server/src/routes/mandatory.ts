import { Router, type IRouter } from "express";
import {
  db,
  mandatoryExpensesTable,
  mandatoryPaymentsTable,
  transactionsTable,
} from "@workspace/db";
import {
  CreateMandatoryExpenseBody,
  UpdateMandatoryExpenseBody,
  PayMandatoryExpenseBody,
} from "@workspace/api-zod";
import { and, desc, eq, gte, lte } from "drizzle-orm";

const router: IRouter = Router();

function monthBounds(now: Date) {
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  return { start, end };
}

function nextDueDate(dueDay: number, now: Date) {
  const day = Math.min(Math.max(1, dueDay), 28);
  const candidate = new Date(now.getFullYear(), now.getMonth(), day);
  if (candidate < new Date(now.getFullYear(), now.getMonth(), now.getDate())) {
    return new Date(now.getFullYear(), now.getMonth() + 1, day);
  }
  return candidate;
}

async function serializeWithMonthState(row: typeof mandatoryExpensesTable.$inferSelect) {
  const now = new Date();
  const { start, end } = monthBounds(now);
  const payments = await db
    .select()
    .from(mandatoryPaymentsTable)
    .where(
      and(
        eq(mandatoryPaymentsTable.expenseId, row.id),
        gte(mandatoryPaymentsTable.paidAt, start),
        lte(mandatoryPaymentsTable.paidAt, end),
      ),
    );
  const paid = payments.reduce((s, p) => s + Number(p.amount), 0);
  const next = nextDueDate(row.dueDay, now);
  return {
    id: row.id,
    name: row.name,
    amount: Number(row.amount),
    dueDay: row.dueDay,
    category: row.category,
    color: row.color,
    icon: row.icon,
    currency: row.currency,
    active: row.active,
    notes: row.notes,
    paidThisMonth: paid,
    nextDueDate: next.toISOString().slice(0, 10),
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/mandatory", async (_req, res) => {
  const rows = await db
    .select()
    .from(mandatoryExpensesTable)
    .orderBy(desc(mandatoryExpensesTable.active), mandatoryExpensesTable.dueDay);
  const out = await Promise.all(rows.map((r) => serializeWithMonthState(r)));
  res.json(out);
});

router.post("/mandatory", async (req, res) => {
  const body = CreateMandatoryExpenseBody.parse(req.body);
  const [row] = await db
    .insert(mandatoryExpensesTable)
    .values({
      name: body.name,
      amount: String(body.amount),
      dueDay: body.dueDay,
      category: body.category ?? null,
      color: body.color ?? null,
      icon: body.icon ?? null,
      currency: body.currency ?? "USD",
      notes: body.notes ?? null,
    })
    .returning();
  res.status(201).json(await serializeWithMonthState(row));
});

router.patch("/mandatory/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateMandatoryExpenseBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.name) updates.name = body.name;
  if (body.amount !== undefined && body.amount !== null) updates.amount = String(body.amount);
  if (body.dueDay !== undefined && body.dueDay !== null) updates.dueDay = body.dueDay;
  if (body.category !== undefined) updates.category = body.category;
  if (body.color !== undefined) updates.color = body.color;
  if (body.icon !== undefined) updates.icon = body.icon;
  if (body.active !== undefined && body.active !== null) updates.active = body.active;
  if (body.notes !== undefined) updates.notes = body.notes;
  const [row] = await db
    .update(mandatoryExpensesTable)
    .set(updates)
    .where(eq(mandatoryExpensesTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Mandatory expense not found" });
    return;
  }
  res.json(await serializeWithMonthState(row));
});

router.delete("/mandatory/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(mandatoryPaymentsTable).where(eq(mandatoryPaymentsTable.expenseId, id));
  await db.delete(mandatoryExpensesTable).where(eq(mandatoryExpensesTable.id, id));
  res.status(204).end();
});

router.post("/mandatory/:id/pay", async (req, res) => {
  const id = Number(req.params.id);
  const body = req.body ? PayMandatoryExpenseBody.parse(req.body) : {};
  const [expense] = await db
    .select()
    .from(mandatoryExpensesTable)
    .where(eq(mandatoryExpensesTable.id, id));
  if (!expense) {
    res.status(404).json({ error: "Mandatory expense not found" });
    return;
  }
  const amount = body.amount ?? Number(expense.amount);
  const paidAt = body.paidAt ? new Date(body.paidAt as unknown as string) : new Date();
  const [payment] = await db
    .insert(mandatoryPaymentsTable)
    .values({
      expenseId: id,
      paidAt,
      amount: String(amount),
      notes: body.notes ?? null,
    })
    .returning();
  await db.insert(transactionsTable).values({
    type: "expense",
    amount: String(amount),
    category: expense.category ?? "Bills",
    description: expense.name,
    merchant: expense.name,
    occurredAt: paidAt,
  });
  res.status(201).json({
    id: payment.id,
    expenseId: payment.expenseId,
    paidAt: payment.paidAt.toISOString(),
    amount: Number(payment.amount),
  });
});

export default router;
