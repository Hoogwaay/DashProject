import { Router, type IRouter } from "express";
import { db, friendsTable } from "@workspace/db";
import { CreateFriendBody, UpdateFriendBody } from "@workspace/api-zod";
import { asc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof friendsTable.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    role: row.role,
    email: row.email,
    status: row.status,
    color: row.color,
    notes: row.notes,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/friends", async (_req, res) => {
  const rows = await db.select().from(friendsTable).orderBy(asc(friendsTable.name));
  res.json(rows.map(serialize));
});

router.post("/friends", async (req, res) => {
  const body = CreateFriendBody.parse(req.body);
  const [row] = await db
    .insert(friendsTable)
    .values({
      name: body.name,
      role: body.role ?? "friend",
      email: body.email ?? null,
      color: body.color ?? null,
      notes: body.notes ?? null,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.patch("/friends/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateFriendBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.name) updates.name = body.name;
  if (body.role !== undefined && body.role !== null) updates.role = body.role;
  if (body.email !== undefined) updates.email = body.email;
  if (body.status !== undefined && body.status !== null) updates.status = body.status;
  if (body.color !== undefined) updates.color = body.color;
  if (body.notes !== undefined) updates.notes = body.notes;
  const [row] = await db
    .update(friendsTable)
    .set(updates)
    .where(eq(friendsTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Friend not found" });
    return;
  }
  res.json(serialize(row));
});

router.delete("/friends/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(friendsTable).where(eq(friendsTable.id, id));
  res.status(204).end();
});

export default router;
