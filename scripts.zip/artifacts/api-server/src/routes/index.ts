import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import transactionsRouter from "./transactions";
import notesRouter from "./notes";
import investmentsRouter from "./investments";
import accountsRouter from "./accounts";
import forecastRouter from "./forecast";
import eventsRouter from "./events";
import bodyRouter from "./body";
import mandatoryRouter from "./mandatory";
import debtsRouter from "./debts";
import friendsRouter from "./friends";
import boardsRouter from "./boards";
import workoutsRouter from "./workouts";
import shiftsRouter from "./shifts";
import knowledgeRouter from "./knowledge";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(transactionsRouter);
router.use(notesRouter);
router.use(investmentsRouter);
router.use(accountsRouter);
router.use(forecastRouter);
router.use(eventsRouter);
router.use(bodyRouter);
router.use(mandatoryRouter);
router.use(debtsRouter);
router.use(friendsRouter);
router.use(boardsRouter);
router.use(workoutsRouter);
router.use(shiftsRouter);
router.use(knowledgeRouter);

export default router;
