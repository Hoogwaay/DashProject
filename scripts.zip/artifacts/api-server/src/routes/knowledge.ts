import { Router, type IRouter } from "express";
import { db, knowledgeNotesTable, knowledgeLinksTable } from "@workspace/db";
import {
  CreateKnowledgeNoteBody,
  UpdateKnowledgeNoteBody,
  CreateKnowledgeLinkBody,
} from "@workspace/api-zod";
import { desc, eq, or } from "drizzle-orm";

const router: IRouter = Router();

function noteOut(row: typeof knowledgeNotesTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    color: row.color,
    tags: row.tags,
    x: row.x ? Number(row.x) : null,
    y: row.y ? Number(row.y) : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function linkOut(row: typeof knowledgeLinksTable.$inferSelect) {
  return {
    id: row.id,
    fromNoteId: row.fromNoteId,
    toNoteId: row.toNoteId,
    label: row.label,
  };
}

router.get("/knowledge/notes", async (_req, res) => {
  const rows = await db
    .select()
    .from(knowledgeNotesTable)
    .orderBy(desc(knowledgeNotesTable.updatedAt));
  res.json(rows.map(noteOut));
});

router.post("/knowledge/notes", async (req, res) => {
  const body = CreateKnowledgeNoteBody.parse(req.body);
  const [row] = await db
    .insert(knowledgeNotesTable)
    .values({
      title: body.title,
      content: body.content ?? "",
      color: body.color ?? null,
      tags: body.tags ?? null,
      x: body.x !== undefined && body.x !== null ? String(body.x) : null,
      y: body.y !== undefined && body.y !== null ? String(body.y) : null,
    })
    .returning();
  res.status(201).json(noteOut(row));
});

router.patch("/knowledge/notes/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateKnowledgeNoteBody.parse(req.body);
  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (body.title) updates.title = body.title;
  if (body.content !== undefined && body.content !== null) updates.content = body.content;
  if (body.color !== undefined) updates.color = body.color;
  if (body.tags !== undefined) updates.tags = body.tags;
  if (body.x !== undefined) updates.x = body.x === null ? null : String(body.x);
  if (body.y !== undefined) updates.y = body.y === null ? null : String(body.y);
  const [row] = await db
    .update(knowledgeNotesTable)
    .set(updates)
    .where(eq(knowledgeNotesTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Knowledge note not found" });
    return;
  }
  res.json(noteOut(row));
});

router.delete("/knowledge/notes/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db
    .delete(knowledgeLinksTable)
    .where(or(eq(knowledgeLinksTable.fromNoteId, id), eq(knowledgeLinksTable.toNoteId, id)));
  await db.delete(knowledgeNotesTable).where(eq(knowledgeNotesTable.id, id));
  res.status(204).end();
});

router.post("/knowledge/links", async (req, res) => {
  const body = CreateKnowledgeLinkBody.parse(req.body);
  const [row] = await db
    .insert(knowledgeLinksTable)
    .values({
      fromNoteId: body.fromNoteId,
      toNoteId: body.toNoteId,
      label: body.label ?? null,
    })
    .returning();
  res.status(201).json(linkOut(row));
});

router.delete("/knowledge/links/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(knowledgeLinksTable).where(eq(knowledgeLinksTable.id, id));
  res.status(204).end();
});

router.get("/knowledge/graph", async (_req, res) => {
  const [notes, links] = await Promise.all([
    db.select().from(knowledgeNotesTable),
    db.select().from(knowledgeLinksTable),
  ]);
  res.json({ notes: notes.map(noteOut), links: links.map(linkOut) });
});

export default router;
