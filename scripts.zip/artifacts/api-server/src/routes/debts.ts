import { Router, type IRouter } from "express";
import { db, debtsTable } from "@workspace/db";
import { CreateDebtBody, UpdateDebtBody } from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof debtsTable.$inferSelect) {
  const original = Number(row.originalAmount);
  const paid = Number(row.paidAmount);
  return {
    id: row.id,
    name: row.name,
    kind: row.kind as "debt" | "credit",
    originalAmount: original,
    paidAmount: paid,
    remaining: Math.max(0, original - paid),
    currency: row.currency,
    lender: row.lender,
    dueDate: row.dueDate ?? null,
    aprPct: row.aprPct ? Number(row.aprPct) : null,
    color: row.color,
    notes: row.notes,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/debts", async (req, res) => {
  const kind = typeof req.query.kind === "string" ? req.query.kind : undefined;
  const rows = await db
    .select()
    .from(debtsTable)
    .where(kind ? eq(debtsTable.kind, kind) : undefined)
    .orderBy(desc(debtsTable.createdAt));
  res.json(rows.map(serialize));
});

router.post("/debts", async (req, res) => {
  const body = CreateDebtBody.parse(req.body);
  const [row] = await db
    .insert(debtsTable)
    .values({
      name: body.name,
      kind: body.kind,
      originalAmount: String(body.originalAmount),
      paidAmount: String(body.paidAmount ?? 0),
      currency: body.currency ?? "USD",
      lender: body.lender ?? null,
      dueDate: body.dueDate ? String(body.dueDate).slice(0, 10) : null,
      aprPct: body.aprPct !== undefined && body.aprPct !== null ? String(body.aprPct) : null,
      color: body.color ?? null,
      notes: body.notes ?? null,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.patch("/debts/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateDebtBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.name) updates.name = body.name;
  if (body.paidAmount !== undefined && body.paidAmount !== null) updates.paidAmount = String(body.paidAmount);
  if (body.dueDate !== undefined) updates.dueDate = body.dueDate ? String(body.dueDate).slice(0, 10) : null;
  if (body.aprPct !== undefined) updates.aprPct = body.aprPct === null ? null : String(body.aprPct);
  if (body.color !== undefined) updates.color = body.color;
  if (body.notes !== undefined) updates.notes = body.notes;
  const [row] = await db.update(debtsTable).set(updates).where(eq(debtsTable.id, id)).returning();
  if (!row) {
    res.status(404).json({ error: "Debt not found" });
    return;
  }
  res.json(serialize(row));
});

router.delete("/debts/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(debtsTable).where(eq(debtsTable.id, id));
  res.status(204).end();
});

export default router;
