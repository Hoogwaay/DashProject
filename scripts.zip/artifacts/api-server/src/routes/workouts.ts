import { Router, type IRouter } from "express";
import {
  db,
  workoutSessionsTable,
  workoutExercisesTable,
  eventsTable,
} from "@workspace/db";
import {
  CreateWorkoutBody,
  UpdateWorkoutBody,
  CreateExerciseBody,
} from "@workspace/api-zod";
import { and, asc, desc, eq, gte, lte } from "drizzle-orm";

const router: IRouter = Router();

function exOut(row: typeof workoutExercisesTable.$inferSelect) {
  return {
    id: row.id,
    sessionId: row.sessionId,
    name: row.name,
    sets: row.sets,
    reps: row.reps,
    weightKg: row.weightKg ? Number(row.weightKg) : null,
    position: row.position,
    notes: row.notes,
  };
}

async function sessionOut(row: typeof workoutSessionsTable.$inferSelect) {
  const exercises = await db
    .select()
    .from(workoutExercisesTable)
    .where(eq(workoutExercisesTable.sessionId, row.id))
    .orderBy(asc(workoutExercisesTable.position));
  return {
    id: row.id,
    eventId: row.eventId,
    scheduledAt: row.scheduledAt.toISOString(),
    name: row.name,
    notes: row.notes,
    durationMin: row.durationMin,
    createdAt: row.createdAt.toISOString(),
    exercises: exercises.map(exOut),
  };
}

router.get("/workouts", async (req, res) => {
  const fromRaw = typeof req.query.from === "string" ? req.query.from : undefined;
  const toRaw = typeof req.query.to === "string" ? req.query.to : undefined;
  const where = [];
  if (fromRaw) where.push(gte(workoutSessionsTable.scheduledAt, new Date(fromRaw)));
  if (toRaw) where.push(lte(workoutSessionsTable.scheduledAt, new Date(toRaw + "T23:59:59")));
  const rows = await db
    .select()
    .from(workoutSessionsTable)
    .where(where.length ? and(...where) : undefined)
    .orderBy(desc(workoutSessionsTable.scheduledAt));
  const out = await Promise.all(rows.map(sessionOut));
  res.json(out);
});

router.post("/workouts", async (req, res) => {
  const body = CreateWorkoutBody.parse(req.body);
  const scheduledAt = new Date(body.scheduledAt as unknown as string);
  const [event] = await db
    .insert(eventsTable)
    .values({
      title: body.name,
      kind: "workout",
      scheduledAt,
      durationMin: body.durationMin ?? null,
      notes: body.notes ?? null,
      color: "#7CF0BD",
    })
    .returning();
  const [row] = await db
    .insert(workoutSessionsTable)
    .values({
      eventId: event.id,
      scheduledAt,
      name: body.name,
      notes: body.notes ?? null,
      durationMin: body.durationMin ?? null,
    })
    .returning();
  res.status(201).json(await sessionOut(row));
});

router.patch("/workouts/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateWorkoutBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.scheduledAt !== undefined && body.scheduledAt !== null)
    updates.scheduledAt = new Date(body.scheduledAt as unknown as string);
  if (body.name) updates.name = body.name;
  if (body.notes !== undefined) updates.notes = body.notes;
  if (body.durationMin !== undefined) updates.durationMin = body.durationMin;
  const [row] = await db
    .update(workoutSessionsTable)
    .set(updates)
    .where(eq(workoutSessionsTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Workout not found" });
    return;
  }
  if (row.eventId) {
    const evUpdates: Record<string, unknown> = {};
    if (updates.scheduledAt) evUpdates.scheduledAt = updates.scheduledAt;
    if (updates.name) evUpdates.title = updates.name;
    if (Object.keys(evUpdates).length) {
      await db.update(eventsTable).set(evUpdates).where(eq(eventsTable.id, row.eventId));
    }
  }
  res.json(await sessionOut(row));
});

router.delete("/workouts/:id", async (req, res) => {
  const id = Number(req.params.id);
  const [row] = await db.select().from(workoutSessionsTable).where(eq(workoutSessionsTable.id, id));
  if (row?.eventId) {
    await db.delete(eventsTable).where(eq(eventsTable.id, row.eventId));
  }
  await db.delete(workoutExercisesTable).where(eq(workoutExercisesTable.sessionId, id));
  await db.delete(workoutSessionsTable).where(eq(workoutSessionsTable.id, id));
  res.status(204).end();
});

router.post("/workouts/exercises", async (req, res) => {
  const body = CreateExerciseBody.parse(req.body);
  const existing = await db
    .select()
    .from(workoutExercisesTable)
    .where(eq(workoutExercisesTable.sessionId, body.sessionId));
  const position = existing.length;
  const [row] = await db
    .insert(workoutExercisesTable)
    .values({
      sessionId: body.sessionId,
      name: body.name,
      sets: body.sets ?? 3,
      reps: body.reps ?? 10,
      weightKg: body.weightKg !== undefined && body.weightKg !== null ? String(body.weightKg) : null,
      position,
      notes: body.notes ?? null,
    })
    .returning();
  res.status(201).json(exOut(row));
});

router.delete("/workouts/exercises/:exerciseId", async (req, res) => {
  const id = Number(req.params.exerciseId);
  await db.delete(workoutExercisesTable).where(eq(workoutExercisesTable.id, id));
  res.status(204).end();
});

export default router;
