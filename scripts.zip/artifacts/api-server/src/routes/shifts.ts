import { Router, type IRouter } from "express";
import {
  db,
  workShiftsTable,
  eventsTable,
  transactionsTable,
} from "@workspace/db";
import { CreateShiftBody, UpdateShiftBody } from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function computeEarnings(input: {
  startedAt: Date;
  endedAt: Date | null;
  hourlyRate: number | null;
  fixedAmount: number | null;
  hours: number | null;
}) {
  if (input.fixedAmount !== null && input.fixedAmount !== undefined) {
    return { hours: input.hours, earned: input.fixedAmount };
  }
  let hours = input.hours;
  if (hours === null || hours === undefined) {
    if (input.endedAt) {
      hours = (input.endedAt.getTime() - input.startedAt.getTime()) / 3600000;
    }
  }
  const earned = hours !== null && hours !== undefined && input.hourlyRate
    ? Math.round(hours * input.hourlyRate * 100) / 100
    : null;
  return { hours, earned };
}

function serialize(row: typeof workShiftsTable.$inferSelect) {
  return {
    id: row.id,
    eventId: row.eventId,
    startedAt: row.startedAt.toISOString(),
    endedAt: row.endedAt ? row.endedAt.toISOString() : null,
    hourlyRate: row.hourlyRate ? Number(row.hourlyRate) : null,
    fixedAmount: row.fixedAmount ? Number(row.fixedAmount) : null,
    hours: row.hours ? Number(row.hours) : null,
    earned: row.earned ? Number(row.earned) : null,
    notes: row.notes,
  };
}

router.get("/shifts", async (_req, res) => {
  const rows = await db.select().from(workShiftsTable).orderBy(desc(workShiftsTable.startedAt));
  res.json(rows.map(serialize));
});

router.post("/shifts", async (req, res) => {
  const body = CreateShiftBody.parse(req.body);
  const startedAt = new Date(body.startedAt as unknown as string);
  const endedAt = body.endedAt ? new Date(body.endedAt as unknown as string) : null;
  const calc = computeEarnings({
    startedAt,
    endedAt,
    hourlyRate: body.hourlyRate ?? null,
    fixedAmount: body.fixedAmount ?? null,
    hours: body.hours ?? null,
  });
  const [event] = await db
    .insert(eventsTable)
    .values({
      title: `Work shift${calc.earned ? ` ($${calc.earned})` : ""}`,
      kind: "task",
      scheduledAt: startedAt,
      durationMin: calc.hours ? Math.round(calc.hours * 60) : null,
      notes: body.notes ?? null,
      color: "#5EC9F2",
    })
    .returning();
  const [row] = await db
    .insert(workShiftsTable)
    .values({
      eventId: event.id,
      startedAt,
      endedAt,
      hourlyRate:
        body.hourlyRate !== undefined && body.hourlyRate !== null ? String(body.hourlyRate) : null,
      fixedAmount:
        body.fixedAmount !== undefined && body.fixedAmount !== null
          ? String(body.fixedAmount)
          : null,
      hours: calc.hours !== null && calc.hours !== undefined ? String(calc.hours) : null,
      earned: calc.earned !== null && calc.earned !== undefined ? String(calc.earned) : null,
      notes: body.notes ?? null,
    })
    .returning();
  if (calc.earned && calc.earned > 0) {
    await db.insert(transactionsTable).values({
      type: "income",
      amount: String(calc.earned),
      category: "Salary",
      description: "Work shift",
      merchant: "Work",
      occurredAt: endedAt ?? startedAt,
    });
  }
  res.status(201).json(serialize(row));
});

router.patch("/shifts/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateShiftBody.parse(req.body);
  const [existing] = await db.select().from(workShiftsTable).where(eq(workShiftsTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Shift not found" });
    return;
  }
  const startedAt = body.startedAt ? new Date(body.startedAt as unknown as string) : existing.startedAt;
  const endedAt = body.endedAt !== undefined
    ? body.endedAt ? new Date(body.endedAt as unknown as string) : null
    : existing.endedAt;
  const hourlyRate = body.hourlyRate !== undefined ? body.hourlyRate : existing.hourlyRate ? Number(existing.hourlyRate) : null;
  const fixedAmount = body.fixedAmount !== undefined ? body.fixedAmount : existing.fixedAmount ? Number(existing.fixedAmount) : null;
  const calc = computeEarnings({
    startedAt,
    endedAt,
    hourlyRate: hourlyRate ?? null,
    fixedAmount: fixedAmount ?? null,
    hours: body.hours ?? (existing.hours ? Number(existing.hours) : null),
  });
  const [row] = await db
    .update(workShiftsTable)
    .set({
      startedAt,
      endedAt,
      hourlyRate: hourlyRate !== null && hourlyRate !== undefined ? String(hourlyRate) : null,
      fixedAmount: fixedAmount !== null && fixedAmount !== undefined ? String(fixedAmount) : null,
      hours: calc.hours !== null && calc.hours !== undefined ? String(calc.hours) : null,
      earned: calc.earned !== null && calc.earned !== undefined ? String(calc.earned) : null,
      notes: body.notes !== undefined ? body.notes : existing.notes,
    })
    .where(eq(workShiftsTable.id, id))
    .returning();
  res.json(serialize(row));
});

router.delete("/shifts/:id", async (req, res) => {
  const id = Number(req.params.id);
  const [row] = await db.select().from(workShiftsTable).where(eq(workShiftsTable.id, id));
  if (row?.eventId) {
    await db.delete(eventsTable).where(eq(eventsTable.id, row.eventId));
  }
  await db.delete(workShiftsTable).where(eq(workShiftsTable.id, id));
  res.status(204).end();
});

export default router;
