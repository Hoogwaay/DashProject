import { useState } from "react";
import { Layout } from "@/components/layout";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListWorkouts,
  useCreateWorkout,
  useDeleteWorkout,
  useCreateExercise,
  useDeleteExercise,
  useGetBodySummary,
  getListWorkoutsQueryKey,
  getListEventsQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Plus,
  Trash2,
  Dumbbell,
  Calendar,
  Activity,
  ChevronRight,
} from "lucide-react";

export default function Workouts() {
  const queryClient = useQueryClient();
  const { data: workouts } = useListWorkouts();
  const { data: bodySummary } = useGetBodySummary();
  const create = useCreateWorkout();
  const remove = useDeleteWorkout();
  const addExercise = useCreateExercise();
  const removeExercise = useDeleteExercise();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [scheduledAt, setScheduledAt] = useState(() => {
    const d = new Date();
    d.setMinutes(0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [duration, setDuration] = useState("60");
  const [notes, setNotes] = useState("");
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getListWorkoutsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
  };

  const handleCreate = () => {
    if (!name) return;
    create.mutate(
      {
        data: {
          name,
          scheduledAt: new Date(scheduledAt).toISOString() as any,
          durationMin: Number(duration),
          notes: notes || null,
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          setName("");
          setNotes("");
        },
      },
    );
  };

  return (
    <Layout>
      <div className="flex items-end justify-between mb-6 mt-2">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Workouts</h1>
          <p className="text-sm text-muted-foreground mt-2">
            Sessions sync to your calendar. Track exercises and watch your body metrics evolve.
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="lg">
              <Plus className="w-4 h-4 mr-2" /> New workout
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>Schedule a workout</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder="Workout name (e.g. Push day)" value={name} onChange={(e) => setName(e.target.value)} />
              <Input type="datetime-local" value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} />
              <Input
                placeholder="Duration (minutes)"
                type="number"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
              />
              <Textarea placeholder="Notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={create.isPending}>
                {create.isPending ? "Saving…" : "Save"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-3">
          {(workouts ?? []).map((w) => {
            const expanded = expandedId === w.id;
            const isPast = new Date(w.scheduledAt) < new Date();
            return (
              <div
                key={w.id}
                className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <button
                    onClick={() => setExpandedId(expanded ? null : w.id)}
                    className="flex items-center gap-3 text-left flex-1 min-w-0"
                  >
                    <div
                      className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0"
                      style={{ background: "rgba(124,240,189,0.14)", color: "#7CF0BD" }}
                    >
                      <Dumbbell className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold truncate">{w.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {new Date(w.scheduledAt).toLocaleString("en-US", {
                          weekday: "short",
                          month: "short",
                          day: "numeric",
                          hour: "numeric",
                          minute: "2-digit",
                        })}
                        {w.durationMin && ` • ${w.durationMin}min`}
                        {" • "}
                        {w.exercises.length} exercises
                      </p>
                    </div>
                    <ChevronRight
                      className={`w-4 h-4 text-muted-foreground transition-transform ml-auto ${expanded ? "rotate-90" : ""}`}
                    />
                  </button>
                  <button
                    onClick={() => remove.mutate({ id: w.id }, { onSuccess: refetch })}
                    className="text-muted-foreground hover:text-destructive p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                {expanded && (
                  <div className="mt-4 pt-4 border-t border-white/[0.06] space-y-2">
                    {w.exercises.map((ex) => (
                      <div key={ex.id} className="flex items-center gap-3 p-2 rounded-xl bg-white/[0.02]">
                        <div className="flex-1">
                          <p className="text-sm font-medium">{ex.name}</p>
                          <p className="text-[11px] text-muted-foreground">
                            {ex.sets} × {ex.reps}
                            {ex.weightKg && ` @ ${ex.weightKg} kg`}
                          </p>
                        </div>
                        <button
                          onClick={() => removeExercise.mutate({ exerciseId: ex.id }, { onSuccess: refetch })}
                          className="text-muted-foreground hover:text-destructive p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                    {w.exercises.length === 0 && (
                      <p className="text-xs text-muted-foreground text-center py-2">
                        No exercises yet
                      </p>
                    )}
                    <ExerciseForm
                      onAdd={(name, sets, reps, weight) =>
                        addExercise.mutate(
                          {
                            data: {
                              sessionId: w.id,
                              name,
                              sets: Number(sets),
                              reps: Number(reps),
                              weightKg: weight ? Number(weight) : null,
                            },
                          },
                          { onSuccess: refetch },
                        )
                      }
                    />
                  </div>
                )}
              </div>
            );
          })}
          {(workouts ?? []).length === 0 && (
            <div className="text-center py-12 text-muted-foreground text-sm">
              No workouts scheduled yet.
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5">
            <div className="flex items-center gap-2 mb-3">
              <Activity className="w-4 h-4" style={{ color: "#7CF0BD" }} />
              <h3 className="font-semibold tracking-tight">Body metrics</h3>
            </div>
            {bodySummary?.latest ? (
              <div className="space-y-2">
                <Stat label="Weight" value={bodySummary.latest.weightKg} unit="kg" delta={bodySummary.weightDelta30 ?? undefined} />
                <Stat label="Body fat" value={bodySummary.latest.bodyFatPct} unit="%" delta={bodySummary.bodyFatDelta30 ?? undefined} />
                <Stat label="Muscle" value={bodySummary.latest.musclePct} unit="%" />
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">No measurements yet.</p>
            )}
            <Link
              href="/body"
              className="mt-4 flex items-center justify-center gap-1 text-xs text-muted-foreground hover:text-foreground py-2 rounded-lg hover:bg-white/[0.04]"
            >
              View body diary <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-4 h-4" style={{ color: "#A89BF5" }} />
              <h3 className="font-semibold tracking-tight">Calendar</h3>
            </div>
            <p className="text-xs text-muted-foreground">
              Each workout you create here automatically appears as a calendar event.
            </p>
            <Link
              href="/calendar"
              className="mt-4 flex items-center justify-center gap-1 text-xs text-muted-foreground hover:text-foreground py-2 rounded-lg hover:bg-white/[0.04]"
            >
              Open calendar <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function Stat({
  label,
  value,
  unit,
  delta,
}: {
  label: string;
  value: number | null | undefined;
  unit: string;
  delta?: number;
}) {
  if (value === null || value === undefined) return null;
  return (
    <div className="flex items-baseline justify-between">
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="flex items-baseline gap-2">
        <span className="text-lg font-bold tabular-nums">
          {value}
          <span className="text-xs text-muted-foreground ml-1">{unit}</span>
        </span>
        {delta !== undefined && (
          <span
            className={`text-[10px] font-semibold tabular-nums ${
              delta < 0 ? "text-primary" : delta > 0 ? "text-destructive" : "text-muted-foreground"
            }`}
          >
            {delta > 0 ? "+" : ""}
            {delta.toFixed(1)}
          </span>
        )}
      </div>
    </div>
  );
}

function ExerciseForm({
  onAdd,
}: {
  onAdd: (name: string, sets: string, reps: string, weight: string) => void;
}) {
  const [name, setName] = useState("");
  const [sets, setSets] = useState("3");
  const [reps, setReps] = useState("10");
  const [weight, setWeight] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!name) return;
        onAdd(name, sets, reps, weight);
        setName("");
        setWeight("");
      }}
      className="flex flex-wrap gap-2 pt-2"
    >
      <Input
        placeholder="Exercise name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="flex-1 min-w-[160px] h-9"
      />
      <Input
        placeholder="Sets"
        type="number"
        value={sets}
        onChange={(e) => setSets(e.target.value)}
        className="w-16 h-9"
      />
      <Input
        placeholder="Reps"
        type="number"
        value={reps}
        onChange={(e) => setReps(e.target.value)}
        className="w-16 h-9"
      />
      <Input
        placeholder="kg"
        type="number"
        value={weight}
        onChange={(e) => setWeight(e.target.value)}
        className="w-20 h-9"
      />
      <Button type="submit" size="sm" disabled={!name}>
        Add
      </Button>
    </form>
  );
}
