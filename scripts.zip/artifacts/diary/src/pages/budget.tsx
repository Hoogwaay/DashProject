import { useState } from "react";
import { Layout } from "@/components/layout";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListMandatoryExpenses,
  useCreateMandatoryExpense,
  useDeleteMandatoryExpense,
  usePayMandatoryExpense,
  useListDebts,
  useCreateDebt,
  useUpdateDebt,
  useDeleteDebt,
  useListAccounts,
  getListMandatoryExpensesQueryKey,
  getListDebtsQueryKey,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { formatCurrency } from "@/lib/utils";
import {
  Plus,
  Trash2,
  Wallet,
  AlertCircle,
  Check,
  ArrowDownRight,
  ArrowUpRight,
  CalendarDays,
  ChevronRight,
} from "lucide-react";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

type Tab = "overview" | "accounts" | "mandatory" | "debts";

export default function Budget() {
  const [tab, setTab] = useState<Tab>("overview");

  return (
    <Layout>
      <div className="flex flex-col gap-2 mb-6 mt-2">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Budget</h1>
        <p className="text-sm text-muted-foreground">
          Accounts, mandatory monthly bills, and debts in one place.
        </p>
      </div>

      <div className="flex flex-wrap gap-2 mb-6 border-b border-white/[0.06] pb-1">
        {(["overview", "accounts", "mandatory", "debts"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium rounded-full transition-all ${
              tab === t
                ? "bg-white text-[#0a1f17]"
                : "text-muted-foreground hover:text-foreground hover:bg-white/[0.04]"
            }`}
          >
            {t === "overview"
              ? "Overview"
              : t === "accounts"
                ? "Accounts"
                : t === "mandatory"
                  ? "Mandatory expenses"
                  : "Debts & credits"}
          </button>
        ))}
      </div>

      {tab === "overview" && <OverviewTab />}
      {tab === "accounts" && <AccountsTab />}
      {tab === "mandatory" && <MandatoryTab />}
      {tab === "debts" && <DebtsTab />}
    </Layout>
  );
}

function OverviewTab() {
  const { data: accounts } = useListAccounts();
  const { data: mandatory } = useListMandatoryExpenses();
  const { data: debts } = useListDebts();

  const totalBalance = (accounts ?? []).reduce((s, a) => s + a.balance, 0);
  const mandatoryRemaining = (mandatory ?? []).reduce(
    (s, m) => s + Math.max(0, m.amount - m.paidThisMonth),
    0,
  );
  const debtTotal = (debts ?? [])
    .filter((d) => d.kind === "debt")
    .reduce((s, d) => s + d.remaining, 0);
  const creditTotal = (debts ?? [])
    .filter((d) => d.kind === "credit")
    .reduce((s, d) => s + d.remaining, 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <SummaryTile
        icon={<Wallet className="w-4 h-4" />}
        label="Total balance"
        value={totalBalance}
        color={MINT}
        href="#accounts"
      />
      <SummaryTile
        icon={<AlertCircle className="w-4 h-4" />}
        label="Mandatory left this month"
        value={mandatoryRemaining}
        color="#F2C879"
      />
      <SummaryTile
        icon={<ArrowDownRight className="w-4 h-4" />}
        label="You owe"
        value={debtTotal}
        color="#F291C8"
      />
      <SummaryTile
        icon={<ArrowUpRight className="w-4 h-4" />}
        label="You're owed"
        value={creditTotal}
        color={LAVENDER}
      />

      <div className="md:col-span-2 lg:col-span-4 rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6 mt-2">
        <h3 className="font-semibold text-lg mb-4">Upcoming bills</h3>
        <div className="space-y-3">
          {(mandatory ?? [])
            .filter((m) => m.active && m.amount > m.paidThisMonth)
            .slice(0, 6)
            .map((m) => (
              <div
                key={m.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.02] border border-white/[0.05]"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: (m.color ?? "#F2C879") + "26", color: m.color ?? "#F2C879" }}
                  >
                    <CalendarDays className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{m.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Due {new Date(m.nextDueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </p>
                  </div>
                </div>
                <p className="text-lg font-bold tabular-nums">
                  {formatCurrency(Math.max(0, m.amount - m.paidThisMonth), m.currency)}
                </p>
              </div>
            ))}
          {(mandatory ?? []).filter((m) => m.active && m.amount > m.paidThisMonth).length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-6">
              No mandatory bills due this month. 🎉
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function SummaryTile({
  icon,
  label,
  value,
  color,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
  href?: string;
}) {
  const Tag: any = href ? Link : "div";
  return (
    <Tag
      {...(href ? { href } : {})}
      className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 backdrop-blur-sm hover:bg-white/[0.05] hover:border-white/[0.1] transition-all"
    >
      <div className="flex items-center gap-2 mb-3">
        <div
          className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: color + "22", color }}
        >
          {icon}
        </div>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
      <p className="text-2xl font-bold tabular-nums">{formatCurrency(value)}</p>
    </Tag>
  );
}

function AccountsTab() {
  const { data: accounts } = useListAccounts();
  return (
    <div>
      <p className="text-sm text-muted-foreground mb-4">
        Manage all your bank accounts and cards on the Accounts page.
      </p>
      <Link
        href="/accounts"
        className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-primary text-[#0a1f17] font-semibold hover:brightness-110 transition-all"
      >
        Open Accounts <ChevronRight className="w-4 h-4" />
      </Link>
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(accounts ?? []).map((a) => (
          <div
            key={a.id}
            className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5"
          >
            <p className="text-xs text-muted-foreground uppercase tracking-wider">
              {a.name}
            </p>
            <p className="text-2xl font-bold tabular-nums mt-1">
              {formatCurrency(a.balance, a.currency)}
            </p>
            <p className="text-[11px] text-muted-foreground mt-1">{a.kind}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function MandatoryTab() {
  const queryClient = useQueryClient();
  const { data: items } = useListMandatoryExpenses();
  const create = useCreateMandatoryExpense();
  const remove = useDeleteMandatoryExpense();
  const pay = usePayMandatoryExpense();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDay, setDueDay] = useState("1");
  const [category, setCategory] = useState("Bills");

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getListMandatoryExpensesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const handleCreate = () => {
    if (!name || !amount) return;
    create.mutate(
      {
        data: {
          name,
          amount: Number(amount),
          dueDay: Number(dueDay),
          category,
          color: "#F2C879",
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          setName("");
          setAmount("");
          setDueDay("1");
          setCategory("Bills");
        },
      },
    );
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">
          Recurring monthly bills (rent, subscriptions, utilities…). Mark them paid each month and
          they'll log a transaction.
        </p>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> New bill
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>Add a mandatory bill</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder="Bill name (e.g. Rent)" value={name} onChange={(e) => setName(e.target.value)} />
              <Input
                placeholder="Amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <Input
                placeholder="Day of month (1-28)"
                type="number"
                min={1}
                max={28}
                value={dueDay}
                onChange={(e) => setDueDay(e.target.value)}
              />
              <Input placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={create.isPending}>
                {create.isPending ? "Saving…" : "Save"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(items ?? []).map((m) => {
          const remaining = Math.max(0, m.amount - m.paidThisMonth);
          const fullyPaid = remaining === 0 && m.amount > 0;
          return (
            <div
              key={m.id}
              className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{
                      background: (m.color ?? "#F2C879") + "26",
                      color: m.color ?? "#F2C879",
                    }}
                  >
                    <CalendarDays className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-semibold">{m.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      Day {m.dueDay} • {m.category ?? "Bills"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => remove.mutate({ id: m.id }, { onSuccess: refetch })}
                  className="text-muted-foreground hover:text-destructive p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-baseline justify-between mb-3">
                <p className="text-2xl font-bold tabular-nums">
                  {formatCurrency(m.amount, m.currency)}
                </p>
                <p className={`text-xs font-semibold ${fullyPaid ? "text-primary" : "text-muted-foreground"}`}>
                  {fullyPaid ? "Paid this month" : `${formatCurrency(remaining, m.currency)} due`}
                </p>
              </div>
              <button
                onClick={() => pay.mutate({ id: m.id, data: {} }, { onSuccess: refetch })}
                disabled={fullyPaid || pay.isPending}
                className={`w-full py-2 rounded-2xl text-sm font-semibold transition-all ${
                  fullyPaid
                    ? "bg-primary/20 text-primary cursor-default"
                    : "bg-primary text-[#0a1f17] hover:brightness-110"
                }`}
              >
                {fullyPaid ? (
                  <span className="inline-flex items-center gap-2">
                    <Check className="w-4 h-4" /> Paid
                  </span>
                ) : (
                  "Mark as paid"
                )}
              </button>
            </div>
          );
        })}
        {(items ?? []).length === 0 && (
          <div className="md:col-span-2 text-center py-12 text-muted-foreground text-sm">
            No mandatory bills yet — add your rent, subscriptions, utilities…
          </div>
        )}
      </div>
    </div>
  );
}

function DebtsTab() {
  const queryClient = useQueryClient();
  const { data: items } = useListDebts();
  const create = useCreateDebt();
  const update = useUpdateDebt();
  const remove = useDeleteDebt();

  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<"debt" | "credit">("debt");
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [lender, setLender] = useState("");
  const [notes, setNotes] = useState("");

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getListDebtsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const handleCreate = () => {
    if (!name || !amount) return;
    create.mutate(
      {
        data: {
          name,
          kind,
          originalAmount: Number(amount),
          lender: lender || null,
          notes: notes || null,
          color: kind === "debt" ? "#F291C8" : LAVENDER,
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          setName("");
          setAmount("");
          setLender("");
          setNotes("");
        },
      },
    );
  };

  const handleAddPayment = (debtId: number, currentPaid: number, amount: string) => {
    const v = Number(amount);
    if (!v) return;
    update.mutate(
      { id: debtId, data: { paidAmount: currentPaid + v } },
      { onSuccess: refetch },
    );
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">
          Track money you owe (debts) and money owed to you (credits).
        </p>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> New entry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>Add debt or credit</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <div className="flex gap-2">
                <button
                  onClick={() => setKind("debt")}
                  className={`flex-1 py-2 rounded-2xl text-sm font-semibold ${
                    kind === "debt" ? "bg-[#F291C8] text-[#0a1f17]" : "bg-white/[0.04]"
                  }`}
                >
                  I owe (debt)
                </button>
                <button
                  onClick={() => setKind("credit")}
                  className={`flex-1 py-2 rounded-2xl text-sm font-semibold ${
                    kind === "credit" ? "bg-secondary text-[#0a1f17]" : "bg-white/[0.04]"
                  }`}
                >
                  Owed to me (credit)
                </button>
              </div>
              <Input placeholder="Description" value={name} onChange={(e) => setName(e.target.value)} />
              <Input
                placeholder="Amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <Input placeholder="Counterparty (optional)" value={lender} onChange={(e) => setLender(e.target.value)} />
              <Textarea placeholder="Notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={create.isPending}>
                {create.isPending ? "Saving…" : "Save"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(items ?? []).map((d) => {
          const pct = d.originalAmount > 0
            ? Math.min(100, (d.paidAmount / d.originalAmount) * 100)
            : 0;
          const isDebt = d.kind === "debt";
          return (
            <div
              key={d.id}
              className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <span
                    className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full"
                    style={{
                      background: isDebt ? "rgba(242,145,200,0.18)" : "rgba(168,155,245,0.18)",
                      color: isDebt ? "#F291C8" : LAVENDER,
                    }}
                  >
                    {isDebt ? "I owe" : "Owed to me"}
                  </span>
                  <p className="font-semibold mt-2">{d.name}</p>
                  {d.lender && <p className="text-[11px] text-muted-foreground">{d.lender}</p>}
                </div>
                <button
                  onClick={() => remove.mutate({ id: d.id }, { onSuccess: refetch })}
                  className="text-muted-foreground hover:text-destructive p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <p className="text-2xl font-bold tabular-nums">
                {formatCurrency(d.remaining, d.currency)}
              </p>
              <p className="text-[11px] text-muted-foreground tabular-nums">
                {formatCurrency(d.paidAmount, d.currency)} of {formatCurrency(d.originalAmount, d.currency)} paid
              </p>
              <div className="h-1.5 rounded-full bg-white/[0.06] mt-2 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${pct}%`,
                    background: isDebt ? "#F291C8" : LAVENDER,
                  }}
                />
              </div>
              {d.remaining > 0 && (
                <PaymentInput onAdd={(amt) => handleAddPayment(d.id, d.paidAmount, amt)} />
              )}
            </div>
          );
        })}
        {(items ?? []).length === 0 && (
          <div className="md:col-span-2 text-center py-12 text-muted-foreground text-sm">
            No debts or credits tracked yet.
          </div>
        )}
      </div>
    </div>
  );
}

function PaymentInput({ onAdd }: { onAdd: (amount: string) => void }) {
  const [val, setVal] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (val) {
          onAdd(val);
          setVal("");
        }
      }}
      className="flex gap-2 mt-3"
    >
      <Input
        placeholder="Add payment $"
        type="number"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        className="h-9"
      />
      <Button type="submit" size="sm" disabled={!val}>
        Add
      </Button>
    </form>
  );
}
