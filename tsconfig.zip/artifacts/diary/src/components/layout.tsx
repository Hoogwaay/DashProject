import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  CalendarDays,
  Settings,
  Search,
  LogOut,
  Dumbbell,
  Users,
  KanbanSquare,
  BookOpen,
  PiggyBank,
} from "lucide-react";
import { cn, getDisplayName } from "@/lib/utils";
import { useT } from "@/lib/i18n";
import avatarUrl from "@/assets/avatar.png";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const t = useT();

  const NAV_ITEMS = [
    { href: "/", icon: LayoutDashboard, label: t("nav.dashboard") },
    { href: "/budget", icon: PiggyBank, label: t("nav.budget") },
    { href: "/calendar", icon: CalendarDays, label: t("nav.calendar") },
    { href: "/workouts", icon: Dumbbell, label: t("nav.sport") },
    { href: "/boards", icon: KanbanSquare, label: t("nav.boards") },
    { href: "/knowledge", icon: BookOpen, label: t("nav.knowledge") },
    { href: "/friends", icon: Users, label: t("nav.friends") },
  ];

  return (
    <div className="h-screen w-full bg-[#0a1414] text-foreground font-sans relative overflow-hidden">
      <div className="pointer-events-none absolute top-[-15%] left-[-10%] w-[55%] h-[55%] bg-primary/8 blur-[180px] rounded-full" />
      <div className="pointer-events-none absolute bottom-[-15%] right-[-10%] w-[55%] h-[55%] bg-secondary/8 blur-[180px] rounded-full" />

      <div className="relative z-10 mx-auto my-2 md:my-3 w-[calc(100%-0.5rem)] md:w-[calc(100%-1.25rem)] max-w-none h-[calc(100vh-1rem)] md:h-[calc(100vh-1.5rem)] rounded-[20px] md:rounded-[28px] bg-gradient-to-br from-[#0f1f1c]/95 via-[#0d1a18]/95 to-[#0a1614]/95 border border-white/[0.06] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.8)] backdrop-blur-xl overflow-hidden">
        <div className="pointer-events-none absolute top-0 right-0 w-[40%] h-[40%] bg-primary/5 blur-[120px] rounded-full" />
        <div className="pointer-events-none absolute bottom-0 left-1/4 w-[30%] h-[30%] bg-secondary/4 blur-[120px] rounded-full" />

        <div className="flex h-full">
          <aside className="hidden md:flex flex-col items-center py-4 px-3 w-[72px] shrink-0 z-10 relative h-full">
            <Link
              href="/"
              className="w-10 h-10 rounded-2xl bg-primary/15 flex items-center justify-center mb-4 hover:bg-primary/25 transition-colors shrink-0"
              title={t("nav.home")}
            >
              <div className="w-3 h-3 rounded-full bg-primary shadow-[0_0_12px_rgba(124,240,189,0.6)]" />
            </Link>

            <nav className="flex flex-col gap-1 items-center w-full flex-1 min-h-0 overflow-y-auto no-scrollbar">
              {NAV_ITEMS.map((item) => {
                const isActive = location === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 relative shrink-0",
                      isActive
                        ? "bg-white text-[#0a1f17] shadow-[0_0_20px_rgba(255,255,255,0.15)]"
                        : "text-muted-foreground hover:text-foreground hover:bg-white/5",
                    )}
                    title={item.label}
                  >
                    <item.icon
                      className="w-[18px] h-[18px]"
                      strokeWidth={isActive ? 2.4 : 1.8}
                    />
                  </Link>
                );
              })}
            </nav>

            <div className="flex flex-col gap-1 items-center pt-3 mt-2 border-t border-white/[0.05] w-full shrink-0">
              <Link
                href="/settings"
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center transition-all",
                  location === "/settings"
                    ? "bg-white text-[#0a1f17]"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5",
                )}
                title={t("nav.settings")}
              >
                <Settings
                  className="w-[18px] h-[18px]"
                  strokeWidth={location === "/settings" ? 2.4 : 1.8}
                />
              </Link>
              <button
                className="w-10 h-10 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all"
                title={t("app.signOut")}
              >
                <LogOut className="w-[18px] h-[18px]" strokeWidth={1.8} />
              </button>
            </div>
          </aside>

          <main className="flex-1 flex flex-col min-w-0 relative h-full overflow-hidden">
            <header className="h-[60px] md:h-[68px] flex items-center justify-between px-5 md:px-7 shrink-0 z-10 relative gap-4">
              <div className="flex items-center gap-2.5 shrink-0">
                <div className="md:hidden w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center">
                  <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                </div>
                <span className="font-semibold text-base md:text-lg tracking-tight">
                  {t("app.name")}
                </span>
              </div>

              <div className="flex-1 max-w-md hidden md:flex items-center relative">
                <Search className="w-4 h-4 absolute left-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder={t("app.search")}
                  className="w-full h-11 bg-white/[0.04] border border-white/[0.06] rounded-full pl-11 pr-4 text-sm focus:outline-none focus:bg-white/[0.06] focus:border-primary/30 transition-all placeholder:text-muted-foreground/60"
                />
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right hidden sm:block leading-tight">
                  <p className="text-[11px] text-muted-foreground">
                    {t("app.welcomeBack")}
                  </p>
                  <p className="text-sm font-semibold text-foreground tracking-tight">
                    {t("app.greeting", { name: getDisplayName() })}
                  </p>
                </div>
                <div className="w-11 h-11 rounded-full p-[2px] bg-gradient-to-tr from-primary to-secondary shrink-0">
                  <div className="w-full h-full rounded-full overflow-hidden border-2 border-[#0d1a18] bg-card">
                    <img
                      src={avatarUrl}
                      alt="Avatar"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </header>

            <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-5 md:px-7 pb-20 md:pb-6 relative z-10">
              {children}
            </div>
          </main>
        </div>
      </div>

      <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#0d1a18]/95 backdrop-blur-xl border-t border-white/[0.06] z-50 flex items-center justify-around px-1 overflow-x-auto no-scrollbar">
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-all shrink-0",
                isActive ? "bg-white text-[#0a1f17]" : "text-muted-foreground",
              )}
            >
              <item.icon className="w-5 h-5" strokeWidth={isActive ? 2.4 : 1.8} />
            </Link>
          );
        })}
        <Link
          href="/settings"
          className={cn(
            "w-10 h-10 rounded-full flex items-center justify-center transition-all shrink-0",
            location === "/settings"
              ? "bg-white text-[#0a1f17]"
              : "text-muted-foreground",
          )}
        >
          <Settings className="w-5 h-5" />
        </Link>
      </div>
    </div>
  );
}
