import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";

export type Lang = "en" | "ru";

const STORAGE_KEY = "diary.lang";

export function getStoredLang(): Lang {
  if (typeof window === "undefined") return "en";
  const v = window.localStorage.getItem(STORAGE_KEY);
  return v === "ru" ? "ru" : "en";
}

type Dict = Record<string, string>;

const en: Dict = {
  // App
  "app.name": "Diary",
  "app.search": "Search payment, note, event...",
  "app.welcomeBack": "Welcome back,",
  "app.greeting": "Hi {name}!",
  "app.signOut": "Sign out",

  // Nav
  "nav.dashboard": "Dashboard",
  "nav.budget": "Budget",
  "nav.calendar": "Calendar",
  "nav.sport": "Sport",
  "nav.boards": "Boards",
  "nav.knowledge": "Knowledge",
  "nav.friends": "Friends",
  "nav.settings": "Settings",
  "nav.home": "Home",

  // Common
  "common.save": "Save",
  "common.cancel": "Cancel",
  "common.delete": "Delete",
  "common.edit": "Edit",
  "common.create": "Create",
  "common.add": "Add",
  "common.next": "next",
  "common.close": "Close",
  "common.saving": "Saving…",
  "common.saved": "Saved!",
  "common.loading": "Loading…",
  "common.viewAll": "View All",
  "common.recent": "Recent",
  "common.all": "All",
  "common.income": "Income",
  "common.expense": "Expense",
  "common.amount": "Amount",
  "common.notes": "Notes",
  "common.notesOptional": "Notes (optional)",
  "common.description": "Description",
  "common.descriptionOptional": "Description (optional)",
  "common.name": "Name",
  "common.balance": "Balance",
  "common.date": "Date",
  "common.month": "Month",
  "common.year": "Year",
  "common.day": "Day",
  "common.entries": "entries",
  "common.min": "min",
  "common.paid": "paid",
  "common.of": "of",
  "common.due": "Due",
  "common.upcoming": "Upcoming",
  "common.thisMonth": "This month",
  "common.thisWeek": "This week",
  "common.today": "Today",
  "common.tomorrow": "Tomorrow",
  "common.yesterday": "Yesterday",
  "common.search": "Search",
  "common.openFriends": "Open friends",

  // Settings
  "settings.title": "Settings",
  "settings.subtitle": "Personalize your diary experience.",
  "settings.displayName": "Display name",
  "settings.displayNameHint": "How we greet you in the header.",
  "settings.namePlaceholder": "Your name",
  "settings.currency": "Currency",
  "settings.currencyHint": "Used for formatting amounts.",
  "settings.language": "Language",
  "settings.languageHint": "Interface language.",
  "settings.langEn": "English",
  "settings.langRu": "Russian",
  "settings.saveChanges": "Save changes",
  "settings.about": "About",
  "settings.aboutBody":
    "Personal Diary — your single home for finance, notes, investments, calendar and body metrics. All data lives in your private database.",

  // Dashboard
  "dashboard.title": "My Dashboard",
  "dashboard.filter.all": "All",
  "dashboard.filter.withdrawal": "Withdrawal",
  "dashboard.filter.savings": "Savings",
  "dashboard.filter.deposit": "Deposit",
  "dashboard.revenueFlow": "Revenue Flow",
  "dashboard.barChart": "Bar chart",
  "dashboard.lineChart": "Line chart",
  "dashboard.clickBar": "Click any bar for daily breakdown",
  "dashboard.available": "Available",
  "dashboard.balance": "Balance",
  "dashboard.myCard": "My Card",
  "dashboard.myCardHint": "Hover to spread • Click to view",
  "dashboard.totalBalance": "Total Balance",
  "dashboard.recentTransactions": "Recent Transactions",
  "dashboard.noTransactions": "No transactions yet",
  "dashboard.viewAll": "View all",
  "dashboard.spending": "Spending",
  "dashboard.friends": "Friends",
  "dashboard.friendsHint": "Share boards, split tabs, plan together",
  "dashboard.mandatoryDue": "Mandatory due",
  "dashboard.remainingThisMonth": "remaining this month",
  "dashboard.paidOf": "{paid} paid of {total}",
  "dashboard.debts": "Debts",
  "dashboard.youOweTotal": "you owe in total",
  "dashboard.youreOwed": "You're owed:",
  "dashboard.upcomingEvents": "Upcoming",
  "dashboard.viewCalendar": "View calendar",
  "dashboard.noEvents": "No upcoming events",
  "dashboard.thisMonth": "This month",
  "dashboard.recent": "Recent",
  "dashboard.day": "Day",
  "dashboard.viewAllLink": "View All",

  // Budget
  "budget.title": "Budget",
  "budget.subtitle":
    "All your money in one place — accounts, transactions, mandatory bills and debts.",
  "budget.tab.overview": "Overview",
  "budget.tab.transactions": "Transactions",
  "budget.tab.accounts": "Accounts",
  "budget.tab.mandatory": "Mandatory expenses",
  "budget.tab.debts": "Debts & credits",
  "budget.totalBalance": "Total balance",
  "budget.mandatoryLeft": "Mandatory left this month",
  "budget.youOwe": "You owe",
  "budget.youAreOwed": "You're owed",
  "budget.upcomingBills": "Upcoming bills",
  "budget.noMandatory": "No mandatory bills due this month.",
  "budget.due": "Due {date}",
  "budget.tx.subtitle": "Every payment in and out — log them here, they appear in the dashboard and category charts.",
  "budget.tx.entries": "{n} entries",
  "budget.acc.subtitle": "All your bank, card and cash accounts. Add as many as you want.",
  "budget.acc.add": "Add account",
  "budget.mn.subtitle": "Recurring monthly bills (rent, subscriptions, utilities…). Mark them paid each month and they'll log a transaction.",
  "budget.mn.new": "New bill",
  "budget.mn.dialogTitle": "Add a mandatory bill",
  "budget.mn.namePlaceholder": "Bill name (e.g. Rent)",
  "budget.mn.dueDayPlaceholder": "Day of month (1-28)",
  "budget.mn.categoryPlaceholder": "Category",
  "budget.mn.day": "Day {day}",
  "budget.mn.paid": "Paid this month",
  "budget.mn.due": "{amount} due",
  "budget.mn.paidLabel": "Paid",
  "budget.mn.markPaid": "Mark as paid",
  "budget.mn.empty": "No mandatory bills yet — add your rent, subscriptions, utilities…",
  "budget.dt.subtitle": "Track money you owe (debts) and money owed to you (credits).",
  "budget.dt.new": "New entry",
  "budget.dt.dialogTitle": "Add debt or credit",
  "budget.dt.iOwe": "I owe (debt)",
  "budget.dt.owedToMe": "Owed to me (credit)",
  "budget.dt.iOweShort": "I owe",
  "budget.dt.owedShort": "Owed to me",
  "budget.dt.descPlaceholder": "Description",
  "budget.dt.counterparty": "Counterparty (optional)",
  "budget.dt.notes": "Notes (optional)",
  "budget.dt.paidOf": "{paid} of {total} paid",
  "budget.dt.empty": "No debts or credits tracked yet.",
  "budget.dt.addPaymentPlaceholder": "Add payment $",
  "budget.dt.addBtn": "Add",
  "common.amount": "Amount",
  "common.delete": "Delete",
  "common.saving": "Saving…",

  // Transactions
  "tx.title": "Transactions",
  "tx.subtitle": "All your income and spending in one place.",
  "tx.add": "Add transaction",
  "tx.new": "New transaction",
  "tx.amount": "Amount",
  "tx.category": "Category (e.g. Groceries)",
  "tx.merchantOptional": "Merchant (optional)",
  "tx.descriptionOptional": "Description (optional)",
  "tx.filter.all": "all",
  "tx.filter.income": "income",
  "tx.filter.expense": "expense",
  "tx.empty": "No transactions match this filter.",
  "tx.income": "Income",
  "tx.expense": "Expense",

  // Knowledge
  "kn.title": "Knowledge",
  "kn.subtitle": "Notes that link to each other. Use [[Note Title]] to create connections.",
  "kn.notes": "Notes",
  "kn.mindMap": "Mind map",
  "kn.mindMapTitle": "Open the visual mind-map of your notes",
  "kn.search": "Search…",
  "kn.newNote": "New note",
  "kn.noNotes": "No notes",
  "kn.untitled": "Untitled note",
  "kn.deleteConfirm": "Delete this note?",
  "kn.tagsPlaceholder": "Tags (comma separated)",
  "kn.contentPlaceholder": "Write your note. Use [[Other note title]] to link.",
  "kn.linkTip": "Tip: Save to auto-create links from",
  "kn.linkTipSuffix": "references",
  "kn.selectOrCreate": "Select a note or create a new one",
  "kn.connectModeStart": "Connect mode — click any dot to start a connection",
  "kn.connectModeNext": "Now click another dot to draw a link (or click the same one to cancel)",
  "kn.dragHint": "Drag dots to move them. Double-click a dot to open the note.",
  "kn.exitConnect": "Exit connect mode",
  "kn.connectNotes": "Connect notes",
  "kn.removeLinkConfirm": "Remove this link?",
  "kn.emptyGraph": "No notes yet — create some on the Notes tab.",
  "kn.connectTip": "Click to connect",
  "kn.nodeTip": "drag to move, double-click to open",
  "kn.legendConnect": "Click two dots to link them • Click a line to delete",
  "kn.legendDrag": "Drag to move • Double-click to open • Click a line to remove",

  // Investments
  "inv.title": "Investments",
  "inv.subtitle": "Track your portfolio performance.",
  "inv.add": "Add holding",
  "inv.name": "Name",
  "inv.ticker": "Ticker",
  "inv.qty": "Qty",
  "inv.buyPrice": "Buy price",
  "inv.nowPrice": "Now price",
  "inv.kind.stock": "Stock",
  "inv.kind.etf": "ETF",
  "inv.kind.crypto": "Crypto",
  "inv.kind.bond": "Bond",
  "inv.portfolioValue": "Portfolio value",
  "inv.allTime": "All time",
  "inv.holdings": "Holdings",
  "inv.acrossClasses": "Across all asset classes",
  "inv.allHoldings": "All holdings",
  "inv.noHoldings": "No holdings yet.",

  // Accounts
  "acc.heading": "Accounts",
  "acc.subtitle": "Manage your connected accounts and cash.",
  "acc.add": "Add Account",
  "acc.title": "Add Account",
  "acc.empty": "No accounts added yet.",
  "acc.totalBalance": "Total Balance",
  "acc.name": "Account name",
  "acc.namePlaceholder": "e.g. Chase Checking",
  "acc.type": "Type",
  "acc.currentBalance": "Current balance",
  "acc.cardLast4": "Card last 4 digits (optional)",
  "acc.kind.checking": "Checking",
  "acc.kind.savings": "Savings",
  "acc.kind.credit": "Credit Card",
  "acc.kind.cash": "Cash",
  "acc.kind.crypto": "Crypto",

  // Mandatory
  "mand.subtitle": "Recurring monthly bills you must pay (rent, utilities, subscriptions).",
  "mand.add": "Add bill",
  "mand.new": "New mandatory bill",
  "mand.namePlaceholder": "Name (e.g. Rent)",
  "mand.dueDay": "Due day of month (1-31)",
  "mand.categoryPlaceholder": "Category (Bills, Subscriptions…)",
  "mand.markPaid": "Mark paid",
  "mand.alreadyPaid": "Paid this month",
  "mand.dueOn": "Due {day} every month",
  "mand.empty": "No mandatory bills yet.",

  // Debts
  "debt.subtitle": "Track money you owe (debts) and money owed to you (credits).",
  "debt.add": "New entry",
  "debt.new": "Add debt or credit",
  "debt.iOwe": "I owe (debt)",
  "debt.owedToMe": "Owed to me (credit)",
  "debt.descriptionPlaceholder": "Description",
  "debt.counterparty": "Counterparty (optional)",
  "debt.iOweLabel": "I owe",
  "debt.owedLabel": "Owed to me",
  "debt.empty": "No debts or credits tracked yet.",
  "debt.addPayment": "Add payment $",

  // Notes
  "notes.title": "Notes",
  "notes.subtitle": "Capture your thoughts and ideas.",
  "notes.new": "New Note",
  "notes.create": "Create Note",
  "notes.edit": "Edit Note",
  "notes.titlePlaceholder": "Note title...",
  "notes.contentPlaceholder": "Write something...",
  "notes.save": "Save Note",
  "notes.pinned": "Pinned",
  "notes.others": "Others",
  "notes.allNotes": "All Notes",
  "notes.empty": "No notes yet. Create one to get started.",

  // Forecast
  "forecast.title": "Income Forecast",
  "forecast.subtitle": "Plan upcoming and recurring income.",
  "forecast.add": "Add forecast",
  "forecast.new": "New forecast entry",
  "forecast.sourcePlaceholder": "Source (e.g. Salary)",
  "forecast.expectedNext3": "Expected next 3 months",
  "forecast.entriesAvg": "{count} entries · avg {avg} / month",
  "forecast.recurring": "Recurring streams",
  "forecast.outOfPlanned": "Out of {total} planned items",
  "forecast.upcoming": "Upcoming income",
  "forecast.empty": "No forecasts yet.",
  "forecast.recur.once": "One-time",
  "forecast.recur.weekly": "Weekly",
  "forecast.recur.monthly": "Monthly",
  "forecast.recur.quarterly": "Quarterly",
  "forecast.recur.yearly": "Yearly",

  // Calendar
  "cal.title": "Calendar",
  "cal.subtitle": "Tasks, workouts, body measurements — your week ahead.",
  "cal.add": "Add event",
  "cal.new": "New event",
  "cal.titlePlaceholder": "Event title",
  "cal.kind": "Kind",
  "cal.kind.task": "Task",
  "cal.kind.workout": "Workout",
  "cal.kind.measurement": "Measurement",
  "cal.kind.note": "Note",
  "cal.kind.other": "Other",
  "cal.duration": "Duration (minutes)",
  "cal.eventsThisMonth": "Events this month",
  "cal.noEvents": "No events.",
  "cal.weekday.mon": "Mon",
  "cal.weekday.tue": "Tue",
  "cal.weekday.wed": "Wed",
  "cal.weekday.thu": "Thu",
  "cal.weekday.fri": "Fri",
  "cal.weekday.sat": "Sat",
  "cal.weekday.sun": "Sun",
  "cal.more": "more",

  // Workouts / Body
  "workouts.title": "Sport",
  "workouts.subtitle":
    "Workouts, exercises and body metrics — all your training in one place.",
  "workouts.tab.workouts": "Workouts",
  "workouts.tab.body": "Body",
  "workouts.subtitle2":
    "Sessions sync to your calendar. Track exercises and watch your body metrics evolve.",
  "workouts.new": "New workout",
  "workouts.schedule": "Schedule a workout",
  "workouts.namePlaceholder": "Workout name (e.g. Push day)",
  "workouts.duration": "Duration (minutes)",
  "workouts.exercises": "Exercises",
  "workouts.addExercise": "Add exercise",
  "workouts.exerciseName": "Exercise name",
  "workouts.sets": "Sets",
  "workouts.reps": "Reps",
  "workouts.weight": "Weight (kg)",
  "workouts.empty": "No workouts yet. Schedule your first one.",
  "workouts.body.subtitle":
    "Track weight, body fat, and measurements over time.",
  "workouts.body.add": "Log measurement",
  "workouts.body.new": "New measurement",
  "workouts.body.weight": "Weight (kg)",
  "workouts.body.bodyFat": "Body fat %",
  "workouts.body.muscle": "Muscle %",
  "workouts.body.waist": "Waist (cm)",
  "workouts.body.chest": "Chest (cm)",
  "workouts.body.hips": "Hips (cm)",
  "workouts.body.history": "History",
  "workouts.body.empty": "No measurements yet.",

  // Friends
  "friends.title": "Friends",
  "friends.subtitle": "Friends and colleagues you can share boards and notes with.",
  "friends.add": "Add person",
  "friends.addTitle": "Add a person",
  "friends.editTitle": "Edit person",
  "friends.role.friend": "Friend",
  "friends.role.colleague": "Colleague",
  "friends.section.friends": "Friends",
  "friends.section.colleagues": "Colleagues",
  "friends.empty": "No people yet. Add your first one.",
  "friends.emailPlaceholder": "Email (optional)",

  // Boards
  "boards.title": "Boards",
  "boards.subtitle":
    "Helpdesk-style kanban boards. Each board has columns and cards. Share with friends to collaborate.",
  "boards.new": "New board",
  "boards.create": "Create a board",
  "boards.namePlaceholder": "Board name",
  "boards.descriptionPlaceholder": "Description",
  "boards.empty": "No boards yet. Create your first one.",
  "boards.cards": "cards",
  "boards.back": "Back to boards",
  "boards.newColumn": "New column",
  "boards.newCard": "New card",
  "boards.cardTitle": "Card title",
  "boards.priority": "Priority",
  "boards.priority.low": "Low",
  "boards.priority.medium": "Medium",
  "boards.priority.high": "High",
  "boards.dueDate": "Due date",
  "boards.share": "Share",
  "boards.shareTitle": "Share board",
  "boards.alreadyShared": "Already shared with",
  "boards.noMembers": "No members yet",
  "boards.addFriend": "Add a friend",
  "boards.deleteColumn": "Delete this column and all cards?",
  "boards.cardTitlePlaceholder": "Card title…",
  "boards.addCard": "Add card",
  "boards.columnName": "Column name",
  "boards.addColumn": "Add column",

  // Knowledge
  "knowledge.title": "Knowledge",
  "knowledge.subtitle": "Your personal knowledge graph — notes connected by ideas.",
  "knowledge.new": "New note",
  "knowledge.newNote": "New knowledge note",
  "knowledge.tagsPlaceholder": "Tags (comma separated)",
  "knowledge.empty": "Your knowledge graph is empty.",
  "knowledge.linkLabel": "Link label",

  // 404
  "nf.title": "404 Page Not Found",
  "nf.subtitle": "Did you forget to add the page to the router?",
};

const ru: Dict = {
  // App
  "app.name": "Дневник",
  "app.search": "Поиск платежей, заметок, событий...",
  "app.welcomeBack": "С возвращением,",
  "app.greeting": "Привет, {name}!",
  "app.signOut": "Выйти",

  // Nav
  "nav.dashboard": "Главная",
  "nav.budget": "Бюджет",
  "nav.calendar": "Календарь",
  "nav.sport": "Спорт",
  "nav.boards": "Доски",
  "nav.knowledge": "База знаний",
  "nav.friends": "Друзья",
  "nav.settings": "Настройки",
  "nav.home": "Главная",

  // Common
  "common.save": "Сохранить",
  "common.cancel": "Отмена",
  "common.delete": "Удалить",
  "common.edit": "Редактировать",
  "common.create": "Создать",
  "common.add": "Добавить",
  "common.next": "далее",
  "common.close": "Закрыть",
  "common.saving": "Сохранение…",
  "common.saved": "Сохранено!",
  "common.loading": "Загрузка…",
  "common.viewAll": "Все",
  "common.recent": "Недавние",
  "common.all": "Все",
  "common.income": "Доход",
  "common.expense": "Расход",
  "common.amount": "Сумма",
  "common.notes": "Заметки",
  "common.notesOptional": "Заметки (необязательно)",
  "common.description": "Описание",
  "common.descriptionOptional": "Описание (необязательно)",
  "common.name": "Название",
  "common.balance": "Баланс",
  "common.date": "Дата",
  "common.month": "Месяц",
  "common.year": "Год",
  "common.day": "День",
  "common.entries": "записей",
  "common.min": "мин",
  "common.paid": "оплачено",
  "common.of": "из",
  "common.due": "Срок",
  "common.upcoming": "Скоро",
  "common.thisMonth": "В этом месяце",
  "common.thisWeek": "На этой неделе",
  "common.today": "Сегодня",
  "common.tomorrow": "Завтра",
  "common.yesterday": "Вчера",
  "common.search": "Поиск",
  "common.openFriends": "Открыть друзей",

  // Settings
  "settings.title": "Настройки",
  "settings.subtitle": "Персонализируйте ваш дневник.",
  "settings.displayName": "Отображаемое имя",
  "settings.displayNameHint": "Как мы обращаемся к вам в шапке.",
  "settings.namePlaceholder": "Ваше имя",
  "settings.currency": "Валюта",
  "settings.currencyHint": "Используется для форматирования сумм.",
  "settings.language": "Язык",
  "settings.languageHint": "Язык интерфейса.",
  "settings.langEn": "Английский",
  "settings.langRu": "Русский",
  "settings.saveChanges": "Сохранить",
  "settings.about": "О программе",
  "settings.aboutBody":
    "Персональный дневник — единое место для финансов, заметок, инвестиций, календаря и метрик тела. Все данные хранятся в вашей личной базе.",

  // Dashboard
  "dashboard.title": "Моя панель",
  "dashboard.filter.all": "Все",
  "dashboard.filter.withdrawal": "Снятие",
  "dashboard.filter.savings": "Накопления",
  "dashboard.filter.deposit": "Пополнение",
  "dashboard.revenueFlow": "Денежный поток",
  "dashboard.barChart": "Гистограмма",
  "dashboard.lineChart": "Линия",
  "dashboard.clickBar": "Нажмите столбец для разбивки по дням",
  "dashboard.available": "Доступно",
  "dashboard.balance": "Баланс",
  "dashboard.myCard": "Моя карта",
  "dashboard.myCardHint": "Наведите для разворота • Нажмите для просмотра",
  "dashboard.totalBalance": "Общий баланс",
  "dashboard.recentTransactions": "Недавние операции",
  "dashboard.noTransactions": "Пока нет операций",
  "dashboard.viewAll": "Все",
  "dashboard.spending": "Расходы",
  "dashboard.friends": "Друзья",
  "dashboard.friendsHint": "Делитесь досками, считайте вместе, планируйте",
  "dashboard.mandatoryDue": "Обязательные платежи",
  "dashboard.remainingThisMonth": "осталось в этом месяце",
  "dashboard.paidOf": "{paid} оплачено из {total}",
  "dashboard.debts": "Долги",
  "dashboard.youOweTotal": "вы должны всего",
  "dashboard.youreOwed": "Вам должны:",
  "dashboard.upcomingEvents": "Скоро",
  "dashboard.viewCalendar": "Календарь",
  "dashboard.noEvents": "Нет ближайших событий",
  "dashboard.thisMonth": "В этом месяце",
  "dashboard.recent": "Недавние",
  "dashboard.day": "День",
  "dashboard.viewAllLink": "Смотреть все",

  // Budget
  "budget.title": "Бюджет",
  "budget.subtitle":
    "Все ваши деньги в одном месте — счета, операции, обязательные платежи и долги.",
  "budget.tab.overview": "Обзор",
  "budget.tab.transactions": "Операции",
  "budget.tab.accounts": "Счета",
  "budget.tab.mandatory": "Обязательные расходы",
  "budget.tab.debts": "Долги и кредиты",
  "budget.totalBalance": "Общий баланс",
  "budget.mandatoryLeft": "Обязательных осталось",
  "budget.youOwe": "Вы должны",
  "budget.youAreOwed": "Вам должны",
  "budget.upcomingBills": "Ближайшие платежи",
  "budget.noMandatory": "Нет обязательных платежей в этом месяце.",
  "budget.due": "До {date}",
  "budget.tx.subtitle": "Каждый приход и расход — записывайте здесь, они появятся на главной и в графиках по категориям.",
  "budget.tx.entries": "{n} записей",
  "budget.acc.subtitle": "Все ваши банковские, картные и наличные счета. Добавляйте сколько нужно.",
  "budget.acc.add": "Добавить счёт",
  "budget.mn.subtitle": "Регулярные платежи (аренда, подписки, коммуналка…). Отмечайте оплату — операция запишется автоматически.",
  "budget.mn.new": "Новый платёж",
  "budget.mn.dialogTitle": "Добавить обязательный платёж",
  "budget.mn.namePlaceholder": "Название (например, Аренда)",
  "budget.mn.dueDayPlaceholder": "День месяца (1-28)",
  "budget.mn.categoryPlaceholder": "Категория",
  "budget.mn.day": "День {day}",
  "budget.mn.paid": "Оплачено в этом месяце",
  "budget.mn.due": "Осталось {amount}",
  "budget.mn.paidLabel": "Оплачено",
  "budget.mn.markPaid": "Отметить оплаченным",
  "budget.mn.empty": "Пока нет обязательных платежей — добавьте аренду, подписки, коммуналку…",
  "budget.dt.subtitle": "Учитывайте долги (которые вы должны) и кредиты (которые должны вам).",
  "budget.dt.new": "Новая запись",
  "budget.dt.dialogTitle": "Добавить долг или кредит",
  "budget.dt.iOwe": "Я должен (долг)",
  "budget.dt.owedToMe": "Мне должны (кредит)",
  "budget.dt.iOweShort": "Я должен",
  "budget.dt.owedShort": "Мне должны",
  "budget.dt.descPlaceholder": "Описание",
  "budget.dt.counterparty": "Кому/от кого (необязательно)",
  "budget.dt.notes": "Заметки (необязательно)",
  "budget.dt.paidOf": "{paid} из {total} погашено",
  "budget.dt.empty": "Долгов и кредитов пока нет.",
  "budget.dt.addPaymentPlaceholder": "Добавить платёж ₽",
  "budget.dt.addBtn": "Добавить",
  "common.amount": "Сумма",
  "common.delete": "Удалить",
  "common.saving": "Сохранение…",

  // Transactions
  "tx.title": "Операции",
  "tx.subtitle": "Все ваши доходы и расходы в одном месте.",
  "tx.add": "Добавить операцию",
  "tx.new": "Новая операция",
  "tx.amount": "Сумма",
  "tx.category": "Категория (например, Продукты)",
  "tx.merchantOptional": "Магазин (необязательно)",
  "tx.descriptionOptional": "Описание (необязательно)",
  "tx.filter.all": "все",
  "tx.filter.income": "доход",
  "tx.filter.expense": "расход",
  "tx.empty": "Нет операций по этому фильтру.",
  "tx.income": "Доход",
  "tx.expense": "Расход",

  // Knowledge
  "kn.title": "База знаний",
  "kn.subtitle": "Заметки, связанные между собой. Используйте [[Заголовок]], чтобы создать связь.",
  "kn.notes": "Заметки",
  "kn.mindMap": "Карта",
  "kn.mindMapTitle": "Открыть визуальную карту заметок",
  "kn.search": "Поиск…",
  "kn.newNote": "Новая заметка",
  "kn.noNotes": "Нет заметок",
  "kn.untitled": "Без названия",
  "kn.deleteConfirm": "Удалить эту заметку?",
  "kn.tagsPlaceholder": "Теги (через запятую)",
  "kn.contentPlaceholder": "Напишите заметку. Используйте [[Заголовок]] для ссылок.",
  "kn.linkTip": "Подсказка: после сохранения автоматически создадутся связи из",
  "kn.linkTipSuffix": "ссылок",
  "kn.selectOrCreate": "Выберите заметку или создайте новую",
  "kn.connectModeStart": "Режим связи — нажмите на точку, чтобы начать связь",
  "kn.connectModeNext": "Нажмите на другую точку, чтобы создать связь (или на ту же, чтобы отменить)",
  "kn.dragHint": "Перетаскивайте точки. Двойной клик — открыть заметку.",
  "kn.exitConnect": "Выйти из режима связи",
  "kn.connectNotes": "Связать заметки",
  "kn.removeLinkConfirm": "Удалить эту связь?",
  "kn.emptyGraph": "Заметок пока нет — создайте их во вкладке «Заметки».",
  "kn.connectTip": "Нажмите для связи",
  "kn.nodeTip": "перетащить — двигать, двойной клик — открыть",
  "kn.legendConnect": "Кликните на две точки, чтобы связать • Клик по линии — удалить",
  "kn.legendDrag": "Перетаскивайте • Двойной клик — открыть • Клик по линии — удалить",

  // Investments
  "inv.title": "Инвестиции",
  "inv.subtitle": "Отслеживайте доходность портфеля.",
  "inv.add": "Добавить актив",
  "inv.name": "Название",
  "inv.ticker": "Тикер",
  "inv.qty": "Кол-во",
  "inv.buyPrice": "Цена покупки",
  "inv.nowPrice": "Тек. цена",
  "inv.kind.stock": "Акция",
  "inv.kind.etf": "ETF",
  "inv.kind.crypto": "Крипто",
  "inv.kind.bond": "Облигация",
  "inv.portfolioValue": "Стоимость портфеля",
  "inv.allTime": "За всё время",
  "inv.holdings": "Активы",
  "inv.acrossClasses": "По всем классам активов",
  "inv.allHoldings": "Все активы",
  "inv.noHoldings": "Активов пока нет.",

  // Accounts
  "acc.heading": "Счета",
  "acc.subtitle": "Управляйте подключёнными счетами и наличными.",
  "acc.add": "Добавить счёт",
  "acc.title": "Добавить счёт",
  "acc.empty": "Счетов пока нет.",
  "acc.totalBalance": "Общий баланс",
  "acc.name": "Название счёта",
  "acc.namePlaceholder": "например, Сбер Дебетовая",
  "acc.type": "Тип",
  "acc.currentBalance": "Текущий баланс",
  "acc.cardLast4": "Последние 4 цифры карты (необязательно)",
  "acc.kind.checking": "Дебетовая",
  "acc.kind.savings": "Накопительная",
  "acc.kind.credit": "Кредитная карта",
  "acc.kind.cash": "Наличные",
  "acc.kind.crypto": "Крипто",

  // Mandatory
  "mand.subtitle":
    "Регулярные ежемесячные платежи (аренда, услуги, подписки).",
  "mand.add": "Добавить платёж",
  "mand.new": "Новый обязательный платёж",
  "mand.namePlaceholder": "Название (например, Аренда)",
  "mand.dueDay": "День месяца оплаты (1-31)",
  "mand.categoryPlaceholder": "Категория (Счета, Подписки…)",
  "mand.markPaid": "Отметить оплаченным",
  "mand.alreadyPaid": "Оплачено в этом месяце",
  "mand.dueOn": "Каждое {day} число",
  "mand.empty": "Пока нет обязательных платежей.",

  // Debts
  "debt.subtitle": "Учёт денег, которые вы должны (долги) и которые должны вам (кредиты).",
  "debt.add": "Новая запись",
  "debt.new": "Добавить долг или кредит",
  "debt.iOwe": "Я должен (долг)",
  "debt.owedToMe": "Мне должны (кредит)",
  "debt.descriptionPlaceholder": "Описание",
  "debt.counterparty": "Контрагент (необязательно)",
  "debt.iOweLabel": "Я должен",
  "debt.owedLabel": "Мне должны",
  "debt.empty": "Пока нет учтённых долгов или кредитов.",
  "debt.addPayment": "Добавить платёж",

  // Notes
  "notes.title": "Заметки",
  "notes.subtitle": "Сохраняйте мысли и идеи.",
  "notes.new": "Новая заметка",
  "notes.create": "Создать заметку",
  "notes.edit": "Редактировать",
  "notes.titlePlaceholder": "Заголовок заметки...",
  "notes.contentPlaceholder": "Напишите что-нибудь...",
  "notes.save": "Сохранить",
  "notes.pinned": "Закреплённые",
  "notes.others": "Остальные",
  "notes.allNotes": "Все заметки",
  "notes.empty": "Заметок пока нет. Создайте первую.",

  // Forecast
  "forecast.title": "Прогноз доходов",
  "forecast.subtitle": "Планируйте предстоящие и регулярные доходы.",
  "forecast.add": "Добавить прогноз",
  "forecast.new": "Новый прогноз",
  "forecast.sourcePlaceholder": "Источник (например, Зарплата)",
  "forecast.expectedNext3": "Ожидается за 3 месяца",
  "forecast.entriesAvg": "{count} записей · в среднем {avg} / месяц",
  "forecast.recurring": "Регулярные потоки",
  "forecast.outOfPlanned": "Из {total} запланированных",
  "forecast.upcoming": "Ближайшие доходы",
  "forecast.empty": "Прогнозов пока нет.",
  "forecast.recur.once": "Разовый",
  "forecast.recur.weekly": "Еженедельно",
  "forecast.recur.monthly": "Ежемесячно",
  "forecast.recur.quarterly": "Ежеквартально",
  "forecast.recur.yearly": "Ежегодно",

  // Calendar
  "cal.title": "Календарь",
  "cal.subtitle":
    "Задачи, тренировки, измерения тела — ваша неделя впереди.",
  "cal.add": "Добавить событие",
  "cal.new": "Новое событие",
  "cal.titlePlaceholder": "Название события",
  "cal.kind": "Тип",
  "cal.kind.task": "Задача",
  "cal.kind.workout": "Тренировка",
  "cal.kind.measurement": "Измерение",
  "cal.kind.note": "Заметка",
  "cal.kind.other": "Другое",
  "cal.duration": "Длительность (минуты)",
  "cal.eventsThisMonth": "События в этом месяце",
  "cal.noEvents": "Нет событий.",
  "cal.weekday.mon": "Пн",
  "cal.weekday.tue": "Вт",
  "cal.weekday.wed": "Ср",
  "cal.weekday.thu": "Чт",
  "cal.weekday.fri": "Пт",
  "cal.weekday.sat": "Сб",
  "cal.weekday.sun": "Вс",
  "cal.more": "ещё",

  // Workouts / Body
  "workouts.title": "Спорт",
  "workouts.subtitle":
    "Тренировки, упражнения и метрики тела — всё в одном месте.",
  "workouts.tab.workouts": "Тренировки",
  "workouts.tab.body": "Тело",
  "workouts.subtitle2":
    "Сессии синхронизируются с календарём. Записывайте упражнения и следите за метриками.",
  "workouts.new": "Новая тренировка",
  "workouts.schedule": "Запланировать тренировку",
  "workouts.namePlaceholder": "Название (например, День груди)",
  "workouts.duration": "Длительность (минуты)",
  "workouts.exercises": "Упражнения",
  "workouts.addExercise": "Добавить упражнение",
  "workouts.exerciseName": "Название упражнения",
  "workouts.sets": "Подходы",
  "workouts.reps": "Повторения",
  "workouts.weight": "Вес (кг)",
  "workouts.empty": "Пока нет тренировок. Запланируйте первую.",
  "workouts.body.subtitle":
    "Отслеживайте вес, процент жира и измерения с течением времени.",
  "workouts.body.add": "Добавить замер",
  "workouts.body.new": "Новый замер",
  "workouts.body.weight": "Вес (кг)",
  "workouts.body.bodyFat": "Жир %",
  "workouts.body.muscle": "Мышцы %",
  "workouts.body.waist": "Талия (см)",
  "workouts.body.chest": "Грудь (см)",
  "workouts.body.hips": "Бёдра (см)",
  "workouts.body.history": "История",
  "workouts.body.empty": "Замеров пока нет.",

  // Friends
  "friends.title": "Друзья",
  "friends.subtitle":
    "Друзья и коллеги, с которыми можно делиться досками и заметками.",
  "friends.add": "Добавить",
  "friends.addTitle": "Добавить человека",
  "friends.editTitle": "Редактировать",
  "friends.role.friend": "Друг",
  "friends.role.colleague": "Коллега",
  "friends.section.friends": "Друзья",
  "friends.section.colleagues": "Коллеги",
  "friends.empty": "Пока пусто. Добавьте первого человека.",
  "friends.emailPlaceholder": "Email (необязательно)",

  // Boards
  "boards.title": "Доски",
  "boards.subtitle":
    "Канбан-доски в стиле helpdesk. Колонки и карточки. Делитесь с друзьями для совместной работы.",
  "boards.new": "Новая доска",
  "boards.create": "Создать доску",
  "boards.namePlaceholder": "Название доски",
  "boards.descriptionPlaceholder": "Описание",
  "boards.empty": "Досок пока нет. Создайте первую.",
  "boards.cards": "карточек",
  "boards.back": "К доскам",
  "boards.newColumn": "Новая колонка",
  "boards.newCard": "Новая карточка",
  "boards.cardTitle": "Заголовок карточки",
  "boards.priority": "Приоритет",
  "boards.priority.low": "Низкий",
  "boards.priority.medium": "Средний",
  "boards.priority.high": "Высокий",
  "boards.dueDate": "Срок",
  "boards.share": "Поделиться",
  "boards.shareTitle": "Поделиться доской",
  "boards.alreadyShared": "Уже доступно",
  "boards.noMembers": "Пока никто не добавлен",
  "boards.addFriend": "Добавить друга",
  "boards.deleteColumn": "Удалить колонку и все карточки?",
  "boards.cardTitlePlaceholder": "Заголовок карточки…",
  "boards.addCard": "Добавить карточку",
  "boards.columnName": "Название колонки",
  "boards.addColumn": "Добавить колонку",

  // Knowledge
  "knowledge.title": "База знаний",
  "knowledge.subtitle":
    "Ваш граф знаний — заметки, связанные идеями.",
  "knowledge.new": "Новая заметка",
  "knowledge.newNote": "Новая заметка знаний",
  "knowledge.tagsPlaceholder": "Теги (через запятую)",
  "knowledge.empty": "Граф знаний пуст.",
  "knowledge.linkLabel": "Подпись связи",

  // 404
  "nf.title": "404 — Страница не найдена",
  "nf.subtitle": "Возможно вы забыли добавить страницу в маршрутизатор?",
};

const DICTS: Record<Lang, Dict> = { en, ru };

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
};

const I18nContext = createContext<Ctx | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => getStoredLang());

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) setLangState(getStoredLang());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const setLang = (l: Lang) => {
    window.localStorage.setItem(STORAGE_KEY, l);
    document.documentElement.lang = l;
    setLangState(l);
  };

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const t = (key: string, vars?: Record<string, string | number>) => {
    const dict = DICTS[lang] ?? en;
    let raw = dict[key] ?? en[key] ?? key;
    if (vars) {
      for (const [k, v] of Object.entries(vars)) {
        raw = raw.replaceAll(`{${k}}`, String(v));
      }
    }
    return raw;
  };

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    // Fallback if used outside provider — use stored lang
    const lang = getStoredLang();
    return {
      lang,
      setLang: (_l: Lang) => {},
      t: (key: string, vars?: Record<string, string | number>) => {
        const dict = DICTS[lang] ?? en;
        let raw = dict[key] ?? en[key] ?? key;
        if (vars) {
          for (const [k, v] of Object.entries(vars)) {
            raw = raw.replaceAll(`{${k}}`, String(v));
          }
        }
        return raw;
      },
    };
  }
  return ctx;
}

export function useT() {
  return useI18n().t;
}

export function localeFor(lang: Lang) {
  return lang === "ru" ? "ru-RU" : "en-US";
}
