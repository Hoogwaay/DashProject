import { useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListMandatoryExpenses,
  useCreateMandatoryExpense,
  useDeleteMandatoryExpense,
  usePayMandatoryExpense,
  useListDebts,
  useCreateDebt,
  useUpdateDebt,
  useDeleteDebt,
  useListAccounts,
  useCreateAccount,
  useDeleteAccount,
  useListTransactions,
  useCreateTransaction,
  useDeleteTransaction,
  getListMandatoryExpensesQueryKey,
  getListDebtsQueryKey,
  getListAccountsQueryKey,
  getListTransactionsQueryKey,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatCurrency, formatShortDate } from "@/lib/utils";
import {
  Plus,
  Trash2,
  Wallet,
  AlertCircle,
  Check,
  ArrowDownRight,
  ArrowUpRight,
  CalendarDays,
  CreditCard,
  Building2,
  Bitcoin,
  MoreHorizontal,
  Filter,
} from "lucide-react";
import { useT, useI18n, localeFor } from "@/lib/i18n";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

type Tab = "overview" | "transactions" | "accounts" | "mandatory" | "debts";

const TAB_IDS: Tab[] = ["overview", "transactions", "accounts", "mandatory", "debts"];

export default function Budget() {
  const t = useT();
  const [tab, setTab] = useState<Tab>("overview");

  return (
    <Layout>
      <div className="flex flex-col gap-2 mb-6 mt-2">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">{t("budget.title")}</h1>
        <p className="text-sm text-muted-foreground">
          {t("budget.subtitle")}
        </p>
      </div>

      <div className="flex flex-wrap gap-2 mb-6 border-b border-white/[0.06] pb-1">
        {TAB_IDS.map((id) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`px-4 py-2 text-sm font-medium rounded-full transition-all ${
              tab === id
                ? "bg-white text-[#0a1f17]"
                : "text-muted-foreground hover:text-foreground hover:bg-white/[0.04]"
            }`}
          >
            {t(`budget.tab.${id}` as any)}
          </button>
        ))}
      </div>

      {tab === "overview" && <OverviewTab onJump={setTab} />}
      {tab === "transactions" && <TransactionsTab />}
      {tab === "accounts" && <AccountsTab />}
      {tab === "mandatory" && <MandatoryTab />}
      {tab === "debts" && <DebtsTab />}
    </Layout>
  );
}

/* ------------------------- Overview ------------------------- */

function OverviewTab({ onJump }: { onJump: (t: Tab) => void }) {
  const t = useT();
  const { lang } = useI18n();
  const { data: accounts } = useListAccounts();
  const { data: mandatory } = useListMandatoryExpenses();
  const { data: debts } = useListDebts();

  const totalBalance = (accounts ?? []).reduce((s, a) => s + a.balance, 0);
  const mandatoryRemaining = (mandatory ?? []).reduce(
    (s, m) => s + Math.max(0, m.amount - m.paidThisMonth),
    0,
  );
  const debtTotal = (debts ?? [])
    .filter((d) => d.kind === "debt")
    .reduce((s, d) => s + d.remaining, 0);
  const creditTotal = (debts ?? [])
    .filter((d) => d.kind === "credit")
    .reduce((s, d) => s + d.remaining, 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <SummaryTile
        icon={<Wallet className="w-4 h-4" />}
        label={t("budget.totalBalance")}
        value={totalBalance}
        color={MINT}
        onClick={() => onJump("accounts")}
      />
      <SummaryTile
        icon={<AlertCircle className="w-4 h-4" />}
        label={t("budget.mandatoryLeft")}
        value={mandatoryRemaining}
        color="#F2C879"
        onClick={() => onJump("mandatory")}
      />
      <SummaryTile
        icon={<ArrowDownRight className="w-4 h-4" />}
        label={t("budget.youOwe")}
        value={debtTotal}
        color="#F291C8"
        onClick={() => onJump("debts")}
      />
      <SummaryTile
        icon={<ArrowUpRight className="w-4 h-4" />}
        label={t("budget.youAreOwed")}
        value={creditTotal}
        color={LAVENDER}
        onClick={() => onJump("debts")}
      />

      <div className="md:col-span-2 lg:col-span-4 rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6 mt-2">
        <h3 className="font-semibold text-lg mb-4">{t("budget.upcomingBills")}</h3>
        <div className="space-y-3">
          {(mandatory ?? [])
            .filter((m) => m.active && m.amount > m.paidThisMonth)
            .slice(0, 6)
            .map((m) => (
              <div
                key={m.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.02] border border-white/[0.05]"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: (m.color ?? "#F2C879") + "26", color: m.color ?? "#F2C879" }}
                  >
                    <CalendarDays className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{m.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {t("budget.due", {
                        date: new Date(m.nextDueDate).toLocaleDateString(localeFor(lang), {
                          month: "short",
                          day: "numeric",
                        }),
                      })}
                    </p>
                  </div>
                </div>
                <p className="text-lg font-bold tabular-nums">
                  {formatCurrency(Math.max(0, m.amount - m.paidThisMonth), m.currency)}
                </p>
              </div>
            ))}
          {(mandatory ?? []).filter((m) => m.active && m.amount > m.paidThisMonth).length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-6">
              {t("budget.noMandatory")} 🎉
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function SummaryTile({
  icon,
  label,
  value,
  color,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="text-left rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 backdrop-blur-sm hover:bg-white/[0.05] hover:border-white/[0.1] transition-all"
    >
      <div className="flex items-center gap-2 mb-3">
        <div
          className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: color + "22", color }}
        >
          {icon}
        </div>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
      <p className="text-2xl font-bold tabular-nums">{formatCurrency(value)}</p>
    </button>
  );
}

/* ------------------------- Transactions ------------------------- */

function TransactionsTab() {
  const t = useT();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"all" | "income" | "expense">("all");
  const { data: txs, isLoading } = useListTransactions();
  const create = useCreateTransaction();
  const del = useDeleteTransaction();

  const [open, setOpen] = useState(false);
  const [type, setType] = useState<"income" | "expense">("expense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [merchant, setMerchant] = useState("");
  const [description, setDescription] = useState("");

  const reset = () => {
    setAmount("");
    setCategory("");
    setMerchant("");
    setDescription("");
    setType("expense");
  };

  const refetch = () => {
    qc.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const handleCreate = () => {
    if (!amount || !category) return;
    create.mutate(
      {
        data: {
          type,
          amount: parseFloat(amount),
          category,
          merchant: merchant || undefined,
          description: description || undefined,
          occurredAt: new Date().toISOString(),
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          reset();
        },
      },
    );
  };

  const filtered = useMemo(
    () => (txs ?? []).filter((tx) => filter === "all" || tx.type === filter),
    [txs, filter],
  );
  const totalIn = useMemo(
    () => (txs ?? []).filter((tx) => tx.type === "income").reduce((s, tx) => s + tx.amount, 0),
    [txs],
  );
  const totalOut = useMemo(
    () => (txs ?? []).filter((tx) => tx.type === "expense").reduce((s, tx) => s + tx.amount, 0),
    [txs],
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-muted-foreground">
          {t("budget.tx.subtitle")}
        </p>
        <Dialog
          open={open}
          onOpenChange={(o) => {
            setOpen(o);
            if (!o) reset();
          }}
        >
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> {t("tx.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{t("tx.new")}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="flex gap-2">
                {(["expense", "income"] as const).map((tk) => (
                  <button
                    key={tk}
                    onClick={() => setType(tk)}
                    className={`flex-1 py-2 rounded-xl text-sm font-semibold transition ${
                      type === tk
                        ? "bg-primary text-primary-foreground"
                        : "bg-background border border-border text-muted-foreground"
                    }`}
                  >
                    {tk === "income" ? t("common.income") : t("common.expense")}
                  </button>
                ))}
              </div>
              <Input
                type="number"
                step="0.01"
                placeholder={t("common.amount")}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <Input
                placeholder={t("tx.category")}
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              />
              <Input
                placeholder={t("tx.merchantOptional")}
                value={merchant}
                onChange={(e) => setMerchant(e.target.value)}
              />
              <Input
                placeholder={t("tx.descriptionOptional")}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>
                {t("common.cancel")}
              </Button>
              <Button onClick={handleCreate} disabled={!amount || !category}>
                {t("common.save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TxSummaryTile label={t("common.income")} amount={totalIn} color={MINT} kind="income" />
        <TxSummaryTile label={t("common.expense")} amount={totalOut} color={LAVENDER} kind="expense" />
      </div>

      <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <div className="flex gap-1 bg-white/[0.04] rounded-full p-1">
              {(["all", "income", "expense"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition ${
                    filter === f
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground"
                  }`}
                >
                  {t(`tx.filter.${f}` as any)}
                </button>
              ))}
            </div>
          </div>
          <p className="text-xs text-muted-foreground">{t("budget.tx.entries", { n: filtered.length })}</p>
        </div>

        {isLoading ? (
          <p className="text-muted-foreground text-sm py-4">{t("common.loading")}</p>
        ) : filtered.length === 0 ? (
          <p className="text-muted-foreground text-sm py-8 text-center">
            {t("tx.empty")}
          </p>
        ) : (
          <div className="divide-y divide-white/[0.05]">
            {filtered.map((tx) => (
              <div key={tx.id} className="flex items-center gap-4 py-3 group">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{
                    background:
                      tx.type === "income"
                        ? "rgba(124,240,189,0.14)"
                        : "rgba(168,155,245,0.14)",
                    color: tx.type === "income" ? MINT : LAVENDER,
                  }}
                >
                  {tx.type === "income" ? (
                    <ArrowUpRight className="w-5 h-5" />
                  ) : (
                    <ArrowDownRight className="w-5 h-5" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">
                    {tx.merchant ?? tx.description ?? tx.category}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {tx.category} · {formatShortDate(tx.occurredAt)}
                  </p>
                </div>
                <div
                  className={`text-base font-semibold tabular-nums ${
                    tx.type === "income" ? "text-primary" : ""
                  }`}
                >
                  {tx.type === "income" ? "+" : "-"}
                  {formatCurrency(tx.amount)}
                </div>
                <button
                  onClick={() =>
                    del.mutate({ id: tx.id }, { onSuccess: refetch })
                  }
                  className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TxSummaryTile({
  label,
  amount,
  color,
  kind,
}: {
  label: string;
  amount: number;
  color: string;
  kind: "income" | "expense";
}) {
  return (
    <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6 flex items-center gap-4">
      <div
        className="w-12 h-12 rounded-2xl flex items-center justify-center"
        style={{ background: `${color}22`, color }}
      >
        {kind === "income" ? (
          <ArrowUpRight className="w-6 h-6" />
        ) : (
          <ArrowDownRight className="w-6 h-6" />
        )}
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
        <p className="text-2xl font-bold tracking-tight tabular-nums">{formatCurrency(amount)}</p>
      </div>
    </div>
  );
}

/* ------------------------- Accounts ------------------------- */

function AccountsTab() {
  const t = useT();
  const qc = useQueryClient();
  const { data: accounts, isLoading } = useListAccounts();
  const createAccount = useCreateAccount();
  const deleteAccount = useDeleteAccount();

  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState("");
  const [kind, setKind] = useState("checking");
  const [balance, setBalance] = useState("");
  const [cardLast4, setCardLast4] = useState("");

  const refetch = () => {
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const reset = () => {
    setName("");
    setKind("checking");
    setBalance("");
    setCardLast4("");
  };

  const handleCreate = () => {
    if (!name || !balance) return;
    createAccount.mutate(
      {
        data: {
          name,
          kind,
          balance: parseFloat(balance),
          currency: "USD",
          cardLast4: cardLast4 || undefined,
        },
      },
      {
        onSuccess: () => {
          refetch();
          setIsOpen(false);
          reset();
        },
      },
    );
  };

  const handleDelete = (id: number) => {
    deleteAccount.mutate({ id }, { onSuccess: refetch });
  };

  const totalBalance = (accounts ?? []).reduce((sum, acc) => sum + acc.balance, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-muted-foreground">
          {t("budget.acc.subtitle")}
        </p>
        <Dialog
          open={isOpen}
          onOpenChange={(o) => {
            setIsOpen(o);
            if (!o) reset();
          }}
        >
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> {t("budget.acc.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{t("acc.title")}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">{t("acc.name")}</label>
                <Input
                  placeholder={t("acc.namePlaceholder")}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">{t("acc.type")}</label>
                  <select
                    className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    value={kind}
                    onChange={(e) => setKind(e.target.value)}
                  >
                    <option value="checking">{t("acc.kind.checking")}</option>
                    <option value="savings">{t("acc.kind.savings")}</option>
                    <option value="credit">{t("acc.kind.credit")}</option>
                    <option value="cash">{t("acc.kind.cash")}</option>
                    <option value="crypto">{t("acc.kind.crypto")}</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">{t("acc.currentBalance")}</label>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={balance}
                    onChange={(e) => setBalance(e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">{t("acc.cardLast4")}</label>
                <Input
                  placeholder="1234"
                  maxLength={4}
                  value={cardLast4}
                  onChange={(e) => setCardLast4(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                {t("common.cancel")}
              </Button>
              <Button onClick={handleCreate} disabled={!name || !balance}>
                {t("common.save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-2xl bg-white/[0.03] border border-white/[0.06] p-6 flex items-center justify-between">
        <div>
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">
            {t("acc.totalBalance")}
          </p>
          <h2 className="text-4xl font-bold tracking-tight text-primary tabular-nums">
            {formatCurrency(totalBalance)}
          </h2>
        </div>
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          <Wallet className="w-8 h-8" />
        </div>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">{t("common.loading")}</p>
      ) : (accounts ?? []).length === 0 ? (
        <div className="text-center py-16 bg-white/[0.02] border border-white/[0.05] rounded-2xl">
          <Building2 className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">{t("acc.empty")}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(accounts ?? []).map((account) => (
            <AccountCard key={account.id} account={account} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </div>
  );
}

function AccountCard({
  account,
  onDelete,
}: {
  account: { id: number; name: string; kind: string; balance: number; currency: string; cardLast4?: string | null };
  onDelete: (id: number) => void;
}) {
  const t = useT();
  const getIcon = () => {
    switch (account.kind) {
      case "credit":
        return <CreditCard className="w-6 h-6" />;
      case "cash":
        return <Wallet className="w-6 h-6" />;
      case "crypto":
        return <Bitcoin className="w-6 h-6" />;
      default:
        return <Building2 className="w-6 h-6" />;
    }
  };

  return (
    <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5 hover:border-primary/30 transition-all duration-300 group flex flex-col justify-between min-h-[160px] relative overflow-hidden">
      <div className="absolute -right-8 -top-8 w-32 h-32 bg-primary/5 rounded-full blur-2xl pointer-events-none" />
      <div className="flex justify-between items-start z-10">
        <div className="w-12 h-12 rounded-xl bg-white/[0.04] border border-white/[0.05] flex items-center justify-center text-muted-foreground">
          {getIcon()}
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity p-1">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-[#0d1a18] border-white/10">
            <DropdownMenuItem
              className="text-destructive focus:bg-destructive/10 focus:text-destructive cursor-pointer"
              onClick={() => onDelete(account.id)}
            >
              <Trash2 className="w-4 h-4 mr-2" /> {t("common.delete")}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <div className="mt-4 z-10">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="font-semibold text-lg">{account.name}</h3>
          {account.cardLast4 && (
            <span className="text-xs px-2 py-0.5 rounded-md bg-white/5 border border-white/[0.05] text-muted-foreground">
              •••{account.cardLast4}
            </span>
          )}
        </div>
        <p className="text-2xl font-bold tracking-tight tabular-nums">
          {formatCurrency(account.balance, account.currency)}
        </p>
        <p className="text-[11px] text-muted-foreground mt-1">{t(`acc.kind.${account.kind}` as any) || account.kind}</p>
      </div>
    </div>
  );
}

/* ------------------------- Mandatory ------------------------- */

function MandatoryTab() {
  const t = useT();
  const queryClient = useQueryClient();
  const { data: items } = useListMandatoryExpenses();
  const create = useCreateMandatoryExpense();
  const remove = useDeleteMandatoryExpense();
  const pay = usePayMandatoryExpense();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDay, setDueDay] = useState("1");
  const [category, setCategory] = useState("Bills");

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getListMandatoryExpensesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const handleCreate = () => {
    if (!name || !amount) return;
    create.mutate(
      {
        data: {
          name,
          amount: Number(amount),
          dueDay: Number(dueDay),
          category,
          color: "#F2C879",
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          setName("");
          setAmount("");
          setDueDay("1");
          setCategory("Bills");
        },
      },
    );
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">
          {t("budget.mn.subtitle")}
        </p>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> {t("budget.mn.new")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{t("budget.mn.dialogTitle")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder={t("budget.mn.namePlaceholder")} value={name} onChange={(e) => setName(e.target.value)} />
              <Input
                placeholder={t("common.amount")}
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <Input
                placeholder={t("budget.mn.dueDayPlaceholder")}
                type="number"
                min={1}
                max={28}
                value={dueDay}
                onChange={(e) => setDueDay(e.target.value)}
              />
              <Input placeholder={t("budget.mn.categoryPlaceholder")} value={category} onChange={(e) => setCategory(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={create.isPending}>
                {create.isPending ? t("common.saving") : t("common.save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(items ?? []).map((m) => {
          const remaining = Math.max(0, m.amount - m.paidThisMonth);
          const fullyPaid = remaining === 0 && m.amount > 0;
          return (
            <div
              key={m.id}
              className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{
                      background: (m.color ?? "#F2C879") + "26",
                      color: m.color ?? "#F2C879",
                    }}
                  >
                    <CalendarDays className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-semibold">{m.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {t("budget.mn.day", { day: m.dueDay })} • {m.category ?? t("budget.mn.categoryPlaceholder")}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => remove.mutate({ id: m.id }, { onSuccess: refetch })}
                  className="text-muted-foreground hover:text-destructive p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-baseline justify-between mb-3">
                <p className="text-2xl font-bold tabular-nums">
                  {formatCurrency(m.amount, m.currency)}
                </p>
                <p className={`text-xs font-semibold ${fullyPaid ? "text-primary" : "text-muted-foreground"}`}>
                  {fullyPaid ? t("budget.mn.paid") : t("budget.mn.due", { amount: formatCurrency(remaining, m.currency) })}
                </p>
              </div>
              <button
                onClick={() => pay.mutate({ id: m.id, data: {} }, { onSuccess: refetch })}
                disabled={fullyPaid || pay.isPending}
                className={`w-full py-2 rounded-2xl text-sm font-semibold transition-all ${
                  fullyPaid
                    ? "bg-primary/20 text-primary cursor-default"
                    : "bg-primary text-[#0a1f17] hover:brightness-110"
                }`}
              >
                {fullyPaid ? (
                  <span className="inline-flex items-center gap-2">
                    <Check className="w-4 h-4" /> {t("budget.mn.paidLabel")}
                  </span>
                ) : (
                  t("budget.mn.markPaid")
                )}
              </button>
            </div>
          );
        })}
        {(items ?? []).length === 0 && (
          <div className="md:col-span-2 text-center py-12 text-muted-foreground text-sm">
            {t("budget.mn.empty")}
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------- Debts ------------------------- */

function DebtsTab() {
  const t = useT();
  const queryClient = useQueryClient();
  const { data: items } = useListDebts();
  const create = useCreateDebt();
  const update = useUpdateDebt();
  const remove = useDeleteDebt();

  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<"debt" | "credit">("debt");
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [lender, setLender] = useState("");
  const [notes, setNotes] = useState("");

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getListDebtsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const handleCreate = () => {
    if (!name || !amount) return;
    create.mutate(
      {
        data: {
          name,
          kind,
          originalAmount: Number(amount),
          lender: lender || null,
          notes: notes || null,
          color: kind === "debt" ? "#F291C8" : LAVENDER,
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          setName("");
          setAmount("");
          setLender("");
          setNotes("");
        },
      },
    );
  };

  const handleAddPayment = (debtId: number, currentPaid: number, amount: string) => {
    const v = Number(amount);
    if (!v) return;
    update.mutate(
      { id: debtId, data: { paidAmount: currentPaid + v } },
      { onSuccess: refetch },
    );
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">
          {t("budget.dt.subtitle")}
        </p>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> {t("budget.dt.new")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{t("budget.dt.dialogTitle")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <div className="flex gap-2">
                <button
                  onClick={() => setKind("debt")}
                  className={`flex-1 py-2 rounded-2xl text-sm font-semibold ${
                    kind === "debt" ? "bg-[#F291C8] text-[#0a1f17]" : "bg-white/[0.04]"
                  }`}
                >
                  {t("budget.dt.iOwe")}
                </button>
                <button
                  onClick={() => setKind("credit")}
                  className={`flex-1 py-2 rounded-2xl text-sm font-semibold ${
                    kind === "credit" ? "bg-secondary text-[#0a1f17]" : "bg-white/[0.04]"
                  }`}
                >
                  {t("budget.dt.owedToMe")}
                </button>
              </div>
              <Input placeholder={t("budget.dt.descPlaceholder")} value={name} onChange={(e) => setName(e.target.value)} />
              <Input
                placeholder={t("common.amount")}
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <Input placeholder={t("budget.dt.counterparty")} value={lender} onChange={(e) => setLender(e.target.value)} />
              <Textarea placeholder={t("budget.dt.notes")} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={create.isPending}>
                {create.isPending ? t("common.saving") : t("common.save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(items ?? []).map((d) => {
          const pct = d.originalAmount > 0
            ? Math.min(100, (d.paidAmount / d.originalAmount) * 100)
            : 0;
          const isDebt = d.kind === "debt";
          return (
            <div
              key={d.id}
              className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <span
                    className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full"
                    style={{
                      background: isDebt ? "rgba(242,145,200,0.18)" : "rgba(168,155,245,0.18)",
                      color: isDebt ? "#F291C8" : LAVENDER,
                    }}
                  >
                    {isDebt ? t("budget.dt.iOweShort") : t("budget.dt.owedShort")}
                  </span>
                  <p className="font-semibold mt-2">{d.name}</p>
                  {d.lender && <p className="text-[11px] text-muted-foreground">{d.lender}</p>}
                </div>
                <button
                  onClick={() => remove.mutate({ id: d.id }, { onSuccess: refetch })}
                  className="text-muted-foreground hover:text-destructive p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <p className="text-2xl font-bold tabular-nums">
                {formatCurrency(d.remaining, d.currency)}
              </p>
              <p className="text-[11px] text-muted-foreground tabular-nums">
                {t("budget.dt.paidOf", { paid: formatCurrency(d.paidAmount, d.currency), total: formatCurrency(d.originalAmount, d.currency) })}
              </p>
              <div className="h-1.5 rounded-full bg-white/[0.06] mt-2 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${pct}%`,
                    background: isDebt ? "#F291C8" : LAVENDER,
                  }}
                />
              </div>
              {d.remaining > 0 && (
                <PaymentInput onAdd={(amt) => handleAddPayment(d.id, d.paidAmount, amt)} />
              )}
            </div>
          );
        })}
        {(items ?? []).length === 0 && (
          <div className="md:col-span-2 text-center py-12 text-muted-foreground text-sm">
            {t("budget.dt.empty")}
          </div>
        )}
      </div>
    </div>
  );
}

function PaymentInput({ onAdd }: { onAdd: (amount: string) => void }) {
  const t = useT();
  const [val, setVal] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (val) {
          onAdd(val);
          setVal("");
        }
      }}
      className="flex gap-2 mt-3"
    >
      <Input
        placeholder={t("budget.dt.addPaymentPlaceholder")}
        type="number"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        className="h-9"
      />
      <Button type="submit" size="sm" disabled={!val}>
        {t("common.add")}
      </Button>
    </form>
  );
}
