import { useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListWorkouts,
  useCreateWorkout,
  useDeleteWorkout,
  useCreateExercise,
  useDeleteExercise,
  useGetBodySummary,
  useListBodyMetrics,
  useCreateBodyMetric,
  useDeleteBodyMetric,
  getListWorkoutsQueryKey,
  getListEventsQueryKey,
  getListBodyMetricsQueryKey,
  getGetBodySummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Plus,
  Trash2,
  Dumbbell,
  Activity,
  ChevronRight,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { formatShortDate } from "@/lib/utils";
import { useT, useI18n, localeFor } from "@/lib/i18n";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

type Tab = "workouts" | "body";

export default function Workouts() {
  const t = useT();
  const [tab, setTab] = useState<Tab>("workouts");

  return (
    <Layout>
      <div className="flex flex-col gap-2 mb-6 mt-2">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">{t("workouts.title")}</h1>
        <p className="text-sm text-muted-foreground">
          {t("workouts.subtitle")}
        </p>
      </div>

      <div className="flex flex-wrap gap-2 mb-6 border-b border-white/[0.06] pb-1">
        {(["workouts", "body"] as Tab[]).map((tab2) => (
          <button
            key={tab2}
            onClick={() => setTab(tab2)}
            className={`px-4 py-2 text-sm font-medium rounded-full transition-all flex items-center gap-2 ${
              tab === tab2
                ? "bg-white text-[#0a1f17]"
                : "text-muted-foreground hover:text-foreground hover:bg-white/[0.04]"
            }`}
          >
            {tab2 === "workouts" ? (
              <>
                <Dumbbell className="w-4 h-4" /> {t("workouts.tab.workouts")}
              </>
            ) : (
              <>
                <Activity className="w-4 h-4" /> {t("workouts.tab.body")}
              </>
            )}
          </button>
        ))}
      </div>

      {tab === "workouts" ? <WorkoutsTab /> : <BodyTab />}
    </Layout>
  );
}

/* ------------------------- Workouts ------------------------- */

function WorkoutsTab() {
  const t = useT();
  const { lang } = useI18n();
  const locale = localeFor(lang);
  const queryClient = useQueryClient();
  const { data: workouts } = useListWorkouts();
  const { data: bodySummary } = useGetBodySummary();
  const create = useCreateWorkout();
  const remove = useDeleteWorkout();
  const addExercise = useCreateExercise();
  const removeExercise = useDeleteExercise();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [scheduledAt, setScheduledAt] = useState(() => {
    const d = new Date();
    d.setMinutes(0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [duration, setDuration] = useState("60");
  const [notes, setNotes] = useState("");
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getListWorkoutsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
  };

  const handleCreate = () => {
    if (!name) return;
    create.mutate(
      {
        data: {
          name,
          scheduledAt: new Date(scheduledAt).toISOString() as any,
          durationMin: Number(duration),
          notes: notes || null,
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          setName("");
          setNotes("");
        },
      },
    );
  };

  return (
    <div>
      <div className="flex items-end justify-between mb-6">
        <p className="text-sm text-muted-foreground">
          {t("workouts.subtitle2")}
        </p>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> {t("workouts.new")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{t("workouts.schedule")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder={t("workouts.namePlaceholder")} value={name} onChange={(e) => setName(e.target.value)} />
              <Input type="datetime-local" value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} />
              <Input
                placeholder={t("workouts.duration")}
                type="number"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
              />
              <Textarea placeholder={t("common.notesOptional")} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={create.isPending}>
                {create.isPending ? t("common.saving") : t("common.save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-3">
          {(workouts ?? []).map((w) => {
            const expanded = expandedId === w.id;
            return (
              <div
                key={w.id}
                className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <button
                    onClick={() => setExpandedId(expanded ? null : w.id)}
                    className="flex items-center gap-3 text-left flex-1 min-w-0"
                  >
                    <div
                      className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0"
                      style={{ background: "rgba(124,240,189,0.14)", color: MINT }}
                    >
                      <Dumbbell className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold truncate">{w.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {new Date(w.scheduledAt).toLocaleString(locale, {
                          weekday: "short",
                          month: "short",
                          day: "numeric",
                          hour: "numeric",
                          minute: "2-digit",
                        })}
                        {w.durationMin && ` • ${w.durationMin}${t("common.min")}`}
                        {" • "}
                        {w.exercises.length} {t("workouts.exercises").toLowerCase()}
                      </p>
                    </div>
                    <ChevronRight
                      className={`w-4 h-4 text-muted-foreground transition-transform ml-auto ${expanded ? "rotate-90" : ""}`}
                    />
                  </button>
                  <button
                    onClick={() => remove.mutate({ id: w.id }, { onSuccess: refetch })}
                    className="text-muted-foreground hover:text-destructive p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                {expanded && (
                  <div className="mt-4 pt-4 border-t border-white/[0.06] space-y-2">
                    {w.exercises.map((ex) => (
                      <div key={ex.id} className="flex items-center gap-3 p-2 rounded-xl bg-white/[0.02]">
                        <div className="flex-1">
                          <p className="text-sm font-medium">{ex.name}</p>
                          <p className="text-[11px] text-muted-foreground">
                            {ex.sets} × {ex.reps}
                            {ex.weightKg && ` @ ${ex.weightKg} kg`}
                          </p>
                        </div>
                        <button
                          onClick={() => removeExercise.mutate({ exerciseId: ex.id }, { onSuccess: refetch })}
                          className="text-muted-foreground hover:text-destructive p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                    {w.exercises.length === 0 && (
                      <p className="text-xs text-muted-foreground text-center py-2">
                        {t("workouts.exercises")} —
                      </p>
                    )}
                    <ExerciseForm
                      onAdd={(name, sets, reps, weight) =>
                        addExercise.mutate(
                          {
                            data: {
                              sessionId: w.id,
                              name,
                              sets: Number(sets),
                              reps: Number(reps),
                              weightKg: weight ? Number(weight) : null,
                            },
                          },
                          { onSuccess: refetch },
                        )
                      }
                    />
                  </div>
                )}
              </div>
            );
          })}
          {(workouts ?? []).length === 0 && (
            <div className="text-center py-12 text-muted-foreground text-sm">
              {t("workouts.empty")}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5">
            <div className="flex items-center gap-2 mb-3">
              <Activity className="w-4 h-4" style={{ color: MINT }} />
              <h3 className="font-semibold tracking-tight">{t("workouts.tab.body")}</h3>
            </div>
            {bodySummary?.latest ? (
              <div className="space-y-2">
                <Stat label={t("workouts.body.weight")} value={bodySummary.latest.weightKg} unit="" delta={bodySummary.weightDelta30 ?? undefined} />
                <Stat label={t("workouts.body.bodyFat")} value={bodySummary.latest.bodyFatPct} unit="" delta={bodySummary.bodyFatDelta30 ?? undefined} />
                <Stat label={t("workouts.body.muscle")} value={bodySummary.latest.musclePct} unit="" />
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">{t("workouts.body.empty")}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  unit,
  delta,
}: {
  label: string;
  value: number | null | undefined;
  unit: string;
  delta?: number;
}) {
  if (value === null || value === undefined) return null;
  return (
    <div className="flex items-baseline justify-between">
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="flex items-baseline gap-2">
        <span className="text-lg font-bold tabular-nums">
          {value}
          <span className="text-xs text-muted-foreground ml-1">{unit}</span>
        </span>
        {delta !== undefined && (
          <span
            className={`text-[10px] font-semibold tabular-nums ${
              delta < 0 ? "text-primary" : delta > 0 ? "text-destructive" : "text-muted-foreground"
            }`}
          >
            {delta > 0 ? "+" : ""}
            {delta.toFixed(1)}
          </span>
        )}
      </div>
    </div>
  );
}

function ExerciseForm({
  onAdd,
}: {
  onAdd: (name: string, sets: string, reps: string, weight: string) => void;
}) {
  const t = useT();
  const [name, setName] = useState("");
  const [sets, setSets] = useState("3");
  const [reps, setReps] = useState("10");
  const [weight, setWeight] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!name) return;
        onAdd(name, sets, reps, weight);
        setName("");
        setWeight("");
      }}
      className="flex flex-wrap gap-2 pt-2"
    >
      <Input
        placeholder={t("workouts.exerciseName")}
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="flex-1 min-w-[160px] h-9"
      />
      <Input placeholder={t("workouts.sets")} type="number" value={sets} onChange={(e) => setSets(e.target.value)} className="w-16 h-9" />
      <Input placeholder={t("workouts.reps")} type="number" value={reps} onChange={(e) => setReps(e.target.value)} className="w-16 h-9" />
      <Input placeholder="kg" type="number" value={weight} onChange={(e) => setWeight(e.target.value)} className="w-20 h-9" />
      <Button type="submit" size="sm" disabled={!name}>
        {t("common.add")}
      </Button>
    </form>
  );
}

/* ------------------------- Body ------------------------- */

function BodyTab() {
  const t = useT();
  const qc = useQueryClient();
  const { data: metrics } = useListBodyMetrics();
  const { data: summary } = useGetBodySummary();
  const create = useCreateBodyMetric();
  const del = useDeleteBodyMetric();

  const [open, setOpen] = useState(false);
  const [recordedAt, setMeasuredAt] = useState(new Date().toISOString().slice(0, 10));
  const [weightKg, setWeightKg] = useState("");
  const [bodyFatPct, setBodyFatPct] = useState("");
  const [waistCm, setWaistCm] = useState("");
  const [chestCm, setChestCm] = useState("");
  const [hipsCm, setHipsCm] = useState("");
  const [notes, setNotes] = useState("");

  const reset = () => {
    setMeasuredAt(new Date().toISOString().slice(0, 10));
    setWeightKg("");
    setBodyFatPct("");
    setWaistCm("");
    setChestCm("");
    setHipsCm("");
    setNotes("");
  };

  const refetch = () => {
    qc.invalidateQueries({ queryKey: getListBodyMetricsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetBodySummaryQueryKey() });
  };

  const handleCreate = () => {
    if (!weightKg) return;
    create.mutate(
      {
        data: {
          recordedAt,
          weightKg: parseFloat(weightKg),
          bodyFatPct: bodyFatPct ? parseFloat(bodyFatPct) : undefined,
          waistCm: waistCm ? parseFloat(waistCm) : undefined,
          chestCm: chestCm ? parseFloat(chestCm) : undefined,
          hipsCm: hipsCm ? parseFloat(hipsCm) : undefined,
          notes: notes || undefined,
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          reset();
        },
      },
    );
  };

  const chartData = useMemo(
    () =>
      [...(metrics ?? [])]
        .sort((a, b) => new Date(a.recordedAt).getTime() - new Date(b.recordedAt).getTime())
        .map((m) => ({
          date: formatShortDate(m.recordedAt),
          weight: m.weightKg,
          fat: m.bodyFatPct ?? null,
        })),
    [metrics],
  );

  const change = summary?.weightDelta30 ?? 0;
  const changePositive = change <= 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-muted-foreground">
          {t("workouts.body.subtitle")}
        </p>
        <Dialog
          open={open}
          onOpenChange={(o) => {
            setOpen(o);
            if (!o) reset();
          }}
        >
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" /> {t("workouts.body.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{t("workouts.body.new")}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-3 py-4">
              <Input type="date" value={recordedAt} onChange={(e) => setMeasuredAt(e.target.value)} />
              <div className="grid grid-cols-2 gap-3">
                <Input
                  type="number"
                  step="0.1"
                  placeholder={t("workouts.body.weight")}
                  value={weightKg}
                  onChange={(e) => setWeightKg(e.target.value)}
                />
                <Input
                  type="number"
                  step="0.1"
                  placeholder={t("workouts.body.bodyFat")}
                  value={bodyFatPct}
                  onChange={(e) => setBodyFatPct(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <Input
                  type="number"
                  step="0.1"
                  placeholder={t("workouts.body.waist")}
                  value={waistCm}
                  onChange={(e) => setWaistCm(e.target.value)}
                />
                <Input
                  type="number"
                  step="0.1"
                  placeholder={t("workouts.body.chest")}
                  value={chestCm}
                  onChange={(e) => setChestCm(e.target.value)}
                />
                <Input
                  type="number"
                  step="0.1"
                  placeholder={t("workouts.body.hips")}
                  value={hipsCm}
                  onChange={(e) => setHipsCm(e.target.value)}
                />
              </div>
              <Input placeholder={t("common.notesOptional")} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>
                {t("common.cancel")}
              </Button>
              <Button onClick={handleCreate} disabled={!weightKg}>
                {t("common.save")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <BodyStatCard
          label={t("workouts.body.weight")}
          value={summary?.latest?.weightKg ? `${summary.latest!.weightKg!.toFixed(1)}` : "—"}
          change={change !== 0 ? `${change > 0 ? "+" : ""}${change.toFixed(1)}` : "—"}
          positive={changePositive}
          color={MINT}
        />
        <BodyStatCard
          label={t("workouts.body.bodyFat")}
          value={
            summary?.latest?.bodyFatPct ? `${summary.latest!.bodyFatPct!.toFixed(1)}%` : "—"
          }
          change="—"
          positive
          color={LAVENDER}
        />
        <BodyStatCard
          label={t("common.entries")}
          value={`${metrics?.length ?? 0}`}
          change="—"
          positive
          color="#5EC9F2"
        />
      </div>

      <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6">
        <h3 className="font-semibold mb-4">{t("workouts.body.weight")}</h3>
        {chartData.length < 2 ? (
          <p className="text-muted-foreground text-sm py-12 text-center">
            {t("workouts.body.empty")}
          </p>
        ) : (
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.4)" fontSize={11} />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} domain={["auto", "auto"]} />
                <Tooltip
                  contentStyle={{
                    background: "rgba(15,30,32,0.95)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: "12px",
                    fontSize: "12px",
                  }}
                />
                <Line type="monotone" dataKey="weight" stroke={MINT} strokeWidth={3} dot={{ r: 4, fill: MINT }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6">
        <h3 className="font-semibold mb-4">{t("workouts.body.history")}</h3>
        {(metrics ?? []).length === 0 ? (
          <p className="text-muted-foreground text-sm py-6 text-center">
            {t("workouts.body.empty")}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground uppercase tracking-wider">
                  <th className="pb-3 font-medium">{t("common.date")}</th>
                  <th className="pb-3 font-medium">{t("workouts.body.weight")}</th>
                  <th className="pb-3 font-medium">{t("workouts.body.bodyFat")}</th>
                  <th className="pb-3 font-medium">{t("workouts.body.waist")}</th>
                  <th className="pb-3 font-medium">{t("workouts.body.chest")}</th>
                  <th className="pb-3 font-medium">{t("workouts.body.hips")}</th>
                  <th className="pb-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {[...(metrics ?? [])]
                  .sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime())
                  .map((m) => (
                    <tr key={m.id} className="border-t border-white/[0.05] group">
                      <td className="py-3">{formatShortDate(m.recordedAt)}</td>
                      <td className="py-3 font-semibold">{m.weightKg} kg</td>
                      <td className="py-3">{m.bodyFatPct != null ? `${m.bodyFatPct}%` : "—"}</td>
                      <td className="py-3">{m.waistCm != null ? `${m.waistCm} cm` : "—"}</td>
                      <td className="py-3">{m.chestCm != null ? `${m.chestCm} cm` : "—"}</td>
                      <td className="py-3">{m.hipsCm != null ? `${m.hipsCm} cm` : "—"}</td>
                      <td className="py-3 text-right">
                        <button
                          onClick={() => del.mutate({ id: m.id }, { onSuccess: refetch })}
                          className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function BodyStatCard({
  label,
  value,
  change,
  positive,
  color,
}: {
  label: string;
  value: string;
  change: string;
  positive: boolean;
  color: string;
}) {
  return (
    <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6 flex items-center gap-4">
      <div
        className="w-12 h-12 rounded-2xl flex items-center justify-center"
        style={{ background: `${color}22`, color }}
      >
        <Activity className="w-6 h-6" />
      </div>
      <div className="flex-1">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
        <p className="text-2xl font-bold tracking-tight tabular-nums">{value}</p>
        <p
          className={`text-xs mt-0.5 flex items-center gap-1 ${
            positive ? "text-primary" : "text-destructive"
          }`}
        >
          {positive ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
          {change}
        </p>
      </div>
    </div>
  );
}
