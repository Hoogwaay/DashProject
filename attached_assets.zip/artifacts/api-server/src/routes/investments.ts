import { Router, type IRouter } from "express";
import { db, investmentsTable } from "@workspace/db";
import { CreateInvestmentBody } from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

const KIND_COLORS: Record<string, string> = {
  stock: "#7CF0BD",
  crypto: "#A89BF5",
  etf: "#5BD7A2",
  bond: "#5EC9F2",
  real_estate: "#F2C879",
  other: "#9CA3AF",
};

function serialize(row: typeof investmentsTable.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    ticker: row.ticker,
    kind: row.kind,
    quantity: Number(row.quantity),
    buyPrice: Number(row.buyPrice),
    currentPrice: Number(row.currentPrice),
    purchasedAt: row.purchasedAt,
  };
}

router.get("/investments", async (_req, res) => {
  const rows = await db
    .select()
    .from(investmentsTable)
    .orderBy(desc(investmentsTable.purchasedAt));
  res.json(rows.map(serialize));
});

router.post("/investments", async (req, res) => {
  const body = CreateInvestmentBody.parse(req.body);
  const [row] = await db
    .insert(investmentsTable)
    .values({
      name: body.name,
      ticker: body.ticker ?? null,
      kind: body.kind,
      quantity: String(body.quantity),
      buyPrice: String(body.buyPrice),
      currentPrice: String(body.currentPrice),
      purchasedAt: body.purchasedAt
        ? (typeof body.purchasedAt === "string"
          ? body.purchasedAt
          : (body.purchasedAt as Date).toISOString().slice(0, 10))
        : new Date().toISOString().slice(0, 10),
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.delete("/investments/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(investmentsTable).where(eq(investmentsTable.id, id));
  res.status(204).end();
});

router.get("/investments/summary", async (_req, res) => {
  const rows = await db.select().from(investmentsTable);
  let totalCost = 0;
  let totalValue = 0;
  const byKind = new Map<string, number>();
  for (const r of rows) {
    const qty = Number(r.quantity);
    const cost = qty * Number(r.buyPrice);
    const value = qty * Number(r.currentPrice);
    totalCost += cost;
    totalValue += value;
    byKind.set(r.kind, (byKind.get(r.kind) ?? 0) + value);
  }
  const profit = totalValue - totalCost;
  const profitPct = totalCost > 0 ? (profit / totalCost) * 100 : 0;
  const breakdown = [...byKind.entries()].map(([kind, value]) => ({
    kind,
    value,
    color: KIND_COLORS[kind] ?? "#9CA3AF",
  }));
  res.json({
    totalCost,
    totalValue,
    profit,
    profitPct,
    breakdown,
  });
});

export default router;
