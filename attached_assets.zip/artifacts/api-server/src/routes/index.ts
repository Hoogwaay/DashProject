import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import transactionsRouter from "./transactions";
import notesRouter from "./notes";
import investmentsRouter from "./investments";
import accountsRouter from "./accounts";
import forecastRouter from "./forecast";
import eventsRouter from "./events";
import bodyRouter from "./body";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(transactionsRouter);
router.use(notesRouter);
router.use(investmentsRouter);
router.use(accountsRouter);
router.use(forecastRouter);
router.use(eventsRouter);
router.use(bodyRouter);

export default router;
