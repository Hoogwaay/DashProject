import { Router, type IRouter } from "express";
import { db, notesTable } from "@workspace/db";
import { CreateNoteBody, UpdateNoteBody } from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof notesTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    color: row.color,
    pinned: row.pinned,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/notes", async (_req, res) => {
  const rows = await db
    .select()
    .from(notesTable)
    .orderBy(desc(notesTable.pinned), desc(notesTable.updatedAt));
  res.json(rows.map(serialize));
});

router.post("/notes", async (req, res) => {
  const body = CreateNoteBody.parse(req.body);
  const [row] = await db
    .insert(notesTable)
    .values({
      title: body.title,
      content: body.content,
      color: body.color ?? null,
      pinned: body.pinned ?? false,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.patch("/notes/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateNoteBody.parse(req.body);
  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (body.title !== undefined && body.title !== null) updates.title = body.title;
  if (body.content !== undefined && body.content !== null) updates.content = body.content;
  if (body.color !== undefined) updates.color = body.color;
  if (body.pinned !== undefined && body.pinned !== null) updates.pinned = body.pinned;
  const [row] = await db
    .update(notesTable)
    .set(updates)
    .where(eq(notesTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Note not found" });
    return;
  }
  res.json(serialize(row));
});

router.delete("/notes/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(notesTable).where(eq(notesTable.id, id));
  res.status(204).end();
});

export default router;
