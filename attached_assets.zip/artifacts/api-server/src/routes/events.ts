import { Router, type IRouter } from "express";
import { db, eventsTable } from "@workspace/db";
import { CreateEventBody, UpdateEventBody, ListEventsQueryParams } from "@workspace/api-zod";
import { and, asc, eq, gte, lte } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof eventsTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    kind: row.kind,
    scheduledAt: row.scheduledAt.toISOString(),
    durationMin: row.durationMin,
    done: row.done,
    notes: row.notes,
    color: row.color,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/events", async (req, res) => {
  const fromRaw = typeof req.query.from === "string" ? req.query.from : undefined;
  const toRaw = typeof req.query.to === "string" ? req.query.to : undefined;
  const kindRaw = typeof req.query.kind === "string" ? req.query.kind : undefined;
  const where = [];
  if (fromRaw) where.push(gte(eventsTable.scheduledAt, new Date(fromRaw)));
  if (toRaw) where.push(lte(eventsTable.scheduledAt, new Date(toRaw)));
  if (kindRaw && ["task", "workout", "measurement", "note"].includes(kindRaw))
    where.push(eq(eventsTable.kind, kindRaw as "task" | "workout" | "measurement" | "note"));

  const rows = await db
    .select()
    .from(eventsTable)
    .where(where.length ? and(...where) : undefined)
    .orderBy(asc(eventsTable.scheduledAt));
  res.json(rows.map(serialize));
});

router.post("/events", async (req, res) => {
  const body = CreateEventBody.parse(req.body);
  const [row] = await db
    .insert(eventsTable)
    .values({
      title: body.title,
      kind: body.kind,
      scheduledAt: new Date(body.scheduledAt as unknown as string),
      durationMin: body.durationMin ?? null,
      done: body.done ?? false,
      notes: body.notes ?? null,
      color: body.color ?? null,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.patch("/events/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateEventBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.title !== undefined && body.title !== null) updates.title = body.title;
  if (body.scheduledAt !== undefined && body.scheduledAt !== null)
    updates.scheduledAt = new Date(body.scheduledAt as unknown as string);
  if (body.durationMin !== undefined) updates.durationMin = body.durationMin;
  if (body.done !== undefined && body.done !== null) updates.done = body.done;
  if (body.notes !== undefined) updates.notes = body.notes;
  if (body.color !== undefined) updates.color = body.color;
  const [row] = await db
    .update(eventsTable)
    .set(updates)
    .where(eq(eventsTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Event not found" });
    return;
  }
  res.json(serialize(row));
});

router.delete("/events/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(eventsTable).where(eq(eventsTable.id, id));
  res.status(204).end();
});

router.get("/events/upcoming", async (_req, res) => {
  const now = new Date();
  const horizon = new Date(now.getTime() + 14 * 86400000);
  const rows = await db
    .select()
    .from(eventsTable)
    .where(and(gte(eventsTable.scheduledAt, now), lte(eventsTable.scheduledAt, horizon)))
    .orderBy(asc(eventsTable.scheduledAt));
  res.json(rows.map(serialize));
});

export default router;
