import { Router, type IRouter } from "express";
import { db, forecastTable } from "@workspace/db";
import { CreateForecastEntryBody, GetForecastSummaryQueryParams } from "@workspace/api-zod";
import { asc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof forecastTable.$inferSelect) {
  return {
    id: row.id,
    source: row.source,
    amount: Number(row.amount),
    expectedDate: row.expectedDate,
    recurrence: row.recurrence,
    notes: row.notes,
  };
}

router.get("/forecast", async (_req, res) => {
  const rows = await db
    .select()
    .from(forecastTable)
    .orderBy(asc(forecastTable.expectedDate));
  res.json(rows.map(serialize));
});

router.post("/forecast", async (req, res) => {
  const body = CreateForecastEntryBody.parse(req.body);
  const [row] = await db
    .insert(forecastTable)
    .values({
      source: body.source,
      amount: String(body.amount),
      expectedDate:
        typeof body.expectedDate === "string"
          ? body.expectedDate
          : (body.expectedDate as Date).toISOString().slice(0, 10),
      recurrence: body.recurrence ?? "once",
      notes: body.notes ?? null,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.delete("/forecast/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(forecastTable).where(eq(forecastTable.id, id));
  res.status(204).end();
});

router.get("/forecast/summary", async (req, res) => {
  const params = GetForecastSummaryQueryParams.parse(req.query);
  const months = params.months ?? 6;
  const rows = await db.select().from(forecastTable);

  const today = new Date();
  const buckets: { month: string; amount: number }[] = [];
  for (let i = 0; i < months; i++) {
    const d = new Date(today.getFullYear(), today.getMonth() + i, 1);
    buckets.push({
      month: d.toLocaleString("en-US", { month: "short" }),
      amount: 0,
    });
  }

  for (const r of rows) {
    const amount = Number(r.amount);
    const baseDate = new Date(`${r.expectedDate}T00:00:00Z`);
    const recurrence = r.recurrence;

    for (let i = 0; i < months; i++) {
      const monthStart = new Date(today.getFullYear(), today.getMonth() + i, 1);
      const monthEnd = new Date(today.getFullYear(), today.getMonth() + i + 1, 0);

      if (recurrence === "monthly" && baseDate <= monthEnd) {
        buckets[i].amount += amount;
      } else if (recurrence === "weekly" && baseDate <= monthEnd) {
        const days = (monthEnd.getTime() - monthStart.getTime()) / 86400000 + 1;
        buckets[i].amount += amount * (days / 7);
      } else if (recurrence === "yearly") {
        if (
          baseDate.getMonth() === monthStart.getMonth() &&
          baseDate <= monthEnd
        ) {
          buckets[i].amount += amount;
        }
      } else if (recurrence === "once") {
        if (
          baseDate >= monthStart &&
          baseDate <= monthEnd
        ) {
          buckets[i].amount += amount;
        }
      }
    }
  }

  res.json(
    buckets.map((b) => ({ month: b.month, amount: Math.round(b.amount * 100) / 100 })),
  );
});

export default router;
