import { Router, type IRouter } from "express";
import { db, transactionsTable } from "@workspace/db";
import { CreateTransactionBody, ListTransactionsQueryParams } from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof transactionsTable.$inferSelect) {
  return {
    id: row.id,
    type: row.type,
    amount: Number(row.amount),
    category: row.category,
    description: row.description,
    merchant: row.merchant,
    accountId: row.accountId,
    occurredAt: row.occurredAt.toISOString(),
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/transactions", async (req, res) => {
  const params = ListTransactionsQueryParams.parse(req.query);
  const limit = params.limit ?? 50;
  const rows = await db
    .select()
    .from(transactionsTable)
    .where(params.type ? eq(transactionsTable.type, params.type) : undefined)
    .orderBy(desc(transactionsTable.occurredAt))
    .limit(limit);
  res.json(rows.map(serialize));
});

router.post("/transactions", async (req, res) => {
  const body = CreateTransactionBody.parse(req.body);
  const [row] = await db
    .insert(transactionsTable)
    .values({
      type: body.type,
      amount: String(body.amount),
      category: body.category,
      description: body.description ?? null,
      merchant: body.merchant ?? null,
      accountId: body.accountId ?? null,
      occurredAt: body.occurredAt ? new Date(body.occurredAt) : new Date(),
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.delete("/transactions/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(transactionsTable).where(eq(transactionsTable.id, id));
  res.status(204).end();
});

export default router;
