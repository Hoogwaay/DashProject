import { Router, type IRouter } from "express";
import { db, accountsTable } from "@workspace/db";
import { CreateAccountBody } from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof accountsTable.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    kind: row.kind,
    balance: Number(row.balance),
    currency: row.currency,
    cardLast4: row.cardLast4,
    color: row.color,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/accounts", async (_req, res) => {
  const rows = await db
    .select()
    .from(accountsTable)
    .orderBy(desc(accountsTable.balance));
  res.json(rows.map(serialize));
});

router.post("/accounts", async (req, res) => {
  const body = CreateAccountBody.parse(req.body);
  const [row] = await db
    .insert(accountsTable)
    .values({
      name: body.name,
      kind: body.kind,
      balance: String(body.balance),
      currency: body.currency ?? "USD",
      cardLast4: body.cardLast4 ?? null,
      color: body.color ?? null,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.delete("/accounts/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(accountsTable).where(eq(accountsTable.id, id));
  res.status(204).end();
});

export default router;
