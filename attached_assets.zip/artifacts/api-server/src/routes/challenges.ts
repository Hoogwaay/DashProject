import { Router, type IRouter } from "express";
import { db, challengesTable, challengeProgressTable } from "@workspace/db";
import { CreateChallengeBody, UpdateChallengeBody, AddChallengeProgressBody } from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof challengesTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    category: row.category,
    icon: row.icon,
    color: row.color,
    unit: row.unit,
    targetValue: Number(row.targetValue),
    currentValue: Number(row.currentValue),
    startDate: row.startDate.toISOString(),
    endDate: row.endDate.toISOString(),
    status: row.status,
    pinned: row.pinned,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function deriveStatus(current: number, target: number, endDate: Date, currentStatus: string) {
  if (currentStatus === "archived") return "archived";
  if (current >= target) return "completed";
  if (endDate.getTime() < Date.now()) return "failed";
  return "active";
}

router.get("/challenges", async (_req, res) => {
  const rows = await db
    .select()
    .from(challengesTable)
    .orderBy(desc(challengesTable.pinned), desc(challengesTable.createdAt));
  res.json(rows.map(serialize));
});

router.post("/challenges", async (req, res) => {
  const body = CreateChallengeBody.parse(req.body);
  const [row] = await db
    .insert(challengesTable)
    .values({
      title: body.title,
      description: body.description ?? null,
      category: body.category ?? "habit",
      icon: body.icon ?? null,
      color: body.color ?? null,
      unit: body.unit ?? "times",
      targetValue: String(body.targetValue),
      currentValue: String(body.currentValue ?? 0),
      startDate: body.startDate ? new Date(body.startDate) : new Date(),
      endDate: new Date(body.endDate),
      pinned: body.pinned ?? false,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.patch("/challenges/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateChallengeBody.parse(req.body);
  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (body.title != null) updates.title = body.title;
  if (body.description !== undefined) updates.description = body.description;
  if (body.category != null) updates.category = body.category;
  if (body.icon !== undefined) updates.icon = body.icon;
  if (body.color !== undefined) updates.color = body.color;
  if (body.unit != null) updates.unit = body.unit;
  if (body.targetValue != null) updates.targetValue = String(body.targetValue);
  if (body.currentValue != null) updates.currentValue = String(body.currentValue);
  if (body.startDate != null) updates.startDate = new Date(body.startDate);
  if (body.endDate != null) updates.endDate = new Date(body.endDate);
  if (body.status != null) updates.status = body.status;
  if (body.pinned != null) updates.pinned = body.pinned;
  const [row] = await db
    .update(challengesTable)
    .set(updates)
    .where(eq(challengesTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Challenge not found" });
    return;
  }
  res.json(serialize(row));
});

router.delete("/challenges/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(challengeProgressTable).where(eq(challengeProgressTable.challengeId, id));
  await db.delete(challengesTable).where(eq(challengesTable.id, id));
  res.status(204).end();
});

router.post("/challenges/:id/progress", async (req, res) => {
  const id = Number(req.params.id);
  const body = AddChallengeProgressBody.parse(req.body);
  const [existing] = await db.select().from(challengesTable).where(eq(challengesTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Challenge not found" });
    return;
  }
  await db.insert(challengeProgressTable).values({
    challengeId: id,
    delta: String(body.delta),
    note: body.note ?? null,
  });
  const newCurrent = Number(existing.currentValue) + body.delta;
  const newStatus = deriveStatus(newCurrent, Number(existing.targetValue), existing.endDate, existing.status);
  const [updated] = await db
    .update(challengesTable)
    .set({
      currentValue: String(newCurrent),
      status: newStatus,
      updatedAt: new Date(),
    })
    .where(eq(challengesTable.id, id))
    .returning();
  res.json(serialize(updated));
});

export default router;
