import { Router, type IRouter } from "express";
import { db, transactionsTable, accountsTable, investmentsTable } from "@workspace/db";
import { GetRevenueFlowQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

const CATEGORY_COLORS: Record<string, string> = {
  Food: "#A89BF5",
  Groceries: "#A89BF5",
  Clothes: "#7CF0BD",
  Shopping: "#7CF0BD",
  Transport: "#5EC9F2",
  Travel: "#5EC9F2",
  Health: "#F2C879",
  Subscriptions: "#F291C8",
  Entertainment: "#F291C8",
  Bills: "#9CA3AF",
  Other: "#9CA3AF",
};

function colorFor(category: string): string {
  if (CATEGORY_COLORS[category]) return CATEGORY_COLORS[category];
  // hash to color
  let hash = 0;
  for (const ch of category) hash = (hash * 31 + ch.charCodeAt(0)) & 0xffffffff;
  const palette = ["#7CF0BD", "#A89BF5", "#5EC9F2", "#F2C879", "#F291C8", "#5BD7A2"];
  return palette[Math.abs(hash) % palette.length];
}

router.get("/dashboard/summary", async (_req, res) => {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const prevMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const prevMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - 7);
  const prevWeekStart = new Date(now);
  prevWeekStart.setDate(now.getDate() - 14);

  const [accounts, txns, investments] = await Promise.all([
    db.select().from(accountsTable),
    db.select().from(transactionsTable),
    db.select().from(investmentsTable),
  ]);

  const totalBalance = accounts.reduce((s, a) => s + Number(a.balance), 0);
  const portfolioValue = investments.reduce(
    (s, i) => s + Number(i.quantity) * Number(i.currentPrice),
    0,
  );
  const netWorth = totalBalance + portfolioValue;

  let monthIncome = 0;
  let monthExpense = 0;
  let prevMonthIncome = 0;
  let prevMonthExpense = 0;
  let weekIncome = 0;
  let weekExpense = 0;
  let prevWeekIncome = 0;
  let prevWeekExpense = 0;

  for (const t of txns) {
    const amount = Number(t.amount);
    const occurredAt = t.occurredAt;
    if (occurredAt >= monthStart) {
      if (t.type === "income") monthIncome += amount;
      else monthExpense += amount;
    } else if (occurredAt >= prevMonthStart && occurredAt <= prevMonthEnd) {
      if (t.type === "income") prevMonthIncome += amount;
      else prevMonthExpense += amount;
    }
    if (occurredAt >= weekStart) {
      if (t.type === "income") weekIncome += amount;
      else weekExpense += amount;
    } else if (occurredAt >= prevWeekStart && occurredAt < weekStart) {
      if (t.type === "income") prevWeekIncome += amount;
      else prevWeekExpense += amount;
    }
  }

  function pct(curr: number, prev: number): number {
    if (prev === 0) return curr === 0 ? 0 : 100;
    return Math.round(((curr - prev) / prev) * 100);
  }

  const currency = accounts[0]?.currency ?? "USD";

  res.json({
    totalBalance,
    monthIncome,
    monthExpense,
    weekIncome,
    weekExpense,
    incomeChangePct: pct(weekIncome, prevWeekIncome),
    expenseChangePct: pct(weekExpense, prevWeekExpense),
    currency,
    netWorth,
    portfolioValue,
  });
});

router.get("/dashboard/revenue-flow", async (req, res) => {
  const params = GetRevenueFlowQueryParams.parse(req.query);
  const months = params.months ?? 6;
  const now = new Date();
  const buckets: { month: string; key: string; income: number; expense: number }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({
      month: d.toLocaleString("en-US", { month: "short" }),
      key: `${d.getFullYear()}-${d.getMonth()}`,
      income: 0,
      expense: 0,
    });
  }
  const txns = await db.select().from(transactionsTable);
  for (const t of txns) {
    const d = t.occurredAt;
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    const bucket = buckets.find((b) => b.key === key);
    if (!bucket) continue;
    const amount = Number(t.amount);
    if (t.type === "income") bucket.income += amount;
    else bucket.expense += amount;
  }
  res.json(
    buckets.map((b) => ({
      month: b.month,
      income: b.income,
      expense: b.expense,
      net: b.income - b.expense,
    })),
  );
});

router.get("/dashboard/spending-by-category", async (_req, res) => {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const txns = await db.select().from(transactionsTable);
  const map = new Map<string, number>();
  for (const t of txns) {
    if (t.type !== "expense") continue;
    if (t.occurredAt < monthStart) continue;
    map.set(t.category, (map.get(t.category) ?? 0) + Number(t.amount));
  }
  const result = [...map.entries()]
    .map(([category, amount]) => ({ category, amount, color: colorFor(category) }))
    .sort((a, b) => b.amount - a.amount);
  res.json(result);
});

router.get("/dashboard/spending-trend", async (_req, res) => {
  const now = new Date();
  const days: { date: string; amount: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    days.push({ date: d.toISOString().slice(0, 10), amount: 0 });
  }
  const txns = await db.select().from(transactionsTable);
  for (const t of txns) {
    if (t.type !== "expense") continue;
    const key = t.occurredAt.toISOString().slice(0, 10);
    const bucket = days.find((d) => d.date === key);
    if (bucket) bucket.amount += Number(t.amount);
  }
  res.json(days);
});

export default router;
