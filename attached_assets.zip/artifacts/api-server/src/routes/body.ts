import { Router, type IRouter } from "express";
import { db, bodyMetricsTable } from "@workspace/db";
import { CreateBodyMetricBody } from "@workspace/api-zod";
import { asc, desc, eq } from "drizzle-orm";

const router: IRouter = Router();

function serialize(row: typeof bodyMetricsTable.$inferSelect) {
  return {
    id: row.id,
    recordedAt: row.recordedAt,
    weightKg: row.weightKg !== null ? Number(row.weightKg) : null,
    bodyFatPct: row.bodyFatPct !== null ? Number(row.bodyFatPct) : null,
    musclePct: row.musclePct !== null ? Number(row.musclePct) : null,
    waistCm: row.waistCm !== null ? Number(row.waistCm) : null,
    chestCm: row.chestCm !== null ? Number(row.chestCm) : null,
    hipsCm: row.hipsCm !== null ? Number(row.hipsCm) : null,
    notes: row.notes,
  };
}

router.get("/body/metrics", async (_req, res) => {
  const rows = await db
    .select()
    .from(bodyMetricsTable)
    .orderBy(desc(bodyMetricsTable.recordedAt));
  res.json(rows.map(serialize));
});

router.post("/body/metrics", async (req, res) => {
  const body = CreateBodyMetricBody.parse(req.body);
  const [row] = await db
    .insert(bodyMetricsTable)
    .values({
      recordedAt: body.recordedAt
        ? (typeof body.recordedAt === "string"
          ? body.recordedAt
          : (body.recordedAt as Date).toISOString().slice(0, 10))
        : new Date().toISOString().slice(0, 10),
      weightKg: body.weightKg !== undefined && body.weightKg !== null ? String(body.weightKg) : null,
      bodyFatPct: body.bodyFatPct !== undefined && body.bodyFatPct !== null ? String(body.bodyFatPct) : null,
      musclePct: body.musclePct !== undefined && body.musclePct !== null ? String(body.musclePct) : null,
      waistCm: body.waistCm !== undefined && body.waistCm !== null ? String(body.waistCm) : null,
      chestCm: body.chestCm !== undefined && body.chestCm !== null ? String(body.chestCm) : null,
      hipsCm: body.hipsCm !== undefined && body.hipsCm !== null ? String(body.hipsCm) : null,
      notes: body.notes ?? null,
    })
    .returning();
  res.status(201).json(serialize(row));
});

router.delete("/body/metrics/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(bodyMetricsTable).where(eq(bodyMetricsTable.id, id));
  res.status(204).end();
});

router.get("/body/summary", async (_req, res) => {
  const rows = await db
    .select()
    .from(bodyMetricsTable)
    .orderBy(asc(bodyMetricsTable.recordedAt));

  const serialized = rows.map(serialize);
  const latest = serialized.length ? serialized[serialized.length - 1] : undefined;

  let weightDelta30: number | null = null;
  let bodyFatDelta30: number | null = null;
  if (latest) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - 30);
    const baselineCandidates = serialized.filter(
      (r) => new Date(r.recordedAt) <= cutoff,
    );
    const baseline = baselineCandidates.length
      ? baselineCandidates[baselineCandidates.length - 1]
      : serialized[0];
    if (baseline) {
      if (latest.weightKg !== null && baseline.weightKg !== null) {
        weightDelta30 = +(latest.weightKg - baseline.weightKg).toFixed(2);
      }
      if (latest.bodyFatPct !== null && baseline.bodyFatPct !== null) {
        bodyFatDelta30 = +(latest.bodyFatPct - baseline.bodyFatPct).toFixed(2);
      }
    }
  }

  const history = serialized.map((r) => ({
    date: r.recordedAt,
    weightKg: r.weightKg,
    bodyFatPct: r.bodyFatPct,
  }));

  res.json({
    latest,
    weightDelta30,
    bodyFatDelta30,
    history,
  });
});

export default router;
