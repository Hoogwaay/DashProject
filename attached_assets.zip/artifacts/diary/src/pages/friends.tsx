import { useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListFriends,
  useCreateFriend,
  useUpdateFriend,
  useDeleteFriend,
  getListFriendsQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Trash2, User, Briefcase, Mail, Edit3 } from "lucide-react";

const PALETTE = ["#7CF0BD", "#A89BF5", "#F2C879", "#5EC9F2", "#F291C8", "#FFB199"];

import { useT } from "@/lib/i18n";

export default function Friends() {
  const t = useT();
  const queryClient = useQueryClient();
  const { data: friends } = useListFriends();
  const create = useCreateFriend();
  const update = useUpdateFriend();
  const remove = useDeleteFriend();

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [role, setRole] = useState<"friend" | "colleague">("friend");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");

  const refetch = () =>
    queryClient.invalidateQueries({ queryKey: getListFriendsQueryKey() });

  const reset = () => {
    setName("");
    setEmail("");
    setNotes("");
    setRole("friend");
    setEditing(null);
  };

  const handleSave = () => {
    if (!name) return;
    const payload = { name, role, email: email || null, notes: notes || null };
    if (editing) {
      update.mutate(
        { id: editing, data: payload },
        {
          onSuccess: () => {
            refetch();
            setOpen(false);
            reset();
          },
        },
      );
    } else {
      const color = PALETTE[(friends?.length ?? 0) % PALETTE.length];
      create.mutate(
        { data: { ...payload, color } },
        {
          onSuccess: () => {
            refetch();
            setOpen(false);
            reset();
          },
        },
      );
    }
  };

  const openEdit = (f: any) => {
    setEditing(f.id);
    setName(f.name);
    setRole(f.role);
    setEmail(f.email ?? "");
    setNotes(f.notes ?? "");
    setOpen(true);
  };

  const friendsList = (friends ?? []).filter((f) => f.role !== "colleague");
  const colleaguesList = (friends ?? []).filter((f) => f.role === "colleague");

  return (
    <Layout>
      <div className="flex items-end justify-between mb-6 mt-2">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">{t("friends.title")}</h1>
          <p className="text-sm text-muted-foreground mt-2">
            {t("friends.subtitle")}
          </p>
        </div>
        <Dialog
          open={open}
          onOpenChange={(v) => {
            setOpen(v);
            if (!v) reset();
          }}
        >
          <DialogTrigger asChild>
            <Button size="lg">
              <Plus className="w-4 h-4 mr-2" /> {t("friends.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{editing ? t("friends.editTitle") : t("friends.addTitle")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder={t("common.name")} value={name} onChange={(e) => setName(e.target.value)} />
              <div className="flex gap-2">
                <button
                  onClick={() => setRole("friend")}
                  className={`flex-1 py-2 rounded-2xl text-sm font-semibold ${role === "friend" ? "bg-primary text-[#0a1f17]" : "bg-white/[0.04]"}`}
                >
                  {t("friends.role.friend")}
                </button>
                <button
                  onClick={() => setRole("colleague")}
                  className={`flex-1 py-2 rounded-2xl text-sm font-semibold ${role === "colleague" ? "bg-secondary text-[#0a1f17]" : "bg-white/[0.04]"}`}
                >
                  {t("friends.role.colleague")}
                </button>
              </div>
              <Input placeholder={t("friends.emailPlaceholder")} type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              <Textarea placeholder={t("common.notes")} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleSave}>{editing ? t("common.save") : t("common.add")}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-8">
        <Section title={t("friends.section.friends")} icon={<User className="w-4 h-4" />}>
          <Grid items={friendsList} onEdit={openEdit} onRemove={(id) => remove.mutate({ id }, { onSuccess: refetch })} />
        </Section>
        <Section title={t("friends.section.colleagues")} icon={<Briefcase className="w-4 h-4" />}>
          <Grid items={colleaguesList} onEdit={openEdit} onRemove={(id) => remove.mutate({ id }, { onSuccess: refetch })} />
        </Section>
      </div>
    </Layout>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">
        {icon} {title}
      </h2>
      {children}
    </section>
  );
}

function Grid({
  items,
  onEdit,
  onRemove,
}: {
  items: any[];
  onEdit: (f: any) => void;
  onRemove: (id: number) => void;
}) {
  if (items.length === 0) {
    return <p className="text-xs text-muted-foreground py-2">—</p>;
  }
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {items.map((f) => {
        const color = f.color ?? PALETTE[f.id % PALETTE.length];
        const initials = f.name
          .split(" ")
          .map((p: string) => p.charAt(0))
          .slice(0, 2)
          .join("")
          .toUpperCase();
        return (
          <div
            key={f.id}
            className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 transition-all hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5"
          >
            <div className="flex items-start justify-between mb-3">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-base font-bold"
                style={{ background: color, color: "#0a1f17" }}
              >
                {initials}
              </div>
              <div className="flex gap-1">
                <button onClick={() => onEdit(f)} className="text-muted-foreground hover:text-foreground p-1">
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => onRemove(f.id)} className="text-muted-foreground hover:text-destructive p-1">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="font-semibold truncate">{f.name}</p>
            {f.email && (
              <p className="text-[11px] text-muted-foreground flex items-center gap-1 truncate mt-1">
                <Mail className="w-3 h-3" />
                {f.email}
              </p>
            )}
            {f.notes && (
              <p className="text-[11px] text-muted-foreground mt-2 line-clamp-2">{f.notes}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}
