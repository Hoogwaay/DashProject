import { useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { PillTabs } from "@/components/pill-tabs";
import { TabTransition } from "@/components/page-transition";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListChallenges,
  useCreateChallenge,
  useUpdateChallenge,
  useDeleteChallenge,
  useAddChallengeProgress,
  getListChallengesQueryKey,
  type Challenge,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Plus,
  Trash2,
  Trophy,
  Target,
  Flame,
  Sparkles,
  CheckCircle2,
  Clock,
  Pin,
  PinOff,
  TrendingUp,
} from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useT } from "@/lib/i18n";

type Tab = "active" | "completed" | "all";

const PRESET_COLORS = [
  "#7CF0BD",
  "#A89BF5",
  "#F5A89B",
  "#F2D06B",
  "#6BB7F2",
  "#FF8FB3",
];

const ICONS_BY_CATEGORY: Record<string, typeof Trophy> = {
  habit: Sparkles,
  fitness: Flame,
  finance: TrendingUp,
  learning: Target,
  other: Trophy,
};

function daysBetween(a: Date, b: Date) {
  const ms = b.getTime() - a.getTime();
  return Math.ceil(ms / (1000 * 60 * 60 * 24));
}

function formatRemaining(endDate: string, t: (k: string) => string) {
  const end = new Date(endDate);
  const now = new Date();
  const days = daysBetween(now, end);
  if (days < 0) return t("challenges.expired");
  if (days === 0) return t("challenges.today");
  if (days === 1) return `1 ${t("challenges.day")}`;
  return `${days} ${t("challenges.days")}`;
}

export default function Challenges() {
  const t = useT();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>("active");
  const [createOpen, setCreateOpen] = useState(false);
  const [progressFor, setProgressFor] = useState<Challenge | null>(null);

  const { data: challenges = [] } = useListChallenges();
  const create = useCreateChallenge();
  const update = useUpdateChallenge();
  const remove = useDeleteChallenge();
  const addProgress = useAddChallengeProgress();

  const invalidate = () =>
    qc.invalidateQueries({ queryKey: getListChallengesQueryKey() });

  const filtered = useMemo(() => {
    if (tab === "all") return challenges;
    if (tab === "active") return challenges.filter((c) => c.status === "active");
    return challenges.filter((c) => c.status === "completed");
  }, [tab, challenges]);

  const stats = useMemo(() => {
    const active = challenges.filter((c) => c.status === "active");
    const done = challenges.filter((c) => c.status === "completed");
    const totalProgress =
      challenges.length > 0
        ? challenges.reduce(
            (s, c) => s + Math.min(1, Number(c.currentValue) / Number(c.targetValue)),
            0,
          ) / challenges.length
        : 0;
    return {
      activeCount: active.length,
      doneCount: done.length,
      avgProgress: Math.round(totalProgress * 100),
    };
  }, [challenges]);

  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3 mb-6 mt-2">
        <div className="flex flex-col gap-2">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            {t("challenges.title")}
          </h1>
          <p className="text-sm text-muted-foreground max-w-xl">
            {t("challenges.subtitle")}
          </p>
        </div>

        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-5 h-10 shadow-[0_0_20px_rgba(124,240,189,0.25)]">
              <Plus className="w-4 h-4 mr-1" />
              {t("challenges.new")}
            </Button>
          </DialogTrigger>
          <ChallengeFormDialog
            onSubmit={async (values) => {
              await create.mutateAsync({ data: values });
              await invalidate();
              setCreateOpen(false);
            }}
          />
        </Dialog>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <StatCard
          label={t("challenges.stat.active")}
          value={stats.activeCount}
          icon={<Flame className="w-5 h-5" />}
          accent="#7CF0BD"
        />
        <StatCard
          label={t("challenges.stat.completed")}
          value={stats.doneCount}
          icon={<CheckCircle2 className="w-5 h-5" />}
          accent="#A89BF5"
        />
        <StatCard
          label={t("challenges.stat.avgProgress")}
          value={`${stats.avgProgress}%`}
          icon={<TrendingUp className="w-5 h-5" />}
          accent="#F2D06B"
        />
      </div>

      <div className="mb-5">
        <PillTabs
          value={tab}
          onChange={setTab}
          items={[
            { key: "active" as Tab, label: t("challenges.tab.active") },
            { key: "completed" as Tab, label: t("challenges.tab.completed") },
            { key: "all" as Tab, label: t("challenges.tab.all") },
          ]}
        />
      </div>

      <TabTransition tabKey={tab}>
        {filtered.length === 0 ? (
          <div className="liquid-glass rounded-3xl p-10 text-center">
            <div className="w-14 h-14 mx-auto rounded-full bg-white/10 flex items-center justify-center mb-3">
              <Trophy className="w-7 h-7 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-1">
              {t("challenges.empty.title")}
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              {t("challenges.empty.subtitle")}
            </p>
            <Button
              onClick={() => setCreateOpen(true)}
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full"
            >
              <Plus className="w-4 h-4 mr-1" />
              {t("challenges.new")}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtered.map((c) => (
              <ChallengeCard
                key={c.id}
                challenge={c}
                onAddProgress={() => setProgressFor(c)}
                onTogglePin={async () => {
                  await update.mutateAsync({ id: c.id, data: { pinned: !c.pinned } });
                  await invalidate();
                }}
                onDelete={async () => {
                  await remove.mutateAsync({ id: c.id });
                  await invalidate();
                }}
              />
            ))}
          </div>
        )}
      </TabTransition>

      <Dialog open={!!progressFor} onOpenChange={(o) => !o && setProgressFor(null)}>
        {progressFor && (
          <ProgressDialog
            challenge={progressFor}
            onSubmit={async (delta, note) => {
              await addProgress.mutateAsync({
                id: progressFor.id,
                data: { delta, note: note || null },
              });
              await invalidate();
              setProgressFor(null);
            }}
          />
        )}
      </Dialog>
    </Layout>
  );
}

function StatCard({
  label,
  value,
  icon,
  accent,
}: {
  label: string;
  value: number | string;
  icon: React.ReactNode;
  accent: string;
}) {
  return (
    <div className="liquid-glass rounded-2xl p-4 flex items-center gap-3 relative overflow-hidden">
      <div
        className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
        style={{
          background: `linear-gradient(135deg, ${accent}33, ${accent}11)`,
          color: accent,
          boxShadow: `0 0 20px ${accent}22 inset`,
        }}
      >
        {icon}
      </div>
      <div className="flex flex-col min-w-0">
        <span className="text-xs uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <span className="text-2xl font-bold leading-tight">{value}</span>
      </div>
    </div>
  );
}

function ChallengeCard({
  challenge,
  onAddProgress,
  onTogglePin,
  onDelete,
}: {
  challenge: Challenge;
  onAddProgress: () => void;
  onTogglePin: () => void;
  onDelete: () => void;
}) {
  const t = useT();
  const target = Number(challenge.targetValue);
  const current = Number(challenge.currentValue);
  const pct = Math.min(100, Math.round((current / target) * 100));
  const accent = challenge.color || "#7CF0BD";
  const Icon = ICONS_BY_CATEGORY[challenge.category] || Trophy;
  const completed = challenge.status === "completed";
  const failed = challenge.status === "failed";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.25 }}
      className="liquid-glass rounded-3xl p-5 relative overflow-hidden group"
    >
      <div
        className="pointer-events-none absolute -top-20 -right-20 w-56 h-56 rounded-full blur-3xl opacity-30"
        style={{ background: accent }}
      />

      <div className="flex items-start justify-between gap-3 mb-4 relative">
        <div className="flex items-start gap-3 min-w-0">
          <div
            className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0"
            style={{
              background: `linear-gradient(135deg, ${accent}40, ${accent}15)`,
              color: accent,
              boxShadow: `0 0 24px ${accent}22 inset, 0 0 18px ${accent}25`,
            }}
          >
            <Icon className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h3 className="font-semibold text-base truncate">{challenge.title}</h3>
              {challenge.pinned && (
                <Pin className="w-3 h-3 text-primary" fill="currentColor" />
              )}
            </div>
            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
              {challenge.description || t("challenges.noDescription")}
            </p>
          </div>
        </div>

        <div className="flex flex-col items-end shrink-0">
          <span
            className={cn(
              "text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-full",
              completed && "bg-primary/20 text-primary",
              failed && "bg-destructive/20 text-destructive",
              !completed && !failed && "bg-white/10 text-muted-foreground",
            )}
          >
            {completed
              ? t("challenges.status.completed")
              : failed
              ? t("challenges.status.failed")
              : t("challenges.status.active")}
          </span>
        </div>
      </div>

      <div className="space-y-2 relative">
        <div className="flex items-baseline justify-between">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold" style={{ color: accent }}>
              {current % 1 === 0 ? current : current.toFixed(1)}
            </span>
            <span className="text-sm text-muted-foreground">
              / {target % 1 === 0 ? target : target.toFixed(1)} {challenge.unit}
            </span>
          </div>
          <span className="text-sm font-semibold">{pct}%</span>
        </div>

        <div className="h-2.5 bg-white/[0.06] rounded-full overflow-hidden relative">
          <motion.div
            className="h-full rounded-full relative"
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            style={{
              background: `linear-gradient(90deg, ${accent}, ${accent}cc)`,
              boxShadow: `0 0 14px ${accent}66`,
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-b from-white/30 to-transparent rounded-full" />
          </motion.div>
        </div>
      </div>

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/[0.06] relative">
        <span className="text-xs text-muted-foreground flex items-center gap-1.5">
          <Clock className="w-3 h-3" />
          {formatRemaining(challenge.endDate, t)}
        </span>

        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 rounded-full hover:bg-white/10"
            onClick={onTogglePin}
            title={challenge.pinned ? t("challenges.unpin") : t("challenges.pin")}
          >
            {challenge.pinned ? (
              <PinOff className="w-3.5 h-3.5" />
            ) : (
              <Pin className="w-3.5 h-3.5" />
            )}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 rounded-full hover:bg-destructive/15 hover:text-destructive"
            onClick={onDelete}
            title={t("common.delete")}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            size="sm"
            disabled={completed}
            className="h-7 ml-1 rounded-full text-xs px-3 bg-white text-[#0a1f17] hover:bg-white/90 disabled:bg-white/20 disabled:text-muted-foreground"
            onClick={onAddProgress}
          >
            <Plus className="w-3 h-3 mr-0.5" />
            {t("challenges.logProgress")}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

function ChallengeFormDialog({
  onSubmit,
}: {
  onSubmit: (values: {
    title: string;
    description: string | null;
    category: string;
    color: string;
    unit: string;
    targetValue: number;
    endDate: string;
  }) => Promise<void>;
}) {
  const t = useT();
  const today = new Date();
  const defaultEnd = new Date(today);
  defaultEnd.setMonth(defaultEnd.getMonth() + 1);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("habit");
  const [color, setColor] = useState(PRESET_COLORS[0]);
  const [unit, setUnit] = useState("times");
  const [target, setTarget] = useState("30");
  const [endDate, setEndDate] = useState(defaultEnd.toISOString().slice(0, 10));
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!title.trim() || !target) return;
    setBusy(true);
    try {
      await onSubmit({
        title: title.trim(),
        description: description.trim() || null,
        category,
        color,
        unit: unit.trim() || "times",
        targetValue: Number(target),
        endDate: new Date(endDate + "T23:59:59").toISOString(),
      });
      setTitle("");
      setDescription("");
      setTarget("30");
    } finally {
      setBusy(false);
    }
  };

  return (
    <DialogContent className="liquid-glass border-white/10 sm:max-w-[480px]">
      <DialogHeader>
        <DialogTitle>{t("challenges.dialog.newTitle")}</DialogTitle>
      </DialogHeader>
      <div className="space-y-3 py-2">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">
            {t("challenges.field.title")}
          </label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t("challenges.field.titlePlaceholder")}
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">
            {t("challenges.field.description")}
          </label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={2}
            placeholder={t("challenges.field.descriptionPlaceholder")}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">
              {t("challenges.field.category")}
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-md px-3 h-9 text-sm focus:outline-none focus:border-primary/40"
            >
              <option value="habit">{t("challenges.cat.habit")}</option>
              <option value="fitness">{t("challenges.cat.fitness")}</option>
              <option value="finance">{t("challenges.cat.finance")}</option>
              <option value="learning">{t("challenges.cat.learning")}</option>
              <option value="other">{t("challenges.cat.other")}</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">
              {t("challenges.field.endDate")}
            </label>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">
              {t("challenges.field.target")}
            </label>
            <Input
              type="number"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">
              {t("challenges.field.unit")}
            </label>
            <Input
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              placeholder="times, km, $..."
            />
          </div>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">
            {t("challenges.field.color")}
          </label>
          <div className="flex gap-2">
            {PRESET_COLORS.map((c) => (
              <button
                type="button"
                key={c}
                onClick={() => setColor(c)}
                className={cn(
                  "w-7 h-7 rounded-full transition-all",
                  color === c
                    ? "ring-2 ring-white/80 ring-offset-2 ring-offset-[#0a1414] scale-110"
                    : "hover:scale-105",
                )}
                style={{ background: c, boxShadow: `0 0 14px ${c}66` }}
              />
            ))}
          </div>
        </div>
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={busy || !title.trim()}>
          {busy ? t("common.saving") : t("challenges.dialog.create")}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

function ProgressDialog({
  challenge,
  onSubmit,
}: {
  challenge: Challenge;
  onSubmit: (delta: number, note: string) => Promise<void>;
}) {
  const t = useT();
  const [delta, setDelta] = useState("1");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const n = Number(delta);
    if (!n || isNaN(n)) return;
    setBusy(true);
    try {
      await onSubmit(n, note);
      setDelta("1");
      setNote("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <DialogContent className="liquid-glass border-white/10 sm:max-w-[420px]">
      <DialogHeader>
        <DialogTitle>{challenge.title}</DialogTitle>
      </DialogHeader>
      <div className="space-y-3 py-2">
        <p className="text-xs text-muted-foreground">
          {t("challenges.progress.help")}
        </p>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">
            {t("challenges.progress.delta")} ({challenge.unit})
          </label>
          <Input
            type="number"
            value={delta}
            onChange={(e) => setDelta(e.target.value)}
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">
            {t("challenges.progress.note")}
          </label>
          <Input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={t("challenges.progress.notePlaceholder")}
          />
        </div>
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={busy}>
          {busy ? t("common.saving") : t("challenges.progress.add")}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
