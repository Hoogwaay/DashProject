import { useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListEvents,
  useCreateEvent,
  useUpdateEvent,
  useDeleteEvent,
  getListEventsQueryKey,
  getListUpcomingEventsQueryKey,
  CreateCalendarEventKind,
} from "@workspace/api-client-react";
import type { CreateCalendarEventKind as CreateCalendarEventKindT } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Check,
  Dumbbell,
  ListChecks,
  Ruler,
  Calendar as CalendarIcon,
} from "lucide-react";
import { useI18n, localeFor } from "@/lib/i18n";

const KIND_COLORS: Record<string, string> = {
  workout: "#7CF0BD",
  task: "#A89BF5",
  measurement: "#5EC9F2",
  habit: "#F2C879",
  other: "#F291C8",
};

export default function Calendar() {
  const qc = useQueryClient();
  const { t, lang } = useI18n();
  const locale = localeFor(lang);
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  const monthStart = cursor;
  const monthEnd = new Date(
    cursor.getFullYear(),
    cursor.getMonth() + 1,
    0,
    23,
    59,
    59
  );

  const { data: events } = useListEvents({
    from: monthStart.toISOString(),
    to: monthEnd.toISOString(),
  });
  const create = useCreateEvent();
  const update = useUpdateEvent();
  const del = useDeleteEvent();

  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [kind, setKind] = useState<CreateCalendarEventKindT>(
    CreateCalendarEventKind.task
  );
  const [scheduledAt, setScheduledAt] = useState(
    new Date().toISOString().slice(0, 16)
  );
  const [durationMin, setDurationMin] = useState("");
  const [notes, setNotes] = useState("");

  const reset = () => {
    setTitle("");
    setKind(CreateCalendarEventKind.task);
    setScheduledAt(new Date().toISOString().slice(0, 16));
    setDurationMin("");
    setNotes("");
  };

  const handleCreate = () => {
    if (!title) return;
    create.mutate(
      {
        data: {
          title,
          kind,
          scheduledAt: new Date(scheduledAt).toISOString(),
          durationMin: durationMin ? parseInt(durationMin) : undefined,
          notes: notes || undefined,
          color: KIND_COLORS[kind],
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListEventsQueryKey() });
          qc.invalidateQueries({ queryKey: getListUpcomingEventsQueryKey() });
          setOpen(false);
          reset();
        },
      }
    );
  };

  const cells = useMemo(() => buildMonthGrid(cursor), [cursor]);
  const eventsByDay = useMemo(() => {
    const m = new Map<string, any[]>();
    (events ?? []).forEach((e) => {
      const k = new Date(e.scheduledAt).toDateString();
      m.set(k, [...(m.get(k) ?? []), e]);
    });
    return m;
  }, [events]);

  const monthLabel = cursor.toLocaleString(locale, {
    month: "long",
    year: "numeric",
  });

  const weekdays = [
    t("cal.weekday.mon"),
    t("cal.weekday.tue"),
    t("cal.weekday.wed"),
    t("cal.weekday.thu"),
    t("cal.weekday.fri"),
    t("cal.weekday.sat"),
    t("cal.weekday.sun"),
  ];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{t("cal.title")}</h1>
            <p className="text-muted-foreground mt-1">
              {t("cal.subtitle")}
            </p>
          </div>
          <Dialog
            open={open}
            onOpenChange={(o) => {
              setOpen(o);
              if (!o) reset();
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full">
                <Plus className="w-4 h-4 mr-2" /> {t("cal.add")}
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle>{t("cal.new")}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <Input
                  placeholder={t("cal.titlePlaceholder")}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
                <select
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={kind}
                  onChange={(e) =>
                    setKind(e.target.value as CreateCalendarEventKindT)
                  }
                >
                  <option value="task">{t("cal.kind.task")}</option>
                  <option value="workout">{t("cal.kind.workout")}</option>
                  <option value="measurement">{t("cal.kind.measurement")}</option>
                  <option value="note">{t("cal.kind.note")}</option>
                </select>
                <Input
                  type="datetime-local"
                  value={scheduledAt}
                  onChange={(e) => setScheduledAt(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder={t("cal.duration")}
                  value={durationMin}
                  onChange={(e) => setDurationMin(e.target.value)}
                />
                <Input
                  placeholder={t("common.notesOptional")}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  {t("common.cancel")}
                </Button>
                <Button onClick={handleCreate} disabled={!title}>
                  {t("common.save")}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={() =>
                setCursor(
                  new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1)
                )
              }
              className="w-9 h-9 rounded-full hover:bg-white/5 flex items-center justify-center"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-bold tracking-tight capitalize">{monthLabel}</h2>
            <button
              onClick={() =>
                setCursor(
                  new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1)
                )
              }
              className="w-9 h-9 rounded-full hover:bg-white/5 flex items-center justify-center"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-2 text-center text-xs font-semibold text-muted-foreground mb-2">
            {weekdays.map((d) => (
              <div key={d}>{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {cells.map((c, i) => {
              const k = c.date.toDateString();
              const dayEvents = eventsByDay.get(k) ?? [];
              const today =
                c.date.toDateString() === new Date().toDateString();
              return (
                <div
                  key={i}
                  className={`min-h-[88px] rounded-2xl p-2 border transition ${
                    c.inMonth
                      ? "bg-background border-border"
                      : "bg-transparent border-transparent opacity-40"
                  }`}
                >
                  <div
                    className={`text-xs font-semibold mb-1 ${
                      today ? "text-primary" : ""
                    }`}
                  >
                    {today ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground">
                        {c.date.getDate()}
                      </span>
                    ) : (
                      c.date.getDate()
                    )}
                  </div>
                  <div className="space-y-1">
                    {dayEvents.slice(0, 2).map((e) => (
                      <div
                        key={e.id}
                        className="text-[10px] truncate px-1.5 py-0.5 rounded-md font-medium"
                        style={{
                          background: `${e.color ?? KIND_COLORS[e.kind] ?? "#7CF0BD"}22`,
                          color: e.color ?? KIND_COLORS[e.kind] ?? "#7CF0BD",
                        }}
                        title={e.title}
                      >
                        {e.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-[10px] text-muted-foreground">
                        +{dayEvents.length - 2} {t("cal.more")}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <h3 className="font-semibold mb-4">{t("cal.eventsThisMonth")}</h3>
          {(events ?? []).length === 0 ? (
            <p className="text-muted-foreground text-sm py-6 text-center">
              {t("cal.noEvents")}
            </p>
          ) : (
            <div className="divide-y divide-border">
              {[...(events ?? [])]
                .sort(
                  (a, b) =>
                    new Date(a.scheduledAt).getTime() -
                    new Date(b.scheduledAt).getTime()
                )
                .map((e) => {
                  const Icon = iconForKind(e.kind);
                  const color = e.color ?? KIND_COLORS[e.kind] ?? "#7CF0BD";
                  const d = new Date(e.scheduledAt);
                  return (
                    <div
                      key={e.id}
                      className="flex items-center gap-4 py-3 group"
                    >
                      <button
                        onClick={() =>
                          update.mutate(
                            { id: e.id, data: { done: !e.done } },
                            {
                              onSuccess: () =>
                                qc.invalidateQueries({
                                  queryKey: getListEventsQueryKey(),
                                }),
                            }
                          )
                        }
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 transition ${
                          e.done
                            ? "bg-primary border-primary text-primary-foreground"
                            : "border-border hover:border-primary"
                        }`}
                      >
                        {e.done && <Check className="w-3.5 h-3.5" />}
                      </button>
                      <div
                        className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0"
                        style={{ background: `${color}22`, color }}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p
                          className={`font-medium truncate ${
                            e.done ? "line-through text-muted-foreground" : ""
                          }`}
                        >
                          {e.title}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {d.toLocaleString(locale, {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                          {e.durationMin ? ` · ${e.durationMin} ${t("common.min")}` : ""}
                        </p>
                      </div>
                      <button
                        onClick={() =>
                          del.mutate(
                            { id: e.id },
                            {
                              onSuccess: () => {
                                qc.invalidateQueries({
                                  queryKey: getListEventsQueryKey(),
                                });
                                qc.invalidateQueries({
                                  queryKey: getListUpcomingEventsQueryKey(),
                                });
                              },
                            }
                          )
                        }
                        className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function iconForKind(k: string) {
  switch (k) {
    case "workout":
      return Dumbbell;
    case "measurement":
      return Ruler;
    case "task":
      return ListChecks;
    default:
      return CalendarIcon;
  }
}

function buildMonthGrid(cursor: Date) {
  const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
  const last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
  const startDow = (first.getDay() + 6) % 7;
  const days: { date: Date; inMonth: boolean }[] = [];
  for (let i = 0; i < startDow; i++) {
    const d = new Date(first);
    d.setDate(first.getDate() - (startDow - i));
    days.push({ date: d, inMonth: false });
  }
  for (let i = 1; i <= last.getDate(); i++) {
    days.push({
      date: new Date(cursor.getFullYear(), cursor.getMonth(), i),
      inMonth: true,
    });
  }
  while (days.length % 7 !== 0) {
    const lastDay = days[days.length - 1].date;
    const d = new Date(lastDay);
    d.setDate(lastDay.getDate() + 1);
    days.push({ date: d, inMonth: false });
  }
  return days;
}
