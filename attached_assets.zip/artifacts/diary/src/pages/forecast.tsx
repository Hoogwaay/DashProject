import { useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListForecastEntries,
  useGetForecastSummary,
  useCreateForecastEntry,
  useDeleteForecastEntry,
  getListForecastEntriesQueryKey,
  getGetForecastSummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { CalendarClock, Plus, Trash2, RefreshCw, Repeat } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";

const MINT = "#7CF0BD";

export default function Forecast() {
  const qc = useQueryClient();
  const { data: items } = useListForecastEntries();
  const { data: summary } = useGetForecastSummary({ months: 3 });
  const create = useCreateForecastEntry();
  const del = useDeleteForecastEntry();

  const [open, setOpen] = useState(false);
  const [source, setSource] = useState("");
  const [amount, setAmount] = useState("");
  const [recurrence, setRecurrence] = useState("monthly");
  const [expectedDate, setExpectedDate] = useState(
    new Date().toISOString().slice(0, 10)
  );
  const [notes, setNotes] = useState("");

  const reset = () => {
    setSource("");
    setAmount("");
    setRecurrence("monthly");
    setExpectedDate(new Date().toISOString().slice(0, 10));
    setNotes("");
  };

  const handleCreate = () => {
    if (!source || !amount) return;
    create.mutate(
      {
        data: {
          source,
          amount: parseFloat(amount),
          recurrence,
          expectedDate,
          notes: notes || undefined,
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListForecastEntriesQueryKey() });
          qc.invalidateQueries({ queryKey: getGetForecastSummaryQueryKey() });
          setOpen(false);
          reset();
        },
      }
    );
  };

  const sortedItems = useMemo(
    () =>
      [...(items ?? [])].sort(
        (a, b) =>
          new Date(a.expectedDate).getTime() - new Date(b.expectedDate).getTime()
      ),
    [items]
  );

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Income Forecast</h1>
            <p className="text-muted-foreground mt-1">
              Plan upcoming and recurring income.
            </p>
          </div>
          <Dialog
            open={open}
            onOpenChange={(o) => {
              setOpen(o);
              if (!o) reset();
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full">
                <Plus className="w-4 h-4 mr-2" /> Add forecast
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle>New forecast entry</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <Input
                  placeholder="Source (e.g. Salary)"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="Amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <Input
                  type="date"
                  value={expectedDate}
                  onChange={(e) => setExpectedDate(e.target.value)}
                />
                <select
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={recurrence}
                  onChange={(e) => setRecurrence(e.target.value)}
                >
                  <option value="once">One-time</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="quarterly">Quarterly</option>
                  <option value="yearly">Yearly</option>
                </select>
                <Input
                  placeholder="Notes (optional)"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate}>Save</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-3xl bg-card border border-border p-6 relative overflow-hidden">
            <div
              className="absolute -right-8 -top-8 w-32 h-32 rounded-full blur-3xl"
              style={{ background: "rgba(124,240,189,0.18)" }}
            />
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">
              Expected next 3 months
            </p>
            <h2 className="text-4xl font-bold tracking-tight">
              {formatCurrency(
                (summary ?? []).reduce((s, m) => s + m.amount, 0)
              )}
            </h2>
            <p className="text-xs text-muted-foreground mt-3">
              {sortedItems.length} entries · avg{" "}
              {formatCurrency(
                (summary ?? []).length > 0
                  ? (summary ?? []).reduce((s, m) => s + m.amount, 0) /
                      (summary ?? []).length
                  : 0
              )}{" "}
              / month
            </p>
          </div>
          <div className="rounded-3xl bg-card border border-border p-6">
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">
              Recurring streams
            </p>
            <h2 className="text-4xl font-bold tracking-tight">
              {sortedItems.filter((i) => i.recurrence !== "once").length}
            </h2>
            <p className="text-xs text-muted-foreground mt-3">
              Out of {sortedItems.length} planned items
            </p>
          </div>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <h3 className="font-semibold mb-4">Upcoming income</h3>
          {sortedItems.length === 0 ? (
            <p className="text-muted-foreground text-sm py-6 text-center">
              No forecasts yet.
            </p>
          ) : (
            <div className="divide-y divide-border">
              {sortedItems.map((it) => {
                const recurring = it.recurrence !== "once";
                return (
                  <div key={it.id} className="flex items-center gap-4 py-3 group">
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0"
                      style={{ background: "rgba(124,240,189,0.14)", color: MINT }}
                    >
                      {recurring ? (
                        <Repeat className="w-5 h-5" />
                      ) : (
                        <CalendarClock className="w-5 h-5" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{it.source}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(it.expectedDate)} ·{" "}
                        <span className="capitalize">{it.recurrence}</span>
                        {it.notes ? ` · ${it.notes}` : ""}
                      </p>
                    </div>
                    <div className="text-base font-semibold text-primary">
                      +{formatCurrency(it.amount)}
                    </div>
                    <button
                      onClick={() =>
                        del.mutate(
                          { id: it.id },
                          {
                            onSuccess: () => {
                              qc.invalidateQueries({
                                queryKey: getListForecastEntriesQueryKey(),
                              });
                              qc.invalidateQueries({
                                queryKey: getGetForecastSummaryQueryKey(),
                              });
                            },
                          }
                        )
                      }
                      className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
