import { useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListInvestments,
  useGetInvestmentSummary,
  useCreateInvestment,
  useDeleteInvestment,
  getListInvestmentsQueryKey,
  getGetInvestmentSummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  TrendingUp,
  TrendingDown,
  Plus,
  Trash2,
  Bitcoin,
  LineChart,
  Landmark,
  PieChart,
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

export default function Investments() {
  const qc = useQueryClient();
  const { data: items, isLoading } = useListInvestments();
  const { data: summary } = useGetInvestmentSummary();
  const create = useCreateInvestment();
  const del = useDeleteInvestment();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [ticker, setTicker] = useState("");
  const [kind, setKind] = useState("stock");
  const [quantity, setQuantity] = useState("");
  const [buyPrice, setBuyPrice] = useState("");
  const [currentPrice, setCurrentPrice] = useState("");

  const reset = () => {
    setName("");
    setTicker("");
    setKind("stock");
    setQuantity("");
    setBuyPrice("");
    setCurrentPrice("");
  };

  const handleCreate = () => {
    if (!name || !quantity || !buyPrice || !currentPrice) return;
    create.mutate(
      {
        data: {
          name,
          ticker: ticker || undefined,
          kind,
          quantity: parseFloat(quantity),
          buyPrice: parseFloat(buyPrice),
          currentPrice: parseFloat(currentPrice),
          purchasedAt: new Date().toISOString().slice(0, 10),
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListInvestmentsQueryKey() });
          qc.invalidateQueries({ queryKey: getGetInvestmentSummaryQueryKey() });
          setOpen(false);
          reset();
        },
      }
    );
  };

  const iconFor = (k: string) => {
    if (k === "crypto") return <Bitcoin className="w-5 h-5" />;
    if (k === "etf") return <PieChart className="w-5 h-5" />;
    if (k === "bond") return <Landmark className="w-5 h-5" />;
    return <LineChart className="w-5 h-5" />;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Investments</h1>
            <p className="text-muted-foreground mt-1">
              Track your portfolio performance.
            </p>
          </div>
          <Dialog
            open={open}
            onOpenChange={(o) => {
              setOpen(o);
              if (!o) reset();
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full">
                <Plus className="w-4 h-4 mr-2" /> Add holding
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle>Add holding</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <Input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
                <div className="grid grid-cols-2 gap-3">
                  <Input
                    placeholder="Ticker"
                    value={ticker}
                    onChange={(e) => setTicker(e.target.value.toUpperCase())}
                  />
                  <select
                    className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                    value={kind}
                    onChange={(e) => setKind(e.target.value)}
                  >
                    <option value="stock">Stock</option>
                    <option value="etf">ETF</option>
                    <option value="crypto">Crypto</option>
                    <option value="bond">Bond</option>
                  </select>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <Input
                    type="number"
                    placeholder="Qty"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  />
                  <Input
                    type="number"
                    placeholder="Buy price"
                    value={buyPrice}
                    onChange={(e) => setBuyPrice(e.target.value)}
                  />
                  <Input
                    type="number"
                    placeholder="Now price"
                    value={currentPrice}
                    onChange={(e) => setCurrentPrice(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate}>Save</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-3xl bg-card border border-border p-6 col-span-1 md:col-span-2 relative overflow-hidden">
            <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full blur-3xl" style={{ background: "rgba(124,240,189,0.18)" }} />
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">
              Portfolio value
            </p>
            <h2 className="text-4xl font-bold tracking-tight">
              {formatCurrency(summary?.totalValue ?? 0)}
            </h2>
            <div className="flex items-center gap-3 mt-3">
              <span
                className={`flex items-center gap-1 text-sm font-medium px-2 py-1 rounded-full ${
                  (summary?.profit ?? 0) >= 0 ? "text-primary" : "text-destructive"
                }`}
                style={{ background: "rgba(255,255,255,0.04)" }}
              >
                {(summary?.profit ?? 0) >= 0 ? (
                  <TrendingUp className="w-3.5 h-3.5" />
                ) : (
                  <TrendingDown className="w-3.5 h-3.5" />
                )}
                {formatCurrency(summary?.profit ?? 0)} ({(summary?.profitPct ?? 0).toFixed(1)}%)
              </span>
              <span className="text-xs text-muted-foreground">All time</span>
            </div>
          </div>
          <div className="rounded-3xl bg-card border border-border p-6">
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">
              Holdings
            </p>
            <h2 className="text-4xl font-bold tracking-tight">{items?.length ?? 0}</h2>
            <p className="text-xs text-muted-foreground mt-3">Across all asset classes</p>
          </div>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <h3 className="font-semibold mb-4">All holdings</h3>
          {isLoading ? (
            <p className="text-muted-foreground text-sm">Loading…</p>
          ) : items?.length === 0 ? (
            <p className="text-muted-foreground text-sm py-6 text-center">
              No holdings yet.
            </p>
          ) : (
            <div className="divide-y divide-border">
              {items?.map((it) => {
                const value = it.quantity * it.currentPrice;
                const cost = it.quantity * it.buyPrice;
                const gain = value - cost;
                const gainPct = cost > 0 ? (gain / cost) * 100 : 0;
                const positive = gain >= 0;
                return (
                  <div
                    key={it.id}
                    className="flex items-center gap-4 py-3 group"
                  >
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0"
                      style={{
                        background: positive
                          ? "rgba(124,240,189,0.14)"
                          : "rgba(168,155,245,0.14)",
                        color: positive ? MINT : LAVENDER,
                      }}
                    >
                      {iconFor(it.kind)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{it.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {it.ticker ? `${it.ticker} · ` : ""}
                        {it.quantity} × {formatCurrency(it.currentPrice)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{formatCurrency(value)}</p>
                      <p
                        className={`text-xs font-medium ${
                          positive ? "text-primary" : "text-destructive"
                        }`}
                      >
                        {positive ? "+" : ""}
                        {gainPct.toFixed(1)}%
                      </p>
                    </div>
                    <button
                      onClick={() =>
                        del.mutate(
                          { id: it.id },
                          {
                            onSuccess: () => {
                              qc.invalidateQueries({ queryKey: getListInvestmentsQueryKey() });
                              qc.invalidateQueries({ queryKey: getGetInvestmentSummaryQueryKey() });
                            },
                          }
                        )
                      }
                      className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
