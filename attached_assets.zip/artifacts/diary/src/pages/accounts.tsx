import { useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { useListAccounts, useCreateAccount, useDeleteAccount, getListAccountsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Wallet, CreditCard, Building2, Bitcoin, Plus, Trash2, MoreHorizontal } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export default function Accounts() {
  const queryClient = useQueryClient();
  const { data: accounts, isLoading } = useListAccounts();
  const createAccount = useCreateAccount();
  const deleteAccount = useDeleteAccount();

  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState("");
  const [kind, setKind] = useState("checking");
  const [balance, setBalance] = useState("");
  const [cardLast4, setCardLast4] = useState("");

  const handleCreate = () => {
    if (!name || !balance) return;
    createAccount.mutate({
      data: {
        name,
        kind,
        balance: parseFloat(balance),
        currency: "USD",
        cardLast4: cardLast4 || undefined,
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
        setIsOpen(false);
        reset();
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteAccount.mutate({ id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() })
    });
  };

  const reset = () => {
    setName("");
    setKind("checking");
    setBalance("");
    setCardLast4("");
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-8 w-32 bg-card rounded mb-4"></div>
            <div className="h-4 w-48 bg-card/50 rounded"></div>
          </div>
        </div>
      </Layout>
    );
  }

  const totalBalance = accounts?.reduce((sum, acc) => sum + acc.balance, 0) || 0;

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Accounts</h1>
            <p className="text-muted-foreground mt-1">Manage your connected accounts and cash.</p>
          </div>
          
          <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if(!open) reset(); }}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                Add Account
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] bg-card border-border">
              <DialogHeader>
                <DialogTitle>Add Account</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Account Name</label>
                  <Input placeholder="e.g. Chase Checking" value={name} onChange={e => setName(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Type</label>
                    <select 
                      className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      value={kind}
                      onChange={e => setKind(e.target.value)}
                    >
                      <option value="checking">Checking</option>
                      <option value="savings">Savings</option>
                      <option value="credit">Credit Card</option>
                      <option value="cash">Cash</option>
                      <option value="crypto">Crypto</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Current Balance</label>
                    <Input type="number" step="0.01" placeholder="0.00" value={balance} onChange={e => setBalance(e.target.value)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Card Last 4 (Optional)</label>
                  <Input placeholder="1234" maxLength={4} value={cardLast4} onChange={e => setCardLast4(e.target.value)} />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                <Button onClick={handleCreate} disabled={!name || !balance}>Save</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 mb-8 flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider mb-1">Total Balance</p>
            <h2 className="text-4xl font-bold tracking-tight text-primary">{formatCurrency(totalBalance)}</h2>
          </div>
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <Wallet className="w-8 h-8" />
          </div>
        </div>

        {accounts?.length === 0 ? (
          <div className="text-center py-16 bg-card/30 border border-border/50 rounded-2xl">
            <Building2 className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground">No accounts added yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {accounts?.map(account => (
              <AccountCard key={account.id} account={account} onDelete={handleDelete} />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}

function AccountCard({ account, onDelete }: { account: any, onDelete: any }) {
  const getIcon = () => {
    switch (account.kind) {
      case 'credit': return <CreditCard className="w-6 h-6" />;
      case 'cash': return <Wallet className="w-6 h-6" />;
      case 'crypto': return <Bitcoin className="w-6 h-6" />;
      default: return <Building2 className="w-6 h-6" />;
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 hover:border-primary/30 transition-all duration-300 group flex flex-col justify-between min-h-[160px] relative overflow-hidden">
      {/* Decorative gradient blur based on card type */}
      <div className="absolute -right-8 -top-8 w-32 h-32 bg-primary/5 rounded-full blur-2xl pointer-events-none" />
      
      <div className="flex justify-between items-start z-10">
        <div className="w-12 h-12 rounded-xl bg-background border border-border flex items-center justify-center text-muted-foreground">
          {getIcon()}
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity p-1">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-card border-border">
            <DropdownMenuItem className="text-destructive focus:bg-destructive/10 focus:text-destructive cursor-pointer" onClick={() => onDelete(account.id)}>
              <Trash2 className="w-4 h-4 mr-2" /> Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="mt-4 z-10">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="font-semibold text-lg text-foreground">{account.name}</h3>
          {account.cardLast4 && (
            <span className="text-xs px-2 py-0.5 rounded-md bg-white/5 border border-border/50 text-muted-foreground">
              •••{account.cardLast4}
            </span>
          )}
        </div>
        <p className="text-2xl font-bold tracking-tight text-foreground">{formatCurrency(account.balance)}</p>
      </div>
    </div>
  );
}