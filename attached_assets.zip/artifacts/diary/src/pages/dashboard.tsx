import { useEffect, useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { Link } from "wouter";
import {
  useGetDashboardSummary,
  useGetRevenueFlow,
  useGetSpendingByCategory,
  useGetSpendingTrend,
  useListTransactions,
  useListAccounts,
  useListUpcomingEvents,
} from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import {
  ArrowDownRight,
  ArrowUpRight,
  TrendingUp,
  TrendingDown,
  Wifi,
  ChevronRight,
  Plus,
} from "lucide-react";
import { Area, AreaChart, ResponsiveContainer } from "recharts";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

export default function Dashboard() {
  const { data: summary } = useGetDashboardSummary();
  const { data: revenueFlow } = useGetRevenueFlow({ months: 6 });
  const { data: breakdown } = useGetSpendingByCategory();
  const { data: trend } = useGetSpendingTrend();
  const { data: txs } = useListTransactions({ limit: 5 });
  const { data: accounts } = useListAccounts();
  const { data: upcoming } = useListUpcomingEvents();

  const recentTxs = useMemo(() => (txs ?? []).slice(0, 5), [txs]);
  const heroAccounts = useMemo(
    () => (accounts ?? []).slice(0, 3),
    [accounts]
  );

  return (
    <Layout>
      {/* Page heading + filter pills */}
      <div className="flex flex-col gap-5 mb-6 mt-2">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          My Dashboard
        </h1>
        <FilterPills />
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* LEFT — Revenue Flow + bottom row */}
        <section className="col-span-12 xl:col-span-8 flex flex-col gap-6">
          <RevenueFlowCard data={revenueFlow ?? []} />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <AvailableCard
              total={summary?.totalBalance ?? 0}
              breakdown={breakdown ?? []}
            />
            <MoneyCard
              kind="income"
              amount={summary?.monthIncome ?? 0}
              changePct={summary?.incomeChangePct ?? 0}
            />
            <MoneyCard
              kind="expense"
              amount={summary?.monthExpense ?? 0}
              changePct={summary?.expenseChangePct ?? 0}
            />
          </div>
        </section>

        {/* RIGHT — Total Balance hero + recent transactions */}
        <section className="col-span-12 xl:col-span-4 flex flex-col gap-6">
          <TotalBalanceCard
            total={summary?.totalBalance ?? 0}
            accounts={heroAccounts}
          />

          <RecentTransactionsCard transactions={recentTxs} />

          <SpendingTrendCard data={trend ?? []} />

          <UpcomingCard events={(upcoming ?? []).slice(0, 3)} />
        </section>
      </div>
    </Layout>
  );
}

/* ---------- Filter pills ---------- */

function FilterPills() {
  const FILTERS = ["All", "Withdrawal", "Savings", "Deposit"];
  const [active, setActive] = useState("All");
  return (
    <div className="flex flex-wrap items-center gap-2.5">
      {FILTERS.map((f) => {
        const isActive = active === f;
        return (
          <button
            key={f}
            onClick={() => setActive(f)}
            className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
              isActive
                ? "text-[#0a1f17] shadow-[0_0_20px_rgba(124,240,189,0.25)]"
                : "text-muted-foreground hover:text-foreground bg-white/[0.04] border border-white/[0.06] hover:bg-white/[0.06]"
            }`}
            style={
              isActive
                ? { background: MINT }
                : undefined
            }
          >
            {f}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Revenue Flow (hatched bar chart) ---------- */

function RevenueFlowCard({
  data,
}: {
  data: { month: string; income: number; expense: number; net: number }[];
}) {
  const [activeIdx, setActiveIdx] = useState<number>(0);
  useEffect(() => {
    if (data.length > 0) setActiveIdx(data.length - 1);
  }, [data.length]);
  const max = Math.max(1, ...data.map((d) => d.income));
  const active = data[activeIdx] ?? data[0];

  return (
    <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6 md:p-7 relative overflow-hidden backdrop-blur-sm">
      <svg width="0" height="0" className="absolute">
        <defs>
          <pattern
            id="hatch-lavender"
            patternUnits="userSpaceOnUse"
            width="7"
            height="7"
            patternTransform="rotate(45)"
          >
            <rect width="7" height="7" fill="rgba(168,155,245,0.06)" />
            <line
              x1="0"
              y1="0"
              x2="0"
              y2="7"
              stroke="rgba(168,155,245,0.45)"
              strokeWidth="2"
            />
          </pattern>
          <pattern
            id="hatch-active"
            patternUnits="userSpaceOnUse"
            width="7"
            height="7"
            patternTransform="rotate(45)"
          >
            <rect width="7" height="7" fill="#A89BF5" />
            <line
              x1="0"
              y1="0"
              x2="0"
              y2="7"
              stroke="rgba(255,255,255,0.18)"
              strokeWidth="2"
            />
          </pattern>
        </defs>
      </svg>

      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-xl md:text-2xl font-bold tracking-tight">
            Revenue Flow
          </h3>
        </div>
        <button className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">
          View All <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex items-end gap-3 md:gap-5 h-[230px] px-1">
        {/* Y-axis labels */}
        <div className="flex flex-col justify-between h-full text-[10px] text-muted-foreground/70 pr-2 py-1">
          <span>2.5k$</span>
          <span>2.0k$</span>
          <span>1.5k$</span>
          <span>1.0k$</span>
          <span>0.5k$</span>
          <span>0$</span>
        </div>

        {data.map((d, i) => {
          const isActive = i === activeIdx;
          const h = (d.income / max) * 100;
          return (
            <button
              key={d.month}
              onClick={() => setActiveIdx(i)}
              className="group flex-1 flex flex-col items-center gap-3 h-full justify-end"
            >
              <div className="relative w-full flex justify-center items-end h-full">
                {isActive && (
                  <div
                    className="absolute left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shadow-lg z-10"
                    style={{
                      background: MINT,
                      color: "#0a1f17",
                      bottom: `calc(${Math.max(8, h)}% + 12px)`,
                    }}
                  >
                    +{formatCurrency(d.income)}
                    <div
                      className="absolute left-1/2 -translate-x-1/2 -bottom-1 w-2.5 h-2.5 rotate-45"
                      style={{ background: MINT }}
                    />
                  </div>
                )}
                {/* Income bar — hatched lavender; active = solid lavender */}
                <svg
                  className="w-full max-w-[52px] transition-all duration-300"
                  style={{ height: `${Math.max(8, h)}%` }}
                  preserveAspectRatio="none"
                  viewBox="0 0 50 100"
                >
                  <rect
                    x="0"
                    y="0"
                    width="50"
                    height="100"
                    rx="22"
                    ry="14"
                    fill={isActive ? LAVENDER : "url(#hatch-lavender)"}
                    stroke={
                      isActive ? "transparent" : "rgba(168,155,245,0.35)"
                    }
                    strokeWidth="0.6"
                  />
                </svg>
              </div>
              <span
                className={`text-xs font-medium transition-all ${
                  isActive
                    ? "text-foreground"
                    : "text-muted-foreground group-hover:text-foreground"
                }`}
              >
                {d.month}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Available pie ---------- */

function AvailableCard({
  total,
  breakdown,
}: {
  total: number;
  breakdown: { category: string; amount: number; color?: string | null }[];
}) {
  const fallbackColors = [MINT, LAVENDER, "#5EC9F2", "#F2C879", "#F291C8"];
  const totalAmt = breakdown.reduce((s, b) => s + b.amount, 0) || 1;
  let acc = 0;
  const segs = (breakdown.length > 0
    ? breakdown
    : [{ category: "—", amount: 1, color: MINT }]
  ).map((b, i) => {
    const pct = (b.amount / totalAmt) * 100;
    const start = acc;
    acc += pct;
    return {
      category: b.category,
      pct,
      start,
      end: acc,
      color: b.color ?? fallbackColors[i % fallbackColors.length],
    };
  });

  return (
    <div className="rounded-3xl bg-card border border-border p-6 flex flex-col">
      <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">
        Available
      </p>
      <div className="flex items-center gap-5">
        <div
          className="relative w-24 h-24 rounded-full shrink-0"
          style={{
            background: `conic-gradient(${segs
              .map((s) => `${s.color} ${s.start}% ${s.end}%`)
              .join(", ")})`,
          }}
        >
          <div className="absolute inset-2 rounded-full bg-card flex flex-col items-center justify-center">
            <span className="text-[10px] uppercase text-muted-foreground tracking-wider">
              Total
            </span>
            <span className="text-sm font-bold leading-none mt-0.5">
              {formatCompact(total)}
            </span>
          </div>
        </div>
        <div className="flex-1 min-w-0 space-y-2">
          {segs.slice(0, 3).map((s) => (
            <div key={s.category} className="flex items-center gap-2 text-xs">
              <span
                className="w-2 h-2 rounded-full"
                style={{ background: s.color }}
              />
              <span className="truncate flex-1 text-muted-foreground">
                {s.category}
              </span>
              <span className="font-semibold">{Math.round(s.pct)}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- Income / Expense ---------- */

function MoneyCard({
  kind,
  amount,
  changePct,
}: {
  kind: "income" | "expense";
  amount: number;
  changePct: number;
}) {
  const isIncome = kind === "income";
  const positive = isIncome ? changePct >= 0 : changePct <= 0;
  const Icon = isIncome ? ArrowUpRight : ArrowDownRight;
  const Trend = positive ? TrendingUp : TrendingDown;
  return (
    <div className="rounded-3xl bg-card border border-border p-6 flex flex-col justify-between">
      <div className="flex items-center justify-between mb-6">
        <div
          className="w-10 h-10 rounded-2xl flex items-center justify-center"
          style={{
            background: isIncome
              ? "rgba(124,240,189,0.14)"
              : "rgba(168,155,245,0.14)",
            color: isIncome ? MINT : LAVENDER,
          }}
        >
          <Icon className="w-5 h-5" />
        </div>
        <div
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${
            positive ? "text-primary" : "text-muted-foreground"
          }`}
          style={{
            background: positive
              ? "rgba(124,240,189,0.10)"
              : "rgba(255,255,255,0.04)",
          }}
        >
          <Trend className="w-3 h-3" />
          {Math.abs(changePct)}%
        </div>
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">
          {isIncome ? "Income" : "Expense"}
        </p>
        <p className="text-2xl font-bold tracking-tight">
          {formatCurrency(amount)}
        </p>
        <p className="text-xs text-muted-foreground mt-1">This month</p>
      </div>
    </div>
  );
}

/* ---------- Total Balance hero (stacked cards) ---------- */

function TotalBalanceCard({
  total,
  accounts,
}: {
  total: number;
  accounts: any[];
}) {
  const palette = [
    { from: "#7CF0BD", to: "#3DB78A", text: "#0a1f17" },
    { from: "#A89BF5", to: "#6E5DD9", text: "#1a1437" },
    { from: "#1E2A2C", to: "#0E1617", text: "#7CF0BD" },
  ];

  return (
    <div className="rounded-3xl bg-card border border-border p-6 relative">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">
            Total Balance
          </p>
          <h2 className="text-3xl font-bold tracking-tight">
            {formatCurrency(total)}
          </h2>
        </div>
        <Link
          href="/accounts"
          className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
        >
          View all <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      <div className="relative h-[260px]">
        {accounts.slice(0, 3).map((acc, i) => {
          const c = palette[i % palette.length];
          return (
            <div
              key={acc.id}
              className="absolute left-0 right-0 rounded-3xl p-5 shadow-2xl transition-all"
              style={{
                top: `${i * 60}px`,
                zIndex: 10 - i,
                background: `linear-gradient(135deg, ${c.from} 0%, ${c.to} 100%)`,
                color: c.text,
                height: "180px",
              }}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.2em] opacity-70">
                    {acc.kind}
                  </p>
                  <p className="font-semibold mt-1">{acc.name}</p>
                </div>
                <Wifi
                  className="w-5 h-5 rotate-90 opacity-80"
                  strokeWidth={2.5}
                />
              </div>
              <div className="absolute bottom-5 left-5 right-5">
                <p className="font-mono text-sm tracking-[0.25em] opacity-90 mb-2">
                  •••• •••• •••• {acc.cardLast4 ?? "0000"}
                </p>
                <div className="flex items-end justify-between">
                  <span className="text-xl font-bold tracking-tight">
                    {formatCurrency(acc.balance)}
                  </span>
                  <span className="text-[10px] uppercase opacity-70">
                    {acc.currency ?? "USD"}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Recent transactions ---------- */

function RecentTransactionsCard({ transactions }: { transactions: any[] }) {
  return (
    <div className="rounded-3xl bg-card border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold tracking-tight">Recent Transactions</h3>
        <Link
          href="/transactions"
          className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
        >
          See all <ChevronRight className="w-3 h-3" />
        </Link>
      </div>
      <div className="space-y-3">
        {transactions.length === 0 && (
          <p className="text-sm text-muted-foreground py-4 text-center">
            No transactions yet
          </p>
        )}
        {transactions.map((tx) => (
          <div key={tx.id} className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
              style={{
                background:
                  tx.type === "income"
                    ? "rgba(124,240,189,0.14)"
                    : "rgba(168,155,245,0.14)",
                color: tx.type === "income" ? MINT : LAVENDER,
              }}
            >
              {tx.type === "income" ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">
                {tx.merchant ?? tx.description ?? tx.category}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {tx.category}
              </p>
            </div>
            <div
              className={`text-sm font-semibold ${
                tx.type === "income" ? "text-primary" : "text-foreground"
              }`}
            >
              {tx.type === "income" ? "+" : "-"}
              {formatCurrency(tx.amount)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Spending sparkline ---------- */

function SpendingTrendCard({
  data,
}: {
  data: { date: string; amount: number }[];
}) {
  const total = data.reduce((s, d) => s + d.amount, 0);
  return (
    <div className="rounded-3xl bg-card border border-border p-6 relative overflow-hidden">
      <div className="flex items-start justify-between mb-2">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">
            Spending — last 7 days
          </p>
          <p className="text-2xl font-bold tracking-tight">
            {formatCurrency(total)}
          </p>
        </div>
      </div>
      <div className="h-[80px] -mx-2 -mb-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={LAVENDER} stopOpacity={0.5} />
                <stop offset="100%" stopColor={LAVENDER} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="amount"
              stroke={LAVENDER}
              strokeWidth={2.5}
              fill="url(#sparkFill)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

/* ---------- Upcoming events ---------- */

function UpcomingCard({ events }: { events: any[] }) {
  return (
    <div className="rounded-3xl bg-card border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold tracking-tight">Upcoming</h3>
        <Link
          href="/calendar"
          className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
        >
          Calendar <ChevronRight className="w-3 h-3" />
        </Link>
      </div>
      {events.length === 0 ? (
        <p className="text-sm text-muted-foreground py-2">Nothing scheduled.</p>
      ) : (
        <div className="space-y-3">
          {events.map((e) => {
            const d = new Date(e.scheduledAt);
            return (
              <div key={e.id} className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-2xl flex flex-col items-center justify-center shrink-0"
                  style={{
                    background: `${e.color ?? MINT}22`,
                    color: e.color ?? MINT,
                  }}
                >
                  <span className="text-[9px] uppercase font-bold leading-none">
                    {d.toLocaleString("en", { month: "short" })}
                  </span>
                  <span className="text-sm font-bold leading-none mt-0.5">
                    {d.getDate()}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{e.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {d.toLocaleTimeString("en", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}{" "}
                    · {e.kind}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------- helpers ---------- */

function formatCompact(n: number) {
  if (n >= 1000) return `$${(n / 1000).toFixed(1)}k`;
  return `$${n.toFixed(0)}`;
}
