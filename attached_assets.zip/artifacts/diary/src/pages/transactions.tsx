import { useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListTransactions,
  useCreateTransaction,
  useDeleteTransaction,
  getListTransactionsQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  ArrowDownRight,
  ArrowUpRight,
  Plus,
  Trash2,
  Filter,
} from "lucide-react";
import { formatCurrency, formatShortDate } from "@/lib/utils";
import { useT } from "@/lib/i18n";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

export default function Transactions() {
  const t = useT();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"all" | "income" | "expense">("all");
  const { data: txs, isLoading } = useListTransactions();
  const create = useCreateTransaction();
  const del = useDeleteTransaction();

  const [open, setOpen] = useState(false);
  const [type, setType] = useState<"income" | "expense">("expense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [merchant, setMerchant] = useState("");
  const [description, setDescription] = useState("");

  const reset = () => {
    setAmount("");
    setCategory("");
    setMerchant("");
    setDescription("");
    setType("expense");
  };

  const handleCreate = () => {
    if (!amount || !category) return;
    create.mutate(
      {
        data: {
          type,
          amount: parseFloat(amount),
          category,
          merchant: merchant || undefined,
          description: description || undefined,
          occurredAt: new Date().toISOString(),
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
          setOpen(false);
          reset();
        },
      }
    );
  };

  const filtered = useMemo(() => {
    return (txs ?? []).filter((t) => filter === "all" || t.type === filter);
  }, [txs, filter]);

  const totalIn = useMemo(
    () => (txs ?? []).filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0),
    [txs]
  );
  const totalOut = useMemo(
    () => (txs ?? []).filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0),
    [txs]
  );

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{t("nav.transactions")}</h1>
            <p className="text-muted-foreground mt-1">
              {t("tx.subtitle")}
            </p>
          </div>
          <Dialog
            open={open}
            onOpenChange={(o) => {
              setOpen(o);
              if (!o) reset();
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full">
                <Plus className="w-4 h-4 mr-2" /> {t("tx.add")}
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle>{t("tx.new")}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="flex gap-2">
                  {(["expense", "income"] as const).map((tkey) => (
                    <button
                      key={tkey}
                      onClick={() => setType(tkey)}
                      className={`flex-1 py-2 rounded-xl text-sm font-semibold transition ${
                        type === tkey
                          ? "bg-primary text-primary-foreground"
                          : "bg-background border border-border text-muted-foreground"
                      }`}
                    >
                      {tkey === "income" ? t("common.income") : t("common.expense")}
                    </button>
                  ))}
                </div>
                <Input
                  type="number"
                  step="0.01"
                  placeholder={t("tx.amount")}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <Input
                  placeholder={t("tx.category")}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                />
                <Input
                  placeholder={t("tx.merchantOptional")}
                  value={merchant}
                  onChange={(e) => setMerchant(e.target.value)}
                />
                <Input
                  placeholder={t("tx.descriptionOptional")}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  {t("common.cancel")}
                </Button>
                <Button onClick={handleCreate} disabled={!amount || !category}>
                  {t("common.save")}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SummaryTile
            label={t("common.income")}
            amount={totalIn}
            color={MINT}
            kind="income"
          />
          <SummaryTile
            label={t("common.expense")}
            amount={totalOut}
            color={LAVENDER}
            kind="expense"
          />
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <div className="flex gap-1 bg-background rounded-full p-1">
                {(["all", "income", "expense"] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold transition ${
                      filter === f
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground"
                    }`}
                  >
                    {t(`tx.filter.${f}` as any)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {isLoading ? (
            <p className="text-muted-foreground text-sm py-4">{t("common.loading")}</p>
          ) : filtered.length === 0 ? (
            <p className="text-muted-foreground text-sm py-8 text-center">
              {t("tx.empty")}
            </p>
          ) : (
            <div className="divide-y divide-border">
              {filtered.map((tx) => (
                <div
                  key={tx.id}
                  className="flex items-center gap-4 py-3 group"
                >
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{
                      background:
                        tx.type === "income"
                          ? "rgba(124,240,189,0.14)"
                          : "rgba(168,155,245,0.14)",
                      color: tx.type === "income" ? MINT : LAVENDER,
                    }}
                  >
                    {tx.type === "income" ? (
                      <ArrowUpRight className="w-5 h-5" />
                    ) : (
                      <ArrowDownRight className="w-5 h-5" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">
                      {tx.merchant ?? tx.description ?? tx.category}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {tx.category} · {formatShortDate(tx.occurredAt)}
                    </p>
                  </div>
                  <div
                    className={`text-base font-semibold ${
                      tx.type === "income" ? "text-primary" : ""
                    }`}
                  >
                    {tx.type === "income" ? "+" : "-"}
                    {formatCurrency(tx.amount)}
                  </div>
                  <button
                    onClick={() =>
                      del.mutate(
                        { id: tx.id },
                        {
                          onSuccess: () =>
                            qc.invalidateQueries({
                              queryKey: getListTransactionsQueryKey(),
                            }),
                        }
                      )
                    }
                    className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function SummaryTile({
  label,
  amount,
  color,
  kind,
}: {
  label: string;
  amount: number;
  color: string;
  kind: "income" | "expense";
}) {
  return (
    <div className="rounded-3xl bg-card border border-border p-6 flex items-center gap-4">
      <div
        className="w-12 h-12 rounded-2xl flex items-center justify-center"
        style={{ background: `${color}22`, color }}
      >
        {kind === "income" ? (
          <ArrowUpRight className="w-6 h-6" />
        ) : (
          <ArrowDownRight className="w-6 h-6" />
        )}
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          {label}
        </p>
        <p className="text-2xl font-bold tracking-tight">
          {formatCurrency(amount)}
        </p>
      </div>
    </div>
  );
}
