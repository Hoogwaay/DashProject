import { useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { useListNotes, useCreateNote, useDeleteNote, useUpdateNote, getListNotesQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Pin, Trash2, Edit3, Plus, StickyNote } from "lucide-react";
import { formatShortDate } from "@/lib/utils";
import { useT } from "@/lib/i18n";

export default function Notes() {
  const t = useT();
  const queryClient = useQueryClient();
  const { data: notes, isLoading } = useListNotes();
  const createNote = useCreateNote();
  const updateNote = useUpdateNote();
  const deleteNote = useDeleteNote();

  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const handleSave = () => {
    if (editingId) {
      updateNote.mutate({
        id: editingId,
        data: { title, content }
      }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
          setIsOpen(false);
          reset();
        }
      });
    } else {
      createNote.mutate({
        data: { title, content }
      }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
          setIsOpen(false);
          reset();
        }
      });
    }
  };

  const handleDelete = (id: number) => {
    deleteNote.mutate({ id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() })
    });
  };

  const handleTogglePin = (id: number, currentPinned: boolean) => {
    updateNote.mutate({
      id,
      data: { pinned: !currentPinned }
    }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() })
    });
  };

  const reset = () => {
    setTitle("");
    setContent("");
    setEditingId(null);
  };

  const openEdit = (note: any) => {
    setTitle(note.title);
    setContent(note.content);
    setEditingId(note.id);
    setIsOpen(true);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-8 w-32 bg-card rounded mb-4"></div>
            <div className="h-4 w-48 bg-card/50 rounded"></div>
          </div>
        </div>
      </Layout>
    );
  }

  const pinnedNotes = notes?.filter(n => n.pinned) || [];
  const otherNotes = notes?.filter(n => !n.pinned) || [];

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">{t("notes.title")}</h1>
            <p className="text-muted-foreground mt-1">{t("notes.subtitle")}</p>
          </div>
          
          <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if(!open) reset(); }}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                {t("notes.new")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] bg-card border-border">
              <DialogHeader>
                <DialogTitle>{editingId ? t("notes.edit") : t("notes.create")}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Input 
                    placeholder={t("notes.titlePlaceholder")} 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="bg-background border-border text-lg font-semibold"
                  />
                </div>
                <div className="space-y-2">
                  <Textarea 
                    placeholder={t("notes.contentPlaceholder")} 
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="bg-background border-border min-h-[150px] resize-none"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setIsOpen(false)}>{t("common.cancel")}</Button>
                <Button onClick={handleSave} disabled={!title.trim()}>{t("notes.save")}</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {pinnedNotes.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
              <Pin className="w-4 h-4" /> {t("notes.pinned")}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pinnedNotes.map(note => (
                <NoteCard key={note.id} note={note} onTogglePin={handleTogglePin} onDelete={handleDelete} onEdit={openEdit} />
              ))}
            </div>
          </div>
        )}

        <div className="space-y-4">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
            {pinnedNotes.length > 0 ? t("notes.others") : t("notes.allNotes")}
          </h2>
          {otherNotes.length === 0 ? (
            <div className="text-center py-12 bg-card/30 border border-border/50 rounded-2xl">
              <StickyNote className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground">{t("notes.empty")}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {otherNotes.map(note => (
                <NoteCard key={note.id} note={note} onTogglePin={handleTogglePin} onDelete={handleDelete} onEdit={openEdit} />
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function NoteCard({ note, onTogglePin, onDelete, onEdit }: { note: any, onTogglePin: any, onDelete: any, onEdit: any }) {
  return (
    <div className="group relative bg-card border border-border rounded-2xl p-5 hover:border-primary/50 transition-all duration-300 flex flex-col shadow-sm hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-semibold text-lg line-clamp-1 flex-1 pr-4">{note.title}</h3>
        <button 
          onClick={() => onTogglePin(note.id, note.pinned)}
          className={`shrink-0 transition-colors ${note.pinned ? 'text-primary' : 'text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100'}`}
        >
          <Pin className="w-4 h-4" />
        </button>
      </div>
      <p className="text-muted-foreground text-sm line-clamp-4 flex-1 mb-4 leading-relaxed">
        {note.content}
      </p>
      <div className="flex items-center justify-between text-xs text-muted-foreground/70 pt-3 border-t border-border/50">
        <span>{formatShortDate(note.updatedAt || note.createdAt)}</span>
        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={() => onEdit(note)} className="hover:text-primary transition-colors p-1">
            <Edit3 className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => onDelete(note.id)} className="hover:text-destructive transition-colors p-1">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
