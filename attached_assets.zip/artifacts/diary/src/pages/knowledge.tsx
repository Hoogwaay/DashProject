import { useState, useMemo, useRef, useEffect } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListKnowledgeNotes,
  useCreateKnowledgeNote,
  useUpdateKnowledgeNote,
  useDeleteKnowledgeNote,
  useGetKnowledgeGraph,
  useCreateKnowledgeLink,
  useDeleteKnowledgeLink,
  getListKnowledgeNotesQueryKey,
  getGetKnowledgeGraphQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Plus,
  Trash2,
  FileText,
  Search,
  Network,
  List,
  Link as LinkIcon,
  Save,
  X,
  Sparkles,
  MousePointer2,
} from "lucide-react";
import { useT } from "@/lib/i18n";

type View = "list" | "graph";

const COLORS = ["#7CF0BD", "#A89BF5", "#F2C879", "#5EC9F2", "#F291C8", "#FFB199", "#9DE2A2"];

export default function Knowledge() {
  const t = useT();
  const [view, setView] = useState<View>("list");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [search, setSearch] = useState("");

  return (
    <Layout>
      <div className="flex items-end justify-between mb-6 mt-2 flex-wrap gap-3">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">{t("kn.title")}</h1>
          <p className="text-sm text-muted-foreground mt-2">
            {t("kn.subtitle")}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-white/[0.04] rounded-full p-1 border border-white/[0.06]">
            <button
              onClick={() => setView("list")}
              className={`flex items-center gap-1.5 px-3 h-8 rounded-full text-xs font-medium transition-all ${
                view === "list" ? "bg-white text-[#0a1f17]" : "text-muted-foreground"
              }`}
            >
              <List className="w-3.5 h-3.5" /> {t("kn.notes")}
            </button>
            <button
              onClick={() => setView("graph")}
              className={`flex items-center gap-1.5 px-3 h-8 rounded-full text-xs font-medium transition-all ${
                view === "graph"
                  ? "bg-white text-[#0a1f17]"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              title={t("kn.mindMapTitle")}
            >
              <Sparkles className="w-3.5 h-3.5" /> {t("kn.mindMap")}
            </button>
          </div>
        </div>
      </div>

      {view === "list" && (
        <ListView
          search={search}
          setSearch={setSearch}
          selectedId={selectedId}
          setSelectedId={setSelectedId}
        />
      )}
      {view === "graph" && <GraphView onSelectNote={(id) => { setSelectedId(id); setView("list"); }} />}
    </Layout>
  );
}

function ListView({
  search,
  setSearch,
  selectedId,
  setSelectedId,
}: {
  search: string;
  setSearch: (v: string) => void;
  selectedId: number | null;
  setSelectedId: (v: number | null) => void;
}) {
  const t = useT();
  const queryClient = useQueryClient();
  const { data: notes } = useListKnowledgeNotes();
  const create = useCreateKnowledgeNote();
  const update = useUpdateKnowledgeNote();
  const remove = useDeleteKnowledgeNote();
  const createLink = useCreateKnowledgeLink();

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getListKnowledgeNotesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetKnowledgeGraphQueryKey() });
  };

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return (notes ?? []).filter(
      (n) =>
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        (n.tags?.toLowerCase().includes(q) ?? false),
    );
  }, [notes, search]);

  const selected = (notes ?? []).find((n) => n.id === selectedId) ?? null;
  const [editTitle, setEditTitle] = useState("");
  const [editContent, setEditContent] = useState("");
  const [editTags, setEditTags] = useState("");
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (selected) {
      setEditTitle(selected.title);
      setEditContent(selected.content);
      setEditTags(selected.tags ?? "");
      setDirty(false);
    }
  }, [selected?.id]);

  const handleNew = () => {
    create.mutate(
      {
        data: {
          title: t("kn.untitled"),
          content: "",
          color: COLORS[(notes?.length ?? 0) % COLORS.length],
        },
      },
      {
        onSuccess: (n) => {
          refetch();
          setSelectedId(n.id);
        },
      },
    );
  };

  const handleSave = () => {
    if (!selected) return;
    update.mutate(
      {
        id: selected.id,
        data: {
          title: editTitle,
          content: editContent,
          tags: editTags || null,
        },
      },
      {
        onSuccess: async () => {
          // Parse [[link]] references and create links automatically
          const allNotes = notes ?? [];
          const linkPattern = /\[\[([^\]]+)\]\]/g;
          const titles = new Set<string>();
          let m;
          while ((m = linkPattern.exec(editContent))) {
            titles.add(m[1].trim().toLowerCase());
          }
          for (const title of titles) {
            const target = allNotes.find(
              (n) => n.title.toLowerCase() === title && n.id !== selected.id,
            );
            if (target) {
              try {
                await createLink.mutateAsync({
                  data: { fromNoteId: selected.id, toNoteId: target.id },
                });
              } catch {
                /* link may already exist */
              }
            }
          }
          refetch();
          setDirty(false);
        },
      },
    );
  };

  const handleDelete = (id: number) => {
    if (!confirm(t("kn.deleteConfirm"))) return;
    remove.mutate(
      { id },
      {
        onSuccess: () => {
          refetch();
          if (selectedId === id) setSelectedId(null);
        },
      },
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-[260px_1fr] gap-4 h-[calc(100vh-280px)] min-h-[500px]">
      <aside className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-3 flex flex-col overflow-hidden">
        <div className="flex items-center gap-2 mb-3">
          <div className="flex-1 relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder={t("kn.search")}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full h-9 bg-white/[0.04] border border-white/[0.06] rounded-full pl-9 pr-3 text-xs focus:outline-none focus:bg-white/[0.06] focus:border-primary/30"
            />
          </div>
          <button
            onClick={handleNew}
            className="w-9 h-9 rounded-full bg-primary text-[#0a1f17] flex items-center justify-center hover:brightness-110"
            title={t("kn.newNote")}
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto space-y-1 -mx-1 px-1 no-scrollbar">
          {filtered.map((n) => (
            <button
              key={n.id}
              onClick={() => setSelectedId(n.id)}
              className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center gap-2 ${
                selectedId === n.id ? "bg-white/[0.08]" : "hover:bg-white/[0.04]"
              }`}
            >
              <div
                className="w-1.5 h-1.5 rounded-full shrink-0"
                style={{ background: n.color ?? "#7CF0BD" }}
              />
              <span className="text-sm font-medium truncate flex-1">{n.title}</span>
            </button>
          ))}
          {filtered.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-4">{t("kn.noNotes")}</p>
          )}
        </div>
      </aside>

      <main className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 overflow-hidden flex flex-col">
        {selected ? (
          <>
            <div className="flex items-center gap-2 mb-3">
              <Input
                value={editTitle}
                onChange={(e) => {
                  setEditTitle(e.target.value);
                  setDirty(true);
                }}
                className="text-lg font-bold h-11 border-none bg-transparent px-0 focus-visible:ring-0"
              />
              {dirty && (
                <Button onClick={handleSave} size="sm" disabled={update.isPending}>
                  <Save className="w-3.5 h-3.5 mr-1" /> {t("common.save")}
                </Button>
              )}
              <button
                onClick={() => handleDelete(selected.id)}
                className="text-muted-foreground hover:text-destructive p-2"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <Input
              value={editTags}
              onChange={(e) => {
                setEditTags(e.target.value);
                setDirty(true);
              }}
              placeholder={t("kn.tagsPlaceholder")}
              className="text-xs h-8 mb-3 bg-white/[0.02]"
            />
            <Textarea
              value={editContent}
              onChange={(e) => {
                setEditContent(e.target.value);
                setDirty(true);
              }}
              placeholder={t("kn.contentPlaceholder")}
              className="flex-1 min-h-0 resize-none border-white/[0.06] bg-white/[0.02] font-mono text-sm leading-relaxed"
            />
            <div className="mt-3 text-[11px] text-muted-foreground flex items-center gap-2">
              <LinkIcon className="w-3 h-3" />
              {t("kn.linkTip")} <code className="px-1 py-0.5 bg-white/[0.05] rounded">[[Title]]</code> {t("kn.linkTipSuffix")}
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
            <FileText className="w-12 h-12 mb-3 opacity-30" />
            <p className="text-sm">{t("kn.selectOrCreate")}</p>
          </div>
        )}
      </main>
    </div>
  );
}

/* ---------- Graph view ---------- */

interface NodePos {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  title: string;
  color: string;
}

function GraphView({ onSelectNote }: { onSelectNote: (id: number) => void }) {
  const t = useT();
  const queryClient = useQueryClient();
  const { data: graph } = useGetKnowledgeGraph();
  const removeLink = useDeleteKnowledgeLink();
  const createLink = useCreateKnowledgeLink();
  const updateNote = useUpdateKnowledgeNote();
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [size, setSize] = useState({ w: 800, h: 500 });
  const [nodes, setNodes] = useState<NodePos[]>([]);
  const [draggingId, setDraggingId] = useState<number | null>(null);
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const [connectMode, setConnectMode] = useState(false);
  const [connectFromId, setConnectFromId] = useState<number | null>(null);
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null);
  const animFrameRef = useRef<number>(0);
  const dragStartRef = useRef<{ x: number; y: number; t: number } | null>(null);

  const refetchGraph = () =>
    queryClient.invalidateQueries({ queryKey: getGetKnowledgeGraphQueryKey() });

  useEffect(() => {
    const measure = () => {
      if (containerRef.current) {
        const r = containerRef.current.getBoundingClientRect();
        setSize({ w: r.width, h: r.height });
      }
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  // Init node positions
  useEffect(() => {
    if (!graph) return;
    const cx = size.w / 2;
    const cy = size.h / 2;
    const r = Math.min(size.w, size.h) / 3;
    setNodes(
      graph.notes.map((n, i) => ({
        id: n.id,
        x: n.x ?? cx + Math.cos((i / graph.notes.length) * Math.PI * 2) * r,
        y: n.y ?? cy + Math.sin((i / graph.notes.length) * Math.PI * 2) * r,
        vx: 0,
        vy: 0,
        title: n.title,
        color: n.color ?? "#7CF0BD",
      })),
    );
  }, [graph?.notes.length, size.w, size.h]);

  // Force-directed simulation
  useEffect(() => {
    if (!graph || nodes.length === 0) return;
    const tick = () => {
      setNodes((prev) => {
        const next = prev.map((n) => ({ ...n }));
        const repulsion = 5200;
        const linkForce = 0.012;
        const targetDist = 150;
        const damping = 0.84;
        for (let i = 0; i < next.length; i++) {
          for (let j = i + 1; j < next.length; j++) {
            const dx = next[j].x - next[i].x;
            const dy = next[j].y - next[i].y;
            const d2 = Math.max(50, dx * dx + dy * dy);
            const f = repulsion / d2;
            const d = Math.sqrt(d2);
            const fx = (dx / d) * f;
            const fy = (dy / d) * f;
            next[i].vx -= fx;
            next[i].vy -= fy;
            next[j].vx += fx;
            next[j].vy += fy;
          }
        }
        for (const link of graph.links) {
          const a = next.find((n) => n.id === link.fromNoteId);
          const b = next.find((n) => n.id === link.toNoteId);
          if (!a || !b) continue;
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const d = Math.sqrt(dx * dx + dy * dy) || 1;
          const f = (d - targetDist) * linkForce;
          const fx = (dx / d) * f;
          const fy = (dy / d) * f;
          a.vx += fx;
          a.vy += fy;
          b.vx -= fx;
          b.vy -= fy;
        }
        const cx = size.w / 2;
        const cy = size.h / 2;
        for (const n of next) {
          if (n.id === draggingId) continue;
          n.vx += (cx - n.x) * 0.0015;
          n.vy += (cy - n.y) * 0.0015;
          n.vx *= damping;
          n.vy *= damping;
          n.x += n.vx;
          n.y += n.vy;
          n.x = Math.max(40, Math.min(size.w - 40, n.x));
          n.y = Math.max(40, Math.min(size.h - 40, n.y));
        }
        return next;
      });
      animFrameRef.current = requestAnimationFrame(tick);
    };
    animFrameRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [graph?.links.length, nodes.length, size.w, size.h, draggingId]);

  const onMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const r = containerRef.current.getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;
    if (connectMode && connectFromId !== null) setCursor({ x, y });
    if (draggingId === null) return;
    setNodes((prev) => prev.map((n) => (n.id === draggingId ? { ...n, x, y, vx: 0, vy: 0 } : n)));
  };

  const onMouseUp = () => {
    if (draggingId === null) return;
    const node = nodes.find((n) => n.id === draggingId);
    const start = dragStartRef.current;
    const moved =
      start && node ? Math.hypot(node.x - start.x, node.y - start.y) > 4 : false;
    if (node && moved) {
      updateNote.mutate({
        id: node.id,
        data: { x: node.x, y: node.y },
      });
    }
    setDraggingId(null);
    dragStartRef.current = null;
  };

  const handleNodeClick = (id: number) => {
    if (!connectMode) return;
    if (connectFromId === null) {
      setConnectFromId(id);
      return;
    }
    if (connectFromId === id) {
      setConnectFromId(null);
      return;
    }
    // Avoid duplicate link
    const exists = graph?.links.some(
      (l) =>
        (l.fromNoteId === connectFromId && l.toNoteId === id) ||
        (l.fromNoteId === id && l.toNoteId === connectFromId),
    );
    if (exists) {
      setConnectFromId(null);
      return;
    }
    createLink.mutate(
      { data: { fromNoteId: connectFromId, toNoteId: id } },
      {
        onSuccess: () => {
          refetchGraph();
          setConnectFromId(null);
        },
      },
    );
  };

  const exitConnectMode = () => {
    setConnectMode(false);
    setConnectFromId(null);
    setCursor(null);
  };

  const fromNode = connectFromId !== null ? nodes.find((n) => n.id === connectFromId) : null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="text-xs text-muted-foreground">
          {connectMode
            ? connectFromId === null
              ? t("kn.connectModeStart")
              : t("kn.connectModeNext")
            : t("kn.dragHint")}
        </div>
        <div className="flex items-center gap-2">
          {connectMode && (
            <button
              onClick={exitConnectMode}
              className="h-9 px-3 rounded-full text-xs font-semibold bg-white/[0.06] hover:bg-white/[0.1] text-foreground inline-flex items-center gap-1.5"
            >
              <X className="w-3.5 h-3.5" /> {t("kn.exitConnect")}
            </button>
          )}
          {!connectMode && (
            <button
              onClick={() => setConnectMode(true)}
              className="h-9 px-3 rounded-full text-xs font-semibold bg-primary text-[#0a1f17] hover:brightness-110 inline-flex items-center gap-1.5"
            >
              <MousePointer2 className="w-3.5 h-3.5" /> {t("kn.connectNotes")}
            </button>
          )}
        </div>
      </div>

      <div
        ref={containerRef}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={() => {
          onMouseUp();
          if (connectMode) setCursor(null);
        }}
        className={`rounded-3xl bg-[radial-gradient(circle_at_center,_rgba(124,240,189,0.04),_rgba(0,0,0,0)_60%)] border border-white/[0.06] relative overflow-hidden h-[calc(100vh-320px)] min-h-[520px] ${
          connectMode ? "cursor-crosshair" : ""
        }`}
      >
        <svg width={size.w} height={size.h} className="absolute inset-0 pointer-events-none">
          {/* Existing links */}
          <g>
            {graph?.links.map((link) => {
              const a = nodes.find((n) => n.id === link.fromNoteId);
              const b = nodes.find((n) => n.id === link.toNoteId);
              if (!a || !b) return null;
              const isHover = hoveredId === a.id || hoveredId === b.id;
              return (
                <line
                  key={link.id}
                  x1={a.x}
                  y1={a.y}
                  x2={b.x}
                  y2={b.y}
                  stroke={isHover ? "#7CF0BD" : "rgba(255,255,255,0.18)"}
                  strokeWidth={isHover ? 2 : 1.2}
                  className="pointer-events-auto cursor-pointer"
                  onClick={() => {
                    if (confirm(t("kn.removeLinkConfirm"))) {
                      removeLink.mutate({ id: link.id }, { onSuccess: refetchGraph });
                    }
                  }}
                />
              );
            })}
          </g>
          {/* Live preview line when connecting */}
          {connectMode && fromNode && cursor && (
            <line
              x1={fromNode.x}
              y1={fromNode.y}
              x2={cursor.x}
              y2={cursor.y}
              stroke="#7CF0BD"
              strokeWidth={1.5}
              strokeDasharray="4 4"
            />
          )}
        </svg>
        {nodes.map((n) => {
          const isHovered = hoveredId === n.id;
          const isConnectSource = connectFromId === n.id;
          // Compute degree for sizing
          const degree =
            graph?.links.filter((l) => l.fromNoteId === n.id || l.toNoteId === n.id).length ?? 0;
          const dotSize = 10 + Math.min(14, degree * 2);
          return (
            <div
              key={n.id}
              onMouseEnter={() => setHoveredId(n.id)}
              onMouseLeave={() => setHoveredId(null)}
              onMouseDown={(e) => {
                if (connectMode) return;
                e.preventDefault();
                setDraggingId(n.id);
                dragStartRef.current = { x: n.x, y: n.y, t: Date.now() };
              }}
              onClick={() => handleNodeClick(n.id)}
              onDoubleClick={() => !connectMode && onSelectNote(n.id)}
              style={{
                left: n.x,
                top: n.y,
                transform: `translate(-50%, -50%)`,
                zIndex: isHovered || isConnectSource ? 10 : 5,
              }}
              className={`absolute select-none flex flex-col items-center ${
                connectMode ? "cursor-pointer" : "cursor-grab active:cursor-grabbing"
              }`}
              title={
                connectMode
                  ? t("kn.connectTip")
                  : `${n.title} — ${t("kn.nodeTip")}`
              }
            >
              {/* Glow ring when source of in-progress link */}
              {isConnectSource && (
                <div
                  className="absolute rounded-full pointer-events-none"
                  style={{
                    width: dotSize + 18,
                    height: dotSize + 18,
                    boxShadow: `0 0 0 2px ${n.color}, 0 0 24px ${n.color}`,
                    transform: "translate(-50%, -50%)",
                    left: "50%",
                    top: dotSize / 2,
                  }}
                />
              )}
              <div
                className="rounded-full transition-transform"
                style={{
                  width: dotSize,
                  height: dotSize,
                  background: n.color,
                  boxShadow: isHovered
                    ? `0 0 16px ${n.color}, 0 0 0 4px rgba(255,255,255,0.06)`
                    : `0 0 8px ${n.color}80`,
                  transform: `scale(${isHovered ? 1.4 : 1})`,
                }}
              />
              <span
                className={`mt-1.5 text-[10px] font-medium whitespace-nowrap max-w-[140px] overflow-hidden text-ellipsis transition-all ${
                  isHovered || isConnectSource
                    ? "text-foreground"
                    : "text-muted-foreground/70"
                }`}
              >
                {n.title}
              </span>
            </div>
          );
        })}
        {(graph?.notes.length ?? 0) === 0 && (
          <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm">
            {t("kn.emptyGraph")}
          </div>
        )}
        <div className="absolute bottom-3 left-3 text-[10px] text-muted-foreground bg-black/40 backdrop-blur px-3 py-1.5 rounded-full border border-white/[0.06]">
          {connectMode ? t("kn.legendConnect") : t("kn.legendDrag")}
        </div>
      </div>
    </div>
  );
}
