import { useMemo, useState } from "react";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListBodyMetrics,
  useGetBodySummary,
  useCreateBodyMetric,
  useDeleteBodyMetric,
  getListBodyMetricsQueryKey,
  getGetBodySummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, Trash2, Activity, TrendingUp, TrendingDown } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { formatShortDate } from "@/lib/utils";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

export default function Body() {
  const qc = useQueryClient();
  const { data: metrics } = useListBodyMetrics();
  const { data: summary } = useGetBodySummary();
  const create = useCreateBodyMetric();
  const del = useDeleteBodyMetric();

  const [open, setOpen] = useState(false);
  const [recordedAt, setMeasuredAt] = useState(
    new Date().toISOString().slice(0, 10)
  );
  const [weightKg, setWeightKg] = useState("");
  const [bodyFatPct, setBodyFatPct] = useState("");
  const [waistCm, setWaistCm] = useState("");
  const [chestCm, setChestCm] = useState("");
  const [hipsCm, setHipsCm] = useState("");
  const [notes, setNotes] = useState("");

  const reset = () => {
    setMeasuredAt(new Date().toISOString().slice(0, 10));
    setWeightKg("");
    setBodyFatPct("");
    setWaistCm("");
    setChestCm("");
    setHipsCm("");
    setNotes("");
  };

  const handleCreate = () => {
    if (!weightKg) return;
    create.mutate(
      {
        data: {
          recordedAt,
          weightKg: parseFloat(weightKg),
          bodyFatPct: bodyFatPct ? parseFloat(bodyFatPct) : undefined,
          waistCm: waistCm ? parseFloat(waistCm) : undefined,
          chestCm: chestCm ? parseFloat(chestCm) : undefined,
          hipsCm: hipsCm ? parseFloat(hipsCm) : undefined,
          notes: notes || undefined,
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListBodyMetricsQueryKey() });
          qc.invalidateQueries({ queryKey: getGetBodySummaryQueryKey() });
          setOpen(false);
          reset();
        },
      }
    );
  };

  const chartData = useMemo(
    () =>
      [...(metrics ?? [])]
        .sort(
          (a, b) =>
            new Date(a.recordedAt).getTime() - new Date(b.recordedAt).getTime()
        )
        .map((m) => ({
          date: formatShortDate(m.recordedAt),
          weight: m.weightKg,
          fat: m.bodyFatPct ?? null,
        })),
    [metrics]
  );

  const change = summary?.weightDelta30 ?? 0;
  const changePositive = change <= 0; // weight loss is positive trend usually

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Body Metrics</h1>
            <p className="text-muted-foreground mt-1">
              Track weight, body fat and measurements.
            </p>
          </div>
          <Dialog
            open={open}
            onOpenChange={(o) => {
              setOpen(o);
              if (!o) reset();
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full">
                <Plus className="w-4 h-4 mr-2" /> Log measurement
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle>New measurement</DialogTitle>
              </DialogHeader>
              <div className="grid gap-3 py-4">
                <Input
                  type="date"
                  value={recordedAt}
                  onChange={(e) => setMeasuredAt(e.target.value)}
                />
                <div className="grid grid-cols-2 gap-3">
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Weight (kg)"
                    value={weightKg}
                    onChange={(e) => setWeightKg(e.target.value)}
                  />
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Body fat (%)"
                    value={bodyFatPct}
                    onChange={(e) => setBodyFatPct(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Waist (cm)"
                    value={waistCm}
                    onChange={(e) => setWaistCm(e.target.value)}
                  />
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Chest (cm)"
                    value={chestCm}
                    onChange={(e) => setChestCm(e.target.value)}
                  />
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Hips (cm)"
                    value={hipsCm}
                    onChange={(e) => setHipsCm(e.target.value)}
                  />
                </div>
                <Input
                  placeholder="Notes (optional)"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={!weightKg}>
                  Save
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatCard
            label="Latest weight"
            value={
              summary?.latest?.weightKg
                ? `${summary.latest!.weightKg!.toFixed(1)} kg`
                : "—"
            }
            change={
              change !== 0 ? `${change > 0 ? "+" : ""}${change.toFixed(1)} kg` : "—"
            }
            positive={changePositive}
            color={MINT}
          />
          <StatCard
            label="Body fat"
            value={
              summary?.latest?.bodyFatPct
                ? `${summary.latest!.bodyFatPct!.toFixed(1)}%`
                : "—"
            }
            change="last log"
            positive={true}
            color={LAVENDER}
          />
          <StatCard
            label="Entries"
            value={`${metrics?.length ?? 0}`}
            change="all time"
            positive={true}
            color="#5EC9F2"
          />
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <h3 className="font-semibold mb-4">Weight trend</h3>
          {chartData.length < 2 ? (
            <p className="text-muted-foreground text-sm py-12 text-center">
              Add at least two measurements to see a trend.
            </p>
          ) : (
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(255,255,255,0.05)"
                  />
                  <XAxis
                    dataKey="date"
                    stroke="rgba(255,255,255,0.4)"
                    fontSize={11}
                  />
                  <YAxis
                    stroke="rgba(255,255,255,0.4)"
                    fontSize={11}
                    domain={["auto", "auto"]}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "rgba(15,30,32,0.95)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      borderRadius: "12px",
                      fontSize: "12px",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="weight"
                    stroke={MINT}
                    strokeWidth={3}
                    dot={{ r: 4, fill: MINT }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <h3 className="font-semibold mb-4">All measurements</h3>
          {(metrics ?? []).length === 0 ? (
            <p className="text-muted-foreground text-sm py-6 text-center">
              No measurements yet.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-muted-foreground uppercase tracking-wider">
                    <th className="pb-3 font-medium">Date</th>
                    <th className="pb-3 font-medium">Weight</th>
                    <th className="pb-3 font-medium">Fat %</th>
                    <th className="pb-3 font-medium">Waist</th>
                    <th className="pb-3 font-medium">Chest</th>
                    <th className="pb-3 font-medium">Hips</th>
                    <th className="pb-3 font-medium"></th>
                  </tr>
                </thead>
                <tbody>
                  {[...(metrics ?? [])]
                    .sort(
                      (a, b) =>
                        new Date(b.recordedAt).getTime() -
                        new Date(a.recordedAt).getTime()
                    )
                    .map((m) => (
                      <tr
                        key={m.id}
                        className="border-t border-border group"
                      >
                        <td className="py-3">{formatShortDate(m.recordedAt)}</td>
                        <td className="py-3 font-semibold">{m.weightKg} kg</td>
                        <td className="py-3">
                          {m.bodyFatPct != null ? `${m.bodyFatPct}%` : "—"}
                        </td>
                        <td className="py-3">
                          {m.waistCm != null ? `${m.waistCm} cm` : "—"}
                        </td>
                        <td className="py-3">
                          {m.chestCm != null ? `${m.chestCm} cm` : "—"}
                        </td>
                        <td className="py-3">
                          {m.hipsCm != null ? `${m.hipsCm} cm` : "—"}
                        </td>
                        <td className="py-3 text-right">
                          <button
                            onClick={() =>
                              del.mutate(
                                { id: m.id },
                                {
                                  onSuccess: () => {
                                    qc.invalidateQueries({
                                      queryKey: getListBodyMetricsQueryKey(),
                                    });
                                    qc.invalidateQueries({
                                      queryKey: getGetBodySummaryQueryKey(),
                                    });
                                  },
                                }
                              )
                            }
                            className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function StatCard({
  label,
  value,
  change,
  positive,
  color,
}: {
  label: string;
  value: string;
  change: string;
  positive: boolean;
  color: string;
}) {
  return (
    <div className="rounded-3xl bg-card border border-border p-6 flex items-center gap-4">
      <div
        className="w-12 h-12 rounded-2xl flex items-center justify-center"
        style={{ background: `${color}22`, color }}
      >
        <Activity className="w-6 h-6" />
      </div>
      <div className="flex-1">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          {label}
        </p>
        <p className="text-2xl font-bold tracking-tight">{value}</p>
        <p
          className={`text-xs mt-0.5 flex items-center gap-1 ${
            positive ? "text-primary" : "text-destructive"
          }`}
        >
          {positive ? (
            <TrendingDown className="w-3 h-3" />
          ) : (
            <TrendingUp className="w-3 h-3" />
          )}
          {change}
        </p>
      </div>
    </div>
  );
}
