import { useState, useMemo } from "react";
import { useParams, Link } from "wouter";
import { Layout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetBoard,
  useCreateBoardColumn,
  useDeleteBoardColumn,
  useCreateBoardCard,
  useUpdateBoardCard,
  useDeleteBoardCard,
  useAddBoardMember,
  useRemoveBoardMember,
  useListFriends,
  getGetBoardQueryKey,
  getListBoardsQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Trash2, ArrowLeft, Users, X } from "lucide-react";
import { useT } from "@/lib/i18n";

const PRIORITY_COLORS: Record<string, string> = {
  high: "#F291C8",
  medium: "#F2C879",
  low: "#7CF0BD",
};

export default function BoardDetail() {
  const t = useT();
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const queryClient = useQueryClient();
  const { data: board } = useGetBoard(id);
  const { data: friends } = useListFriends();

  const createColumn = useCreateBoardColumn();
  const removeColumn = useDeleteBoardColumn();
  const createCard = useCreateBoardCard();
  const updateCard = useUpdateBoardCard();
  const removeCard = useDeleteBoardCard();
  const addMember = useAddBoardMember();
  const removeMember = useRemoveBoardMember();

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getGetBoardQueryKey(id) });
    queryClient.invalidateQueries({ queryKey: getListBoardsQueryKey() });
  };

  const [newColName, setNewColName] = useState("");
  const [showColInput, setShowColInput] = useState(false);
  const [openColId, setOpenColId] = useState<number | null>(null);
  const [newCardTitle, setNewCardTitle] = useState("");
  const [draggedCardId, setDraggedCardId] = useState<number | null>(null);
  const [dragOverCol, setDragOverCol] = useState<number | null>(null);

  const [shareOpen, setShareOpen] = useState(false);

  const memberFriendIds = useMemo(
    () => new Set((board?.members ?? []).map((m) => m.friendId)),
    [board?.members],
  );
  const availableFriends = (friends ?? []).filter((f) => !memberFriendIds.has(f.id));

  if (!board) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64 text-muted-foreground">{t("common.loading")}</div>
      </Layout>
    );
  }

  const handleAddColumn = () => {
    if (!newColName) return;
    createColumn.mutate(
      { id, data: { name: newColName } },
      {
        onSuccess: () => {
          refetch();
          setNewColName("");
          setShowColInput(false);
        },
      },
    );
  };

  const handleAddCard = (columnId: number) => {
    if (!newCardTitle) return;
    createCard.mutate(
      { id, data: { columnId, title: newCardTitle } },
      {
        onSuccess: () => {
          refetch();
          setNewCardTitle("");
          setOpenColId(null);
        },
      },
    );
  };

  const handleDrop = (targetColId: number) => {
    if (draggedCardId === null) return;
    updateCard.mutate(
      { cardId: draggedCardId, data: { columnId: targetColId } },
      { onSuccess: refetch },
    );
    setDraggedCardId(null);
    setDragOverCol(null);
  };

  return (
    <Layout>
      <div className="flex items-center justify-between gap-4 mb-6 mt-2">
        <div className="flex items-center gap-3 min-w-0">
          <Link
            href="/boards"
            className="w-9 h-9 rounded-full bg-white/[0.04] hover:bg-white/[0.08] flex items-center justify-center shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div className="min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight truncate">{board.name}</h1>
            {board.description && (
              <p className="text-sm text-muted-foreground truncate">{board.description}</p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="flex -space-x-2">
            {board.members.slice(0, 4).map((m) => (
              <div
                key={m.id}
                className="w-8 h-8 rounded-full border-2 border-[#0d1a18] flex items-center justify-center text-xs font-bold"
                style={{ background: m.friendColor ?? "#7CF0BD", color: "#0a1f17" }}
                title={m.friendName}
              >
                {m.friendName.charAt(0).toUpperCase()}
              </div>
            ))}
          </div>
          <Dialog open={shareOpen} onOpenChange={setShareOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Users className="w-4 h-4 mr-2" /> {t("boards.share")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
              <DialogHeader>
                <DialogTitle>{t("boards.shareTitle")}</DialogTitle>
              </DialogHeader>
              <div className="space-y-2 mt-2 max-h-[400px] overflow-y-auto">
                <p className="text-xs text-muted-foreground mb-2">{t("boards.alreadyShared")}</p>
                {board.members.length === 0 && (
                  <p className="text-xs text-muted-foreground py-3 text-center">{t("boards.noMembers")}</p>
                )}
                {board.members.map((m) => (
                  <div
                    key={m.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-white/[0.03]"
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                        style={{ background: m.friendColor ?? "#7CF0BD", color: "#0a1f17" }}
                      >
                        {m.friendName.charAt(0).toUpperCase()}
                      </div>
                      <span className="text-sm">{m.friendName}</span>
                    </div>
                    <button
                      onClick={() => removeMember.mutate({ memberId: m.id }, { onSuccess: refetch })}
                      className="text-muted-foreground hover:text-destructive p-1"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}

                {availableFriends.length > 0 && (
                  <>
                    <p className="text-xs text-muted-foreground mt-4 mb-2">{t("boards.addFriend")}</p>
                    {availableFriends.map((f) => (
                      <button
                        key={f.id}
                        onClick={() =>
                          addMember.mutate(
                            { id, data: { friendId: f.id } },
                            { onSuccess: refetch },
                          )
                        }
                        className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-white/[0.05]"
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                            style={{ background: f.color ?? "#7CF0BD", color: "#0a1f17" }}
                          >
                            {f.name.charAt(0).toUpperCase()}
                          </div>
                          <span className="text-sm">{f.name}</span>
                        </div>
                        <Plus className="w-4 h-4 text-muted-foreground" />
                      </button>
                    ))}
                  </>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-6 -mx-1 px-1 no-scrollbar">
        {board.columns.map((col) => (
          <div
            key={col.id}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOverCol(col.id);
            }}
            onDragLeave={() => setDragOverCol(null)}
            onDrop={() => handleDrop(col.id)}
            className={`w-[300px] shrink-0 rounded-3xl bg-white/[0.02] border ${
              dragOverCol === col.id ? "border-primary/50 bg-primary/[0.04]" : "border-white/[0.05]"
            } p-4 transition-all`}
          >
            <div className="flex items-center justify-between mb-3 px-1">
              <div className="flex items-center gap-2">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ background: col.color ?? "#7CF0BD" }}
                />
                <p className="font-semibold text-sm tracking-tight">{col.name}</p>
                <span className="text-[10px] text-muted-foreground bg-white/[0.06] px-1.5 py-0.5 rounded">
                  {col.cards.length}
                </span>
              </div>
              <button
                onClick={() => {
                  if (col.cards.length === 0 || confirm(t("boards.deleteColumn"))) {
                    removeColumn.mutate({ columnId: col.id }, { onSuccess: refetch });
                  }
                }}
                className="text-muted-foreground hover:text-destructive p-1 opacity-50 hover:opacity-100"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2 max-h-[60vh] overflow-y-auto no-scrollbar">
              {col.cards.map((card) => (
                <div
                  key={card.id}
                  draggable
                  onDragStart={() => setDraggedCardId(card.id)}
                  onDragEnd={() => setDraggedCardId(null)}
                  className={`p-3 rounded-2xl bg-[#0d1a18] border border-white/[0.08] cursor-grab active:cursor-grabbing transition-all hover:border-white/[0.15] ${draggedCardId === card.id ? "opacity-40" : ""}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-medium leading-snug">{card.title}</p>
                    <button
                      onClick={() => removeCard.mutate({ cardId: card.id }, { onSuccess: refetch })}
                      className="text-muted-foreground hover:text-destructive p-0.5 opacity-0 group-hover:opacity-100"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                  {card.description && (
                    <p className="text-[11px] text-muted-foreground line-clamp-2 mb-2">
                      {card.description}
                    </p>
                  )}
                  <div className="flex items-center justify-between">
                    {card.priority && (
                      <span
                        className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold"
                        style={{
                          background: (PRIORITY_COLORS[card.priority] ?? "#fff") + "26",
                          color: PRIORITY_COLORS[card.priority] ?? "#fff",
                        }}
                      >
                        {card.priority}
                      </span>
                    )}
                    {card.assigneeName && (
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ml-auto"
                        style={{
                          background: card.assigneeColor ?? "#7CF0BD",
                          color: "#0a1f17",
                        }}
                        title={card.assigneeName}
                      >
                        {card.assigneeName.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {openColId === col.id ? (
              <div className="mt-2 space-y-2">
                <Textarea
                  placeholder={t("boards.cardTitlePlaceholder")}
                  value={newCardTitle}
                  onChange={(e) => setNewCardTitle(e.target.value)}
                  className="min-h-[60px] text-sm"
                  autoFocus
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => handleAddCard(col.id)} disabled={!newCardTitle}>
                    {t("boards.addCard")}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setOpenColId(null);
                      setNewCardTitle("");
                    }}
                  >
                    {t("common.cancel")}
                  </Button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setOpenColId(col.id)}
                className="w-full mt-2 py-2 text-xs text-muted-foreground hover:text-foreground hover:bg-white/[0.04] rounded-xl flex items-center justify-center gap-1"
              >
                <Plus className="w-3 h-3" /> {t("boards.addCard")}
              </button>
            )}
          </div>
        ))}

        <div className="w-[280px] shrink-0">
          {showColInput ? (
            <div className="rounded-3xl bg-white/[0.04] border border-white/[0.08] p-3 space-y-2">
              <Input
                placeholder={t("boards.columnName")}
                value={newColName}
                onChange={(e) => setNewColName(e.target.value)}
                autoFocus
              />
              <div className="flex gap-2">
                <Button size="sm" onClick={handleAddColumn} disabled={!newColName}>
                  {t("common.add")}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowColInput(false);
                    setNewColName("");
                  }}
                >
                  {t("common.cancel")}
                </Button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowColInput(true)}
              className="w-full py-3 rounded-3xl border border-dashed border-white/[0.1] text-sm text-muted-foreground hover:text-foreground hover:bg-white/[0.04] hover:border-white/[0.2] transition-all flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" /> {t("boards.addColumn")}
            </button>
          )}
        </div>
      </div>
    </Layout>
  );
}
