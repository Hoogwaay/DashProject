import { useState } from "react";
import { Layout } from "@/components/layout";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListBoards,
  useCreateBoard,
  useDeleteBoard,
  getListBoardsQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Trash2, KanbanSquare, Users, ChevronRight } from "lucide-react";
import { useT } from "@/lib/i18n";

const COLORS = ["#7CF0BD", "#A89BF5", "#F2C879", "#5EC9F2", "#F291C8"];

export default function Boards() {
  const t = useT();
  const queryClient = useQueryClient();
  const { data: boards } = useListBoards();
  const create = useCreateBoard();
  const remove = useDeleteBoard();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const refetch = () =>
    queryClient.invalidateQueries({ queryKey: getListBoardsQueryKey() });

  const handleCreate = () => {
    if (!name) return;
    create.mutate(
      {
        data: {
          name,
          description: description || null,
          color: COLORS[(boards?.length ?? 0) % COLORS.length],
        },
      },
      {
        onSuccess: () => {
          refetch();
          setOpen(false);
          setName("");
          setDescription("");
        },
      },
    );
  };

  return (
    <Layout>
      <div className="flex items-end justify-between mb-6 mt-2">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">{t("boards.title")}</h1>
          <p className="text-sm text-muted-foreground mt-2">
            {t("boards.subtitle")}
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="lg">
              <Plus className="w-4 h-4 mr-2" /> {t("boards.new")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[440px] bg-[#0d1a18] border-white/10">
            <DialogHeader>
              <DialogTitle>{t("boards.create")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder={t("boards.namePlaceholder")} value={name} onChange={(e) => setName(e.target.value)} />
              <Textarea placeholder={t("boards.descriptionPlaceholder")} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate}>{t("common.create")}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {(boards ?? []).map((b) => (
          <Link
            key={b.id}
            href={`/boards/${b.id}`}
            className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 transition-all hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5 group"
          >
            <div className="flex items-start justify-between mb-3">
              <div
                className="w-11 h-11 rounded-2xl flex items-center justify-center"
                style={{ background: (b.color ?? "#7CF0BD") + "26", color: b.color ?? "#7CF0BD" }}
              >
                <KanbanSquare className="w-5 h-5" />
              </div>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  if (confirm(`${t("common.delete")} "${b.name}"?`)) {
                    remove.mutate({ id: b.id }, { onSuccess: refetch });
                  }
                }}
                className="text-muted-foreground hover:text-destructive p-1 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <p className="font-semibold tracking-tight">{b.name}</p>
            {b.description && (
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{b.description}</p>
            )}
            <div className="mt-4 flex items-center justify-between text-[11px] text-muted-foreground">
              <span>{b.cardCount} {t("boards.cards")}</span>
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3" /> {b.memberCount}
              </span>
            </div>
          </Link>
        ))}
        {(boards ?? []).length === 0 && (
          <div className="col-span-full text-center py-12 text-muted-foreground text-sm">
            {t("boards.empty")}
          </div>
        )}
      </div>
    </Layout>
  );
}
