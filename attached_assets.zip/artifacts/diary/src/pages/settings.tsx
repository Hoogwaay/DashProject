import { useState } from "react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User, DollarSign, Save } from "lucide-react";
import { getDisplayName, getCurrency } from "@/lib/utils";

export default function Settings() {
  const [displayName, setDisplayName] = useState(getDisplayName());
  const [currency, setCurrency] = useState(getCurrency());
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    localStorage.setItem("diary.displayName", displayName.trim() || "Stefan");
    localStorage.setItem("diary.currency", currency || "USD");
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      window.location.reload();
    }, 800);
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground mt-1">
            Personalize your diary experience.
          </p>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6 space-y-6">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold">Display name</h3>
                <p className="text-xs text-muted-foreground">
                  How we greet you in the header.
                </p>
              </div>
            </div>
            <Input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Your name"
            />
          </div>

          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold">Currency</h3>
                <p className="text-xs text-muted-foreground">
                  Used for formatting amounts.
                </p>
              </div>
            </div>
            <select
              className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
            >
              <option value="USD">USD — US Dollar</option>
              <option value="EUR">EUR — Euro</option>
              <option value="RUB">RUB — Russian Ruble</option>
              <option value="GBP">GBP — British Pound</option>
              <option value="JPY">JPY — Japanese Yen</option>
            </select>
          </div>

          <div className="flex justify-end">
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              {saved ? "Saved!" : "Save changes"}
            </Button>
          </div>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <h3 className="font-semibold mb-2">About</h3>
          <p className="text-sm text-muted-foreground">
            Personal Diary — your single home for finance, notes, investments,
            calendar and body metrics. All data lives in your private database.
          </p>
        </div>
      </div>
    </Layout>
  );
}
