import { useState } from "react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User, DollarSign, Save, Languages } from "lucide-react";
import { getDisplayName, getCurrency } from "@/lib/utils";
import { useI18n, type Lang } from "@/lib/i18n";

export default function Settings() {
  const { t, lang, setLang } = useI18n();
  const [displayName, setDisplayName] = useState(getDisplayName());
  const [currency, setCurrency] = useState(getCurrency());
  const [language, setLanguage] = useState<Lang>(lang);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    localStorage.setItem("diary.displayName", displayName.trim() || "Stefan");
    localStorage.setItem("diary.currency", currency || "USD");
    setLang(language);
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      window.location.reload();
    }, 800);
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("settings.title")}</h1>
          <p className="text-muted-foreground mt-1">
            {t("settings.subtitle")}
          </p>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6 space-y-6">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold">{t("settings.displayName")}</h3>
                <p className="text-xs text-muted-foreground">
                  {t("settings.displayNameHint")}
                </p>
              </div>
            </div>
            <Input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder={t("settings.namePlaceholder")}
            />
          </div>

          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                <Languages className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold">{t("settings.language")}</h3>
                <p className="text-xs text-muted-foreground">
                  {t("settings.languageHint")}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setLanguage("en")}
                className={`h-12 rounded-xl border text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                  language === "en"
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background border-border text-foreground hover:bg-card"
                }`}
              >
                <span className="text-lg">EN</span>
                <span>{t("settings.langEn")}</span>
              </button>
              <button
                type="button"
                onClick={() => setLanguage("ru")}
                className={`h-12 rounded-xl border text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                  language === "ru"
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background border-border text-foreground hover:bg-card"
                }`}
              >
                <span className="text-lg">RU</span>
                <span>{t("settings.langRu")}</span>
              </button>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold">{t("settings.currency")}</h3>
                <p className="text-xs text-muted-foreground">
                  {t("settings.currencyHint")}
                </p>
              </div>
            </div>
            <select
              className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
            >
              <option value="USD">USD — US Dollar</option>
              <option value="EUR">EUR — Euro</option>
              <option value="RUB">RUB — Russian Ruble</option>
              <option value="GBP">GBP — British Pound</option>
              <option value="JPY">JPY — Japanese Yen</option>
            </select>
          </div>

          <div className="flex justify-end">
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              {saved ? t("common.saved") : t("settings.saveChanges")}
            </Button>
          </div>
        </div>

        <div className="rounded-3xl bg-card border border-border p-6">
          <h3 className="font-semibold mb-2">{t("settings.about")}</h3>
          <p className="text-sm text-muted-foreground">
            {t("settings.aboutBody")}
          </p>
        </div>
      </div>
    </Layout>
  );
}
