import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Dashboard from "@/pages/dashboard";
import Transactions from "@/pages/transactions";
import Notes from "@/pages/notes";
import Investments from "@/pages/investments";
import Accounts from "@/pages/accounts";
import Forecast from "@/pages/forecast";
import Calendar from "@/pages/calendar";
import Body from "@/pages/body";
import Settings from "@/pages/settings";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/notes" component={Notes} />
      <Route path="/investments" component={Investments} />
      <Route path="/accounts" component={Accounts} />
      <Route path="/forecast" component={Forecast} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/body" component={Body} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;