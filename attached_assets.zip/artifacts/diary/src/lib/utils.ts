import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { getStoredLang, localeFor } from "./i18n"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number, currency: string = getCurrency()) {
  return new Intl.NumberFormat(localeFor(getStoredLang()), {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }).format(amount)
}

export function formatDate(dateStr: string) {
  if (!dateStr) return '';
  return new Intl.DateTimeFormat(localeFor(getStoredLang()), {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(new Date(dateStr))
}

export function formatShortDate(dateStr: string) {
  if (!dateStr) return '';
  return new Intl.DateTimeFormat(localeFor(getStoredLang()), {
    month: 'short',
    day: 'numeric'
  }).format(new Date(dateStr))
}

export function getDisplayName() {
  return localStorage.getItem('diary.displayName') || 'Stefan';
}

export function getCurrency() {
  return localStorage.getItem('diary.currency') || 'USD';
}
