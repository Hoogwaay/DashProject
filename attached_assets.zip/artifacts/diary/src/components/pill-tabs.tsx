import { motion, LayoutGroup } from "framer-motion";
import { useId, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export type PillTabItem<T extends string> = {
  key: T;
  label: ReactNode;
  icon?: ReactNode;
};

type Variant = "default" | "primary";

type PillTabsProps<T extends string> = {
  items: PillTabItem<T>[];
  value: T;
  onChange: (value: T) => void;
  variant?: Variant;
  className?: string;
  size?: "sm" | "md";
};

export function PillTabs<T extends string>({
  items,
  value,
  onChange,
  variant = "default",
  className,
  size = "md",
}: PillTabsProps<T>) {
  const groupId = useId();

  const padding = size === "sm" ? "px-3.5 py-1.5 text-[13px]" : "px-4 py-2 text-sm";

  return (
    <LayoutGroup id={groupId}>
      <div
        className={cn(
          "flex flex-wrap items-center gap-1.5 p-1 rounded-full bg-white/[0.04] border border-white/[0.06] backdrop-blur-md w-fit",
          className,
        )}
      >
        {items.map((item) => {
          const isActive = value === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onChange(item.key)}
              className={cn(
                "relative rounded-full font-medium transition-colors flex items-center gap-2 outline-none",
                padding,
                isActive
                  ? variant === "primary"
                    ? "text-[#0a1f17]"
                    : "text-[#0a1f17]"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {isActive && (
                <motion.span
                  layoutId={`pill-tabs-bg-${groupId}`}
                  className={cn(
                    "absolute inset-0 rounded-full -z-0",
                    variant === "primary"
                      ? "bg-primary shadow-[0_0_24px_rgba(124,240,189,0.35)]"
                      : "bg-white shadow-[0_8px_24px_-8px_rgba(255,255,255,0.35)]",
                  )}
                  transition={{ type: "spring", stiffness: 420, damping: 36, mass: 0.7 }}
                />
              )}
              <span className="relative z-10 flex items-center gap-2 whitespace-nowrap">
                {item.icon}
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </LayoutGroup>
  );
}
