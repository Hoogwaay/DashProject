import { motion, AnimatePresence } from "framer-motion";
import { type ReactNode } from "react";

type PageTransitionProps = {
  routeKey: string;
  children: ReactNode;
};

export function PageTransition({ routeKey, children }: PageTransitionProps) {
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={routeKey}
        initial={{ opacity: 0, y: 12, filter: "blur(6px)" }}
        animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
        exit={{ opacity: 0, y: -8, filter: "blur(4px)" }}
        transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
        className="h-full"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

type TabTransitionProps = {
  tabKey: string;
  children: ReactNode;
  direction?: "horizontal" | "vertical";
};

export function TabTransition({
  tabKey,
  children,
  direction = "horizontal",
}: TabTransitionProps) {
  const offset = direction === "horizontal" ? { x: 16 } : { y: 12 };
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={tabKey}
        initial={{ opacity: 0, ...offset }}
        animate={{ opacity: 1, x: 0, y: 0 }}
        exit={{ opacity: 0, ...offset }}
        transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
