# Workspace

## Overview

Personal Diary — a finance + life tracking web app built as a pnpm monorepo with shared types between an Express API server and a React + Vite frontend. Visual style: dark teal/forest theme, glassmorphism cards, mint green (#7CF0BD) and lavender-violet (#A89BF5) accents, large rounded cards.

## Artifacts

- `artifacts/diary` — React + Vite + Tailwind v4 + shadcn/ui frontend (slug: `diary`, previewPath: `/`).
- `artifacts/api-server` — Express 5 API serving all diary endpoints under `/api`.
- `artifacts/mockup-sandbox` — Reserved for canvas-based UI prototyping.

## Stack

- pnpm monorepo, TypeScript project references.
- Frontend: React 18, Vite, Tailwind v4, shadcn/ui, wouter, TanStack Query, framer-motion, recharts, lucide-react.
- Backend: Express 5, Drizzle ORM, PostgreSQL (Replit-managed).
- Shared: OpenAPI spec at `lib/api-spec/openapi.yaml` is the source of truth. Orval generates `@workspace/api-client-react` (typed React Query hooks) and `@workspace/api-zod` (Zod schemas).

## Database (Drizzle)

PostgreSQL via `DATABASE_URL`. Schema in `lib/db/src/schema/`:

- `transactions` — income/expense, category, merchant, occurredAt
- `notes` — title, content, pinned
- `investments` — name, ticker, kind (stock/etf/crypto/bond), quantity, buy/current price
- `accounts` — name, kind (checking/savings/credit/cash/crypto), balance, cardLast4
- `forecast_entries` — source, amount, recurrence, expectedDate
- `events` — calendar items: title, kind (task/workout/measurement/note), scheduledAt, durationMin, done, color
- `body_metrics` — recordedAt, weightKg, bodyFatPct, musclePct, waistCm, chestCm, hipsCm

Run `pnpm --filter @workspace/db run push` to sync schema. Numeric columns return strings from drizzle — routes coerce with `Number()`.

## API Routes

- `/api/dashboard/{summary,revenue-flow,spending-by-category,spending-trend}`
- `/api/transactions` (GET/POST/DELETE)
- `/api/notes` (GET/POST/PATCH/DELETE)
- `/api/investments` (+ `/summary`)
- `/api/accounts`
- `/api/forecast` (+ `/summary`)
- `/api/events` (+ `/upcoming`) — note: `from`/`to` query params are parsed as raw ISO strings to bypass Zod's `zod.date()` issue
- `/api/body/{metrics,summary}`

## Frontend Pages

- `/` Dashboard — Revenue Flow hatched bar chart with active mint pill, Available pie, Income/Expense cards, stacked Total Balance hero (3 credit cards), Recent Transactions, Spending sparkline, Upcoming events.
- `/transactions`, `/notes`, `/investments`, `/accounts`, `/forecast`, `/calendar`, `/body`, `/settings`

## Conventions

- All hooks come from `@workspace/api-client-react`. After mutations, invalidate via the corresponding `getXxxQueryKey()`.
- Display name + currency stored in `localStorage` (`diary.displayName`, `diary.currency`).
- Dark-only theme: both `:root` and `.dark` set to dark palette; `<html class="dark">` set in index.html.
- No emojis in UI.
- Mobile: left vertical nav collapses into bottom tab bar; cards stack vertically.

## Seed Data

Demo data lives at `/tmp/seed.sql` for developer convenience.
