import { pgTable, serial, text, timestamp, numeric, integer } from "drizzle-orm/pg-core";

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  category: text("category").notNull(),
  description: text("description"),
  merchant: text("merchant"),
  accountId: integer("account_id"),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type TransactionRow = typeof transactionsTable.$inferSelect;
export type InsertTransactionRow = typeof transactionsTable.$inferInsert;
