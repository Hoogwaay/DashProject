import { pgTable, serial, text, numeric, date } from "drizzle-orm/pg-core";

export const investmentsTable = pgTable("investments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ticker: text("ticker"),
  kind: text("kind").notNull(),
  quantity: numeric("quantity", { precision: 20, scale: 8 }).notNull(),
  buyPrice: numeric("buy_price", { precision: 18, scale: 4 }).notNull(),
  currentPrice: numeric("current_price", { precision: 18, scale: 4 }).notNull(),
  purchasedAt: date("purchased_at").notNull().defaultNow(),
});

export type InvestmentRow = typeof investmentsTable.$inferSelect;
export type InsertInvestmentRow = typeof investmentsTable.$inferInsert;
