import { pgTable, serial, text, numeric, date } from "drizzle-orm/pg-core";

export const bodyMetricsTable = pgTable("body_metrics", {
  id: serial("id").primaryKey(),
  recordedAt: date("recorded_at").notNull().defaultNow(),
  weightKg: numeric("weight_kg", { precision: 6, scale: 2 }),
  bodyFatPct: numeric("body_fat_pct", { precision: 5, scale: 2 }),
  musclePct: numeric("muscle_pct", { precision: 5, scale: 2 }),
  waistCm: numeric("waist_cm", { precision: 6, scale: 2 }),
  chestCm: numeric("chest_cm", { precision: 6, scale: 2 }),
  hipsCm: numeric("hips_cm", { precision: 6, scale: 2 }),
  notes: text("notes"),
});

export type BodyMetricRow = typeof bodyMetricsTable.$inferSelect;
export type InsertBodyMetricRow = typeof bodyMetricsTable.$inferInsert;
