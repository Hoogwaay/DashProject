import { pgTable, serial, text, numeric, date } from "drizzle-orm/pg-core";

export const forecastTable = pgTable("forecast_entries", {
  id: serial("id").primaryKey(),
  source: text("source").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  expectedDate: date("expected_date").notNull(),
  recurrence: text("recurrence").notNull().default("once"),
  notes: text("notes"),
});

export type ForecastRow = typeof forecastTable.$inferSelect;
export type InsertForecastRow = typeof forecastTable.$inferInsert;
