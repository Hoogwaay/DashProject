import { pgTable, serial, text, integer, numeric, timestamp, boolean } from "drizzle-orm/pg-core";

export const challengesTable = pgTable("challenges", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull().default("habit"),
  icon: text("icon"),
  color: text("color"),
  unit: text("unit").notNull().default("times"),
  targetValue: numeric("target_value", { precision: 14, scale: 2 }).notNull(),
  currentValue: numeric("current_value", { precision: 14, scale: 2 }).notNull().default("0"),
  startDate: timestamp("start_date", { withTimezone: true }).notNull().defaultNow(),
  endDate: timestamp("end_date", { withTimezone: true }).notNull(),
  status: text("status").notNull().default("active"),
  pinned: boolean("pinned").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const challengeProgressTable = pgTable("challenge_progress", {
  id: serial("id").primaryKey(),
  challengeId: integer("challenge_id").notNull(),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
  delta: numeric("delta", { precision: 14, scale: 2 }).notNull(),
  note: text("note"),
});

export type ChallengeRow = typeof challengesTable.$inferSelect;
export type InsertChallengeRow = typeof challengesTable.$inferInsert;
export type ChallengeProgressRow = typeof challengeProgressTable.$inferSelect;
export type InsertChallengeProgressRow = typeof challengeProgressTable.$inferInsert;
