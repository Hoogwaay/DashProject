import { pgTable, serial, text, numeric, timestamp } from "drizzle-orm/pg-core";

export const accountsTable = pgTable("accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull(),
  balance: numeric("balance", { precision: 14, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("USD"),
  cardLast4: text("card_last4"),
  color: text("color"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AccountRow = typeof accountsTable.$inferSelect;
export type InsertAccountRow = typeof accountsTable.$inferInsert;
