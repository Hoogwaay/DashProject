import { useLayoutEffect, useRef, useState } from "react";

/**
 * Auto-fits its children inside the available space by uniformly scaling them
 * down. Never scales above 1.0. Uses CSS transform; offsetHeight/offsetWidth
 * stay unaffected by the transform so we can re-measure without resetting it.
 */
export function FitToViewport({ children }: { children: React.ReactNode }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useLayoutEffect(() => {
    let raf = 0;

    const compute = () => {
      const wrap = wrapRef.current;
      const inner = innerRef.current;
      if (!wrap || !inner) return;
      const wrapH = wrap.clientHeight;
      const wrapW = wrap.clientWidth;
      if (!wrapW || !wrapH) return;
      // offsetHeight/Width return the layout (untransformed) size.
      const naturalH = inner.offsetHeight;
      const naturalW = inner.offsetWidth;
      if (!naturalH || !naturalW) return;
      const s = Math.min(1, wrapH / naturalH, wrapW / naturalW);
      setScale((prev) => (Math.abs(prev - s) < 0.005 ? prev : s));
    };

    const schedule = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(compute);
    };

    schedule();

    const ro = new ResizeObserver(schedule);
    if (wrapRef.current) ro.observe(wrapRef.current);
    if (innerRef.current) ro.observe(innerRef.current);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return (
    <div ref={wrapRef} className="w-full h-full overflow-hidden">
      <div
        ref={innerRef}
        style={{
          transform: `scale(${scale})`,
          transformOrigin: "top left",
          width: "100%",
        }}
      >
        {children}
      </div>
    </div>
  );
}
