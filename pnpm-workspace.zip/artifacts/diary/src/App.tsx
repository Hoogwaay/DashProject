import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Dashboard from "@/pages/dashboard";
import Notes from "@/pages/notes";
import Forecast from "@/pages/forecast";
import Calendar from "@/pages/calendar";
import Settings from "@/pages/settings";
import Budget from "@/pages/budget";
import Workouts from "@/pages/workouts";
import Friends from "@/pages/friends";
import Boards from "@/pages/boards";
import BoardDetail from "@/pages/board-detail";
import Knowledge from "@/pages/knowledge";
import { Redirect } from "wouter";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/notes" component={Notes} />
      <Route path="/forecast" component={Forecast} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/budget" component={Budget} />
      <Route path="/workouts" component={Workouts} />
      <Route path="/friends" component={Friends} />
      <Route path="/boards" component={Boards} />
      <Route path="/boards/:id" component={BoardDetail} />
      <Route path="/knowledge" component={Knowledge} />
      <Route path="/settings" component={Settings} />
      {/* Legacy routes — redirect to consolidated tabs */}
      <Route path="/transactions">{() => <Redirect to="/budget" />}</Route>
      <Route path="/accounts">{() => <Redirect to="/budget" />}</Route>
      <Route path="/investments">{() => <Redirect to="/budget" />}</Route>
      <Route path="/body">{() => <Redirect to="/workouts" />}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
