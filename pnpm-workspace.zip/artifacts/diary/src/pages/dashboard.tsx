import { useEffect, useMemo, useRef, useState } from "react";
import { Layout } from "@/components/layout";
import { FitToViewport } from "@/components/fit-to-viewport";
import { Link } from "wouter";
import {
  useGetDashboardSummary,
  useGetRevenueFlow,
  useGetRevenueFlowYear,
  useGetRevenueFlowMonth,
  useGetSpendingByCategory,
  useGetSpendingTrend,
  useListTransactions,
  useListAccounts,
} from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import {
  ArrowDownRight,
  ArrowUpRight,
  TrendingUp,
  TrendingDown,
  ChevronRight,
  ChevronLeft,
  Plus,
  X,
  BarChart3,
  LineChart as LineIcon,
  Calendar,
  AlertCircle,
  Users,
} from "lucide-react";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const MINT = "#7CF0BD";
const LAVENDER = "#A89BF5";

export default function Dashboard() {
  const { data: summary } = useGetDashboardSummary();
  const { data: revenueFlow } = useGetRevenueFlow({ months: 6 });
  const { data: breakdown } = useGetSpendingByCategory();
  const { data: trend } = useGetSpendingTrend();
  const { data: txs } = useListTransactions({ limit: 5 });
  const { data: accounts } = useListAccounts();

  const recentTxs = useMemo(() => (txs ?? []).slice(0, 3), [txs]);
  const heroAccounts = useMemo(
    () => (accounts ?? []).slice(0, 3),
    [accounts]
  );

  return (
    <Layout>
      <FitToViewport>
      <div className="flex flex-col gap-3 mb-4 mt-1">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
          My Dashboard
        </h1>
        <FilterPills />
      </div>

      <div className="grid grid-cols-12 gap-4">
        <section className="col-span-12 xl:col-span-8 flex flex-col gap-6">
          <RevenueFlowCard initialData={revenueFlow ?? []} />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <AvailableCard
              total={summary?.totalBalance ?? 0}
              breakdown={breakdown ?? []}
            />
            <div className="flex flex-col gap-6">
              <MoneyCard
                kind="income"
                amount={summary?.monthIncome ?? 0}
                changePct={summary?.incomeChangePct ?? 0}
              />
              <MoneyCard
                kind="expense"
                amount={summary?.monthExpense ?? 0}
                changePct={summary?.expenseChangePct ?? 0}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <MandatoryDueCard
              remaining={summary?.mandatoryDueRemaining ?? 0}
              total={summary?.mandatoryDueTotal ?? 0}
              nextDate={summary?.mandatoryNextDate ?? null}
            />
            <DebtCard
              debtTotal={summary?.debtTotal ?? 0}
              creditTotal={summary?.creditTotal ?? 0}
            />
          </div>
        </section>

        <section className="col-span-12 xl:col-span-4 flex flex-col gap-6">
          <MyCardStack accounts={heroAccounts} transactions={recentTxs} />
          <div className="grid grid-cols-2 gap-4">
            <FriendsTeaser />
            <SpendingTrendCard data={trend ?? []} />
          </div>
        </section>
      </div>
      </FitToViewport>
    </Layout>
  );
}

function FilterPills() {
  const FILTERS = ["All", "Withdrawal", "Savings", "Deposit"];
  const [active, setActive] = useState("All");
  return (
    <div className="flex flex-wrap items-center gap-2.5">
      {FILTERS.map((f) => {
        const isActive = active === f;
        return (
          <button
            key={f}
            onClick={() => setActive(f)}
            className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
              isActive
                ? "text-[#0a1f17] shadow-[0_0_20px_rgba(124,240,189,0.25)]"
                : "text-muted-foreground hover:text-foreground bg-white/[0.04] border border-white/[0.06] hover:bg-white/[0.06]"
            }`}
            style={isActive ? { background: MINT } : undefined}
          >
            {f}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Revenue Flow ---------- */

function RevenueFlowCard({
  initialData,
}: {
  initialData: { month: string; income: number; expense: number; net: number }[];
}) {
  const [chartType, setChartType] = useState<"bar" | "line">("bar");
  const [view, setView] = useState<"recent" | "year">("recent");
  const [yearOffset, setYearOffset] = useState(0);
  const [monthDrillDown, setMonthDrillDown] = useState<
    { year: number; month: number; label: string } | null
  >(null);

  const currentYear = new Date().getFullYear() + yearOffset;
  const { data: yearData } = useGetRevenueFlowYear(
    { year: currentYear },
    { query: { enabled: view === "year" } as any },
  );

  const data = view === "year" ? yearData ?? [] : initialData;
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const lastIdx = data.length - 1;
  const activeIdx = hoveredIdx ?? lastIdx;
  const max = Math.max(1, ...data.map((d) => Math.max(d.income, d.expense)));
  const active = data[activeIdx];

  const handleBarClick = (idx: number) => {
    if (view !== "year") return;
    setMonthDrillDown({
      year: currentYear,
      month: idx + 1,
      label: `${data[idx].month} ${currentYear}`,
    });
  };

  return (
    <div
      className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6 md:p-7 relative overflow-hidden backdrop-blur-sm transition-all duration-300 hover:bg-white/[0.05] hover:border-white/[0.1]"
      onMouseLeave={() => setHoveredIdx(null)}
    >
      <svg width="0" height="0" className="absolute">
        <defs>
          <pattern
            id="hatch-lavender"
            patternUnits="userSpaceOnUse"
            width="7"
            height="7"
            patternTransform="rotate(45)"
          >
            <rect width="7" height="7" fill="rgba(168,155,245,0.06)" />
            <line x1="0" y1="0" x2="0" y2="7" stroke="rgba(168,155,245,0.45)" strokeWidth="2" />
          </pattern>
        </defs>
      </svg>

      <div className="flex flex-wrap items-start justify-between mb-6 gap-3">
        <div>
          <h3 className="text-xl md:text-2xl font-bold tracking-tight">Revenue Flow</h3>
          {view === "year" && (
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => setYearOffset((y) => y - 1)}
                className="w-7 h-7 rounded-full bg-white/[0.04] hover:bg-white/[0.08] flex items-center justify-center"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-sm font-semibold tabular-nums w-12 text-center">
                {currentYear}
              </span>
              <button
                onClick={() => setYearOffset((y) => y + 1)}
                className="w-7 h-7 rounded-full bg-white/[0.04] hover:bg-white/[0.08] flex items-center justify-center"
                disabled={yearOffset >= 0}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <span className="text-[10px] text-muted-foreground ml-2">Click any bar for daily breakdown</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-white/[0.04] rounded-full p-1 border border-white/[0.06]">
            <button
              onClick={() => setChartType("bar")}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                chartType === "bar" ? "bg-white text-[#0a1f17]" : "text-muted-foreground hover:text-foreground"
              }`}
              title="Bar chart"
            >
              <BarChart3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setChartType("line")}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                chartType === "line" ? "bg-white text-[#0a1f17]" : "text-muted-foreground hover:text-foreground"
              }`}
              title="Line chart"
            >
              <LineIcon className="w-4 h-4" />
            </button>
          </div>
          <button
            onClick={() => {
              setView(view === "year" ? "recent" : "year");
              setYearOffset(0);
            }}
            className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 px-3 py-2 rounded-full bg-white/[0.04] hover:bg-white/[0.08]"
          >
            {view === "year" ? "Recent" : "View All"} <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {chartType === "bar" ? (
        <div className="flex items-end gap-2 md:gap-3 h-[240px] px-1">
          <div className="flex flex-col justify-between h-full text-[10px] text-muted-foreground/70 pr-2 py-1">
            <span>{`${(max / 1000).toFixed(1)}k$`}</span>
            <span>{`${((max * 0.75) / 1000).toFixed(1)}k$`}</span>
            <span>{`${((max * 0.5) / 1000).toFixed(1)}k$`}</span>
            <span>{`${((max * 0.25) / 1000).toFixed(1)}k$`}</span>
            <span>0$</span>
          </div>

          {data.map((d, i) => {
            const isActive = i === activeIdx;
            const h = (d.income / max) * 100;
            return (
              <button
                key={`${d.month}-${i}`}
                onMouseEnter={() => setHoveredIdx(i)}
                onClick={() => handleBarClick(i)}
                className={`group flex-1 flex flex-col items-center gap-3 h-full justify-end ${view === "year" ? "cursor-pointer" : "cursor-default"}`}
              >
                <div className="relative w-full flex justify-center items-end h-full">
                  <div
                    className="absolute left-1/2 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shadow-lg z-10 pointer-events-none"
                    style={{
                      background: MINT,
                      color: "#0a1f17",
                      bottom: `calc(${Math.max(8, h)}% + 12px)`,
                      opacity: isActive ? 1 : 0,
                      transform: isActive
                        ? "translateX(-50%) translateY(0) scale(1)"
                        : "translateX(-50%) translateY(6px) scale(0.92)",
                      transition:
                        "opacity 350ms cubic-bezier(0.4,0,0.2,1), transform 350ms cubic-bezier(0.4,0,0.2,1), bottom 400ms cubic-bezier(0.4,0,0.2,1)",
                    }}
                  >
                    +{formatCurrency(d.income)}
                    <div
                      className="absolute left-1/2 -translate-x-1/2 -bottom-1 w-2.5 h-2.5 rotate-45"
                      style={{ background: MINT }}
                    />
                  </div>
                  <svg
                    className="w-full max-w-[40px]"
                    style={{
                      height: `${Math.max(8, h)}%`,
                      transition: "height 400ms cubic-bezier(0.4,0,0.2,1)",
                    }}
                    preserveAspectRatio="none"
                    viewBox="0 0 50 100"
                  >
                    <rect
                      x="0"
                      y="0"
                      width="50"
                      height="100"
                      rx="22"
                      ry="14"
                      fill={isActive ? LAVENDER : "url(#hatch-lavender)"}
                      stroke={isActive ? "transparent" : "rgba(168,155,245,0.35)"}
                      strokeWidth="0.6"
                      style={{
                        transition:
                          "fill 350ms cubic-bezier(0.4,0,0.2,1), stroke 350ms cubic-bezier(0.4,0,0.2,1)",
                      }}
                    />
                  </svg>
                </div>
                <span
                  className={`text-[11px] font-medium transition-all ${
                    isActive
                      ? "text-foreground"
                      : "text-muted-foreground group-hover:text-foreground"
                  }`}
                >
                  {d.month}
                </span>
              </button>
            );
          })}
        </div>
      ) : (
        <div className="h-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              onClick={(e: any) => {
                if (view === "year" && e?.activeTooltipIndex !== undefined) {
                  handleBarClick(e.activeTooltipIndex);
                }
              }}
            >
              <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false} width={40} />
              <Tooltip
                contentStyle={{
                  background: "#0d1a18",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "12px",
                  fontSize: "12px",
                }}
                formatter={(value: number) => `$${value.toFixed(0)}`}
              />
              <Line
                type="monotone"
                dataKey="income"
                stroke={MINT}
                strokeWidth={2.5}
                dot={{ fill: MINT, r: 4 }}
                activeDot={{ r: 6 }}
                name="Income"
              />
              <Line
                type="monotone"
                dataKey="expense"
                stroke={LAVENDER}
                strokeWidth={2.5}
                dot={{ fill: LAVENDER, r: 4 }}
                activeDot={{ r: 6 }}
                name="Expense"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <DailyDrillDownDialog
        open={!!monthDrillDown}
        onClose={() => setMonthDrillDown(null)}
        year={monthDrillDown?.year ?? 0}
        month={monthDrillDown?.month ?? 0}
        label={monthDrillDown?.label ?? ""}
      />
    </div>
  );
}

function DailyDrillDownDialog({
  open,
  onClose,
  year,
  month,
  label,
}: {
  open: boolean;
  onClose: () => void;
  year: number;
  month: number;
  label: string;
}) {
  const { data } = useGetRevenueFlowMonth(
    { year, month },
    { query: { enabled: open && year > 0 && month > 0 } as any },
  );
  const days = data ?? [];
  const totalIncome = days.reduce((s, d) => s + d.income, 0);
  const totalExpense = days.reduce((s, d) => s + d.expense, 0);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[640px] bg-[#0d1a18] border-white/10">
        <DialogHeader>
          <DialogTitle>{label}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div className="rounded-2xl bg-white/[0.03] border border-white/[0.06] p-4">
            <p className="text-[11px] text-muted-foreground">Income</p>
            <p className="text-xl font-bold tabular-nums text-primary">
              {formatCurrency(totalIncome)}
            </p>
          </div>
          <div className="rounded-2xl bg-white/[0.03] border border-white/[0.06] p-4">
            <p className="text-[11px] text-muted-foreground">Expense</p>
            <p className="text-xl font-bold tabular-nums">
              {formatCurrency(totalExpense)}
            </p>
          </div>
        </div>
        <div className="h-[260px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={days}>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false} width={40} />
              <Tooltip
                contentStyle={{
                  background: "#0d1a18",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "12px",
                  fontSize: "12px",
                }}
                formatter={(value: number) => `$${value.toFixed(0)}`}
                labelFormatter={(label: any) => `Day ${label}`}
              />
              <Bar dataKey="income" fill={MINT} radius={[6, 6, 0, 0]} name="Income" />
              <Bar dataKey="expense" fill={LAVENDER} radius={[6, 6, 0, 0]} name="Expense" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ---------- Available pie ---------- */

function AvailableCard({
  total,
  breakdown,
}: {
  total: number;
  breakdown: { category: string; amount: number; color?: string | null }[];
}) {
  const fallbackColors = [LAVENDER, "#F2C879", MINT, "#5EC9F2", "#F291C8"];
  const totalAmt = breakdown.reduce((s, b) => s + b.amount, 0) || 1;
  let acc = 0;
  const segs = (breakdown.length > 0
    ? breakdown
    : [{ category: "—", amount: 1, color: MINT }]
  ).map((b, i) => {
    const pct = (b.amount / totalAmt) * 100;
    const start = acc;
    acc += pct;
    return {
      category: b.category,
      amount: b.amount,
      pct,
      start,
      end: acc,
      color: b.color ?? fallbackColors[i % fallbackColors.length],
    };
  });

  return (
    <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-6 backdrop-blur-sm transition-all duration-300 hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold tracking-tight text-lg">Available</h3>
        <Link
          href="/budget"
          className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
        >
          View All <ChevronRight className="w-3 h-3" />
        </Link>
      </div>
      <div className="flex items-center gap-5">
        <div
          className="relative w-32 h-32 rounded-full shrink-0"
          style={{
            background: `conic-gradient(${segs.map((s) => `${s.color} ${s.start}% ${s.end}%`).join(", ")})`,
          }}
        >
          <div className="absolute inset-3 rounded-full bg-[#0d1a18] flex flex-col items-center justify-center">
            <p className="text-[10px] text-muted-foreground">Balance</p>
            <p className="text-base font-bold tabular-nums">
              {formatCompact(total)}
            </p>
          </div>
        </div>
        <div className="flex-1 min-w-0 space-y-2">
          {segs.slice(0, 4).map((s) => (
            <div key={s.category} className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ background: s.color }}
                />
                <span className="text-xs text-muted-foreground truncate">
                  {s.category}
                </span>
              </div>
              <span className="text-xs font-semibold tabular-nums shrink-0">
                {s.pct.toFixed(0)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- Money cards ---------- */

function MoneyCard({
  kind,
  amount,
  changePct,
}: {
  kind: "income" | "expense";
  amount: number;
  changePct: number;
}) {
  const isIncome = kind === "income";
  const positive = changePct >= 0;
  return (
    <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 backdrop-blur-sm flex items-center gap-4 transition-all duration-300 hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5">
      <div
        className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0"
        style={{
          background: isIncome ? "rgba(124,240,189,0.12)" : "rgba(168,155,245,0.12)",
        }}
      >
        {isIncome ? (
          <ArrowUpRight className="w-5 h-5" style={{ color: MINT }} />
        ) : (
          <ArrowDownRight className="w-5 h-5" style={{ color: LAVENDER }} />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="text-xs text-muted-foreground">
            {isIncome ? "Income" : "Expense"}
          </p>
          <span
            className={`text-[10px] font-semibold flex items-center gap-0.5 ${
              positive ? "text-primary" : "text-destructive"
            }`}
          >
            {positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(changePct)}%
          </span>
        </div>
        <p className="text-2xl font-bold tracking-tight tabular-nums">
          {formatCurrency(amount)}
        </p>
        <p className="text-[10px] text-muted-foreground mt-0.5">
          This month
        </p>
      </div>
    </div>
  );
}

/* ---------- New: Mandatory + Debt widgets ---------- */

function MandatoryDueCard({
  remaining,
  total,
  nextDate,
}: {
  remaining: number;
  total: number;
  nextDate: string | null;
}) {
  const paid = Math.max(0, total - remaining);
  const pct = total > 0 ? Math.min(100, (paid / total) * 100) : 0;
  return (
    <Link
      href="/budget"
      className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 backdrop-blur-sm flex flex-col gap-3 transition-all duration-300 hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="w-9 h-9 rounded-2xl flex items-center justify-center"
            style={{ background: "rgba(242,200,121,0.14)" }}
          >
            <AlertCircle className="w-4 h-4" style={{ color: "#F2C879" }} />
          </div>
          <p className="text-sm font-semibold tracking-tight">
            Mandatory due
          </p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground" />
      </div>
      <div>
        <p className="text-3xl font-bold tabular-nums">
          {formatCurrency(remaining)}
        </p>
        <p className="text-[11px] text-muted-foreground mt-0.5">
          remaining this month
          {nextDate && (
            <>
              {" • next "}
              <span className="text-foreground">
                {new Date(nextDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
              </span>
            </>
          )}
        </p>
      </div>
      <div className="h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: MINT }}
        />
      </div>
      <p className="text-[10px] text-muted-foreground tabular-nums">
        {formatCurrency(paid)} paid of {formatCurrency(total)}
      </p>
    </Link>
  );
}

function DebtCard({
  debtTotal,
  creditTotal,
}: {
  debtTotal: number;
  creditTotal: number;
}) {
  const net = creditTotal - debtTotal;
  return (
    <Link
      href="/budget"
      className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 backdrop-blur-sm flex flex-col gap-3 transition-all duration-300 hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="w-9 h-9 rounded-2xl flex items-center justify-center"
            style={{ background: "rgba(242,145,200,0.14)" }}
          >
            <ArrowDownRight className="w-4 h-4" style={{ color: "#F291C8" }} />
          </div>
          <p className="text-sm font-semibold tracking-tight">Debts</p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground" />
      </div>
      <div>
        <p className="text-3xl font-bold tabular-nums" style={{ color: debtTotal > 0 ? "#F291C8" : undefined }}>
          {formatCurrency(debtTotal)}
        </p>
        <p className="text-[11px] text-muted-foreground mt-0.5">
          you owe in total
        </p>
      </div>
      <div className="flex items-center justify-between text-[11px] pt-1">
        <span className="text-muted-foreground">
          You're owed: <span className="text-foreground font-medium tabular-nums">{formatCurrency(creditTotal)}</span>
        </span>
        <span className={`font-semibold tabular-nums ${net >= 0 ? "text-primary" : "text-destructive"}`}>
          {net >= 0 ? "+" : ""}{formatCurrency(net)}
        </span>
      </div>
    </Link>
  );
}

/* ---------- My Card (with bottom-anchored transactions) ---------- */

const CARD_PALETTE = [
  { from: "#7CF0BD", to: "#3DB78A", text: "#0a1f17" },
  { from: "#A89BF5", to: "#6E5DD9", text: "#ffffff" },
  { from: "#5EC9F2", to: "#2A8FB8", text: "#ffffff" },
];

function MyCardStack({
  accounts,
  transactions,
}: {
  accounts: any[];
  transactions: any[];
}) {
  const [activeIdx, setActiveIdx] = useState(0);
  const [showTx, setShowTx] = useState(false);
  const [hoverStack, setHoverStack] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const frontCardRef = useRef<HTMLButtonElement | null>(null);
  const [popTop, setPopTop] = useState(248);

  useEffect(() => {
    if (!showTx) return;
    const onClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowTx(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setShowTx(false);
    };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [showTx]);

  const safeAccounts = accounts.length > 0 ? accounts : [];
  const visible = useMemo(() => {
    if (safeAccounts.length === 0) return [];
    const idx = activeIdx % safeAccounts.length;
    return [safeAccounts[idx], ...safeAccounts.filter((_, i) => i !== idx)].slice(0, 3);
  }, [safeAccounts, activeIdx]);

  const COLLAPSED_OFFSET = 16;
  const SPREAD_OFFSET = 56;
  const stackOffset = hoverStack ? SPREAD_OFFSET : COLLAPSED_OFFSET;
  const stackHeight = 180 + Math.max(0, visible.length - 1) * stackOffset + 12;

  useEffect(() => {
    const measure = () => {
      if (!frontCardRef.current || !containerRef.current) return;
      const card = frontCardRef.current.getBoundingClientRect();
      const wrapper = containerRef.current.getBoundingClientRect();
      setPopTop(card.bottom - wrapper.top);
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [safeAccounts.length, activeIdx, hoverStack]);

  // Z-index plan to fix popover ordering:
  //   panel chrome (background)        z-1
  //   back cards                       z-10, z-12 (i=2,1 reversed for clarity)
  //   transactions popover             z-20  (BEHIND front card, IN FRONT OF back cards/panel)
  //   front card                       z-30
  //   panel header                     z-40

  return (
    <div ref={containerRef} className="relative">
      {/* Panel chrome — purely visual background. No pointer events, no overflow clipping. */}
      <div className="absolute inset-0 rounded-3xl bg-white/[0.03] border border-white/[0.06] backdrop-blur-sm transition-all duration-300 z-[1] pointer-events-none" />

      <div className="relative p-6">
        <div className="relative z-40 flex items-center justify-between mb-4">
          <h3 className="font-semibold tracking-tight text-lg">My Card</h3>
          <span className="text-xs text-muted-foreground hidden sm:inline">
            Hover to spread • Click to view
          </span>
        </div>

        <div
          className="relative"
          style={{
            height: `${stackHeight}px`,
            transition: "height 600ms cubic-bezier(0.22, 1, 0.36, 1)",
          }}
          onMouseEnter={() => setHoverStack(true)}
          onMouseLeave={() => setHoverStack(false)}
        >
          {visible.map((acc, i) => {
            const palette = CARD_PALETTE[safeAccounts.indexOf(acc) % CARD_PALETTE.length];
            const isFront = i === 0;
            const top = i * stackOffset;
            const scale = 1 - i * 0.04;
            // Front card gets z-30, back cards z-12, z-10 — so popover (z-20) sits between.
            const cardZ = isFront ? 30 : 12 - i;
            return (
              <button
                key={acc.id ?? i}
                ref={isFront ? frontCardRef : undefined}
                onClick={() => {
                  if (isFront) {
                    setShowTx((v) => !v);
                  } else {
                    setShowTx(false);
                    setActiveIdx(safeAccounts.indexOf(acc));
                  }
                }}
                className={`absolute left-0 right-0 rounded-3xl p-5 text-left cursor-pointer will-change-transform ${
                  isFront
                    ? "shadow-[0_20px_50px_-15px_rgba(0,0,0,0.6)] hover:shadow-[0_25px_60px_-10px_rgba(124,240,189,0.45)]"
                    : "shadow-xl hover:brightness-110"
                }`}
                style={{
                  top: `${top}px`,
                  height: "180px",
                  background: `linear-gradient(135deg, ${palette.from} 0%, ${palette.to} 100%)`,
                  color: palette.text,
                  zIndex: cardZ,
                  transform: `scale(${scale})`,
                  transformOrigin: "top center",
                  transition:
                    "top 700ms cubic-bezier(0.22, 1, 0.36, 1), transform 700ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 500ms ease, filter 400ms ease",
                }}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[11px] opacity-80 font-medium uppercase tracking-wider">
                      {acc.name ?? "Account"}
                    </p>
                    <p
                      className={`font-bold tracking-tight mt-1 tabular-nums ${
                        isFront ? "text-3xl" : "text-xl"
                      }`}
                    >
                      {formatCurrency(acc.balance ?? 0)}
                    </p>
                  </div>
                  {isFront && (
                    <span
                      className="w-9 h-9 rounded-full bg-white flex items-center justify-center shadow-lg shrink-0 transition-transform duration-300 hover:scale-110 hover:rotate-90"
                      aria-hidden
                    >
                      <Plus className="w-5 h-5 text-[#0a1f17]" />
                    </span>
                  )}
                </div>
                <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
                  <div>
                    <p className="font-mono text-sm tracking-[0.2em] opacity-95">
                      {isFront
                        ? `4358 4445 0968 ${acc.cardLast4 ?? "0000"}`
                        : `•••• •••• •••• ${acc.cardLast4 ?? "0000"}`}
                    </p>
                    {isFront && (
                      <p className="font-mono text-[11px] tracking-[0.15em] opacity-80 mt-1">
                        08/24
                      </p>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Transactions popover — z-20 sits ABOVE back cards (z-10/12) but BELOW front card (z-30).
          So it slides out from behind the active card only, not from behind the whole panel. */}
      <div
        className="absolute left-6 right-6 z-20 overflow-hidden"
        style={{
          top: `${popTop - 36}px`,
          maxHeight: showTx ? "560px" : "0px",
          opacity: showTx ? 1 : 0,
          pointerEvents: showTx ? "auto" : "none",
          transition: "max-height 600ms cubic-bezier(0.22, 1, 0.36, 1), opacity 350ms ease",
        }}
        aria-hidden={!showTx}
      >
        <div
          className="mt-1 rounded-2xl border border-white/10 shadow-2xl p-5 pt-9"
          style={{
            background: "rgba(13, 26, 24, 0.97)",
            backdropFilter: "blur(16px)",
            WebkitBackdropFilter: "blur(16px)",
            boxShadow:
              "0 25px 60px -15px rgba(0,0,0,0.7), 0 0 0 1px rgba(124,240,189,0.08)",
            transform: showTx ? "translateY(0)" : "translateY(-12px)",
            transition: "transform 600ms cubic-bezier(0.22, 1, 0.36, 1)",
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <div>
              <h4 className="text-sm font-semibold tracking-tight">Recent Transactions</h4>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                {visible[0]?.name ?? ""}
              </p>
            </div>
            <button
              onClick={() => setShowTx(false)}
              className="w-7 h-7 rounded-full hover:bg-white/10 flex items-center justify-center transition-all duration-200 hover:rotate-90"
              aria-label="Close"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
          <div className="space-y-1">
            {transactions.length === 0 && (
              <p className="text-xs text-muted-foreground py-3 text-center">
                No transactions yet
              </p>
            )}
            {transactions.map((tx) => {
              const brand = brandFor(tx.merchant);
              return (
                <div
                  key={tx.id}
                  className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-white/[0.05] transition-all duration-200 hover:translate-x-1"
                >
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-sm font-bold transition-transform duration-200 hover:scale-110 hover:rotate-6"
                    style={{ background: brand?.bg, color: brand?.fg }}
                  >
                    {brand?.letter}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {tx.merchant ?? tx.description ?? tx.category}
                    </p>
                  </div>
                  <div
                    className={`text-sm font-semibold tabular-nums ${
                      tx.type === "income" ? "text-primary" : "text-foreground"
                    }`}
                  >
                    {tx.type === "income" ? "+" : "-"}
                    {formatCurrency(tx.amount)}
                  </div>
                </div>
              );
            })}
          </div>
          <Link
            href="/budget"
            className="mt-2 flex items-center justify-center gap-1 text-xs text-muted-foreground hover:text-foreground py-2 rounded-lg hover:bg-white/[0.04] transition-colors"
          >
            View all <ChevronRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    </div>
  );
}

const BRAND_STYLE: Record<string, { bg: string; fg: string; letter?: string }> = {
  Figma: { bg: "#F24E1E22", fg: "#F24E1E", letter: "F" },
  Grammarly: { bg: "#15C39A22", fg: "#15C39A", letter: "G" },
  Blender: { bg: "#F5792A22", fg: "#F5792A", letter: "B" },
};

function brandFor(merchant?: string | null) {
  if (!merchant) return null;
  const exact = BRAND_STYLE[merchant];
  if (exact) return exact;
  return {
    bg: "rgba(168,155,245,0.14)",
    fg: LAVENDER,
    letter: merchant.charAt(0).toUpperCase(),
  };
}

/* ---------- Friends teaser ---------- */

function FriendsTeaser() {
  const FRIEND_GRADIENTS = [
    "linear-gradient(135deg,#7CF0BD,#3DB78A)",
    "linear-gradient(135deg,#A89BF5,#6E5DD9)",
    "linear-gradient(135deg,#F2C879,#E69833)",
  ];
  return (
    <Link
      href="/friends"
      className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 backdrop-blur-sm flex flex-col gap-3 transition-all duration-300 hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5 group"
    >
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold tracking-tight">Friends</p>
        <Users className="w-4 h-4 text-muted-foreground" />
      </div>
      <p className="text-[11px] text-muted-foreground leading-snug">
        Share boards, split tabs, plan together
      </p>
      <div className="flex -space-x-2.5 mt-auto">
        {FRIEND_GRADIENTS.map((g, i) => (
          <div
            key={i}
            className="w-8 h-8 rounded-full border-2 border-[#0d1a18] shrink-0"
            style={{ background: g }}
          />
        ))}
        <span
          className="w-8 h-8 rounded-full bg-white/10 border-2 border-[#0d1a18] flex items-center justify-center text-foreground"
          aria-label="Open friends"
        >
          <Plus className="w-3.5 h-3.5" />
        </span>
      </div>
    </Link>
  );
}

function SpendingTrendCard({
  data,
}: {
  data: { date: string; amount: number }[];
}) {
  return (
    <div className="rounded-3xl bg-white/[0.03] border border-white/[0.06] p-5 backdrop-blur-sm flex flex-col gap-2 overflow-hidden transition-all duration-300 hover:bg-white/[0.05] hover:border-white/[0.1] hover:-translate-y-0.5">
      <p className="text-sm font-semibold tracking-tight">Spending</p>
      <div className="flex-1 -mx-2 -mb-2 min-h-[80px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={MINT} stopOpacity={0.5} />
                <stop offset="100%" stopColor={MINT} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="amount"
              stroke={MINT}
              strokeWidth={2.5}
              fill="url(#sparkFill)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function formatCompact(n: number) {
  if (n >= 1000) return `$${(n / 1000).toFixed(1)}k`;
  return `$${n.toFixed(0)}`;
}
