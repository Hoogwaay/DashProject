-- Demo data for Diary
-- Wipes existing demo rows and reseeds with realistic content.

BEGIN;

TRUNCATE TABLE
  knowledge_links,
  knowledge_notes,
  workout_exercises,
  workout_sessions,
  work_shifts,
  board_cards,
  board_columns,
  board_members,
  boards,
  friends,
  body_metrics,
  forecast_entries,
  calendar_events,
  debt_payments,
  debts,
  mandatory_payments,
  mandatory_expenses,
  notes,
  investments,
  transactions,
  accounts
RESTART IDENTITY CASCADE;

-- ===== Accounts (3 cards: green / lavender / blue, matching CARD_PALETTE) =====
INSERT INTO accounts (name, kind, balance, currency, card_last4, color) VALUES
  ('Main Checking',  'checking', 4820.50, 'USD', '4521', '#7CF0BD'),
  ('Savings Vault',  'savings',  12750.00,'USD', '8830', '#A89BF5'),
  ('Travel Card',    'credit',   1240.75, 'USD', '3318', '#5EC9F2');

-- ===== Transactions (spread across last 6 months) =====
INSERT INTO transactions (type, amount, category, description, merchant, account_id, occurred_at) VALUES
  -- This month
  ('income',  3200.00, 'Salary',        'Monthly salary',     'Acme Corp',  1, NOW() - INTERVAL '2 days'),
  ('expense',   89.40, 'Groceries',     'Weekly groceries',   'Whole Foods',1, NOW() - INTERVAL '1 day'),
  ('expense',   12.99, 'Subscriptions', 'Music streaming',    'Spotify',    1, NOW() - INTERVAL '3 days'),
  ('expense',   45.00, 'Transport',     'Ride share',         'Uber',       1, NOW() - INTERVAL '4 days'),
  ('expense',  120.00, 'Clothes',       'New jacket',         'Zara',       1, NOW() - INTERVAL '6 days'),
  ('expense',   34.50, 'Food',          'Lunch out',          'Sweetgreen', 1, NOW() - INTERVAL '7 days'),
  ('income',   450.00, 'Freelance',     'Side gig',           'Figma',      2, NOW() - INTERVAL '8 days'),
  ('expense',   24.00, 'Subscriptions', 'Design tool',        'Figma',      1, NOW() - INTERVAL '9 days'),
  ('expense',   15.99, 'Subscriptions', 'Writing assistant',  'Grammarly',  1, NOW() - INTERVAL '11 days'),
  ('expense',   72.30, 'Groceries',     'Weekly groceries',   'Trader Joe', 1, NOW() - INTERVAL '12 days'),
  ('expense',   18.75, 'Food',          'Coffee + pastry',    'Blue Bottle',1, NOW() - INTERVAL '14 days'),
  ('expense',  220.00, 'Travel',        'Train tickets',      'Amtrak',     3, NOW() - INTERVAL '15 days'),
  -- Last month
  ('income',  3200.00, 'Salary',        'Monthly salary',     'Acme Corp',  1, NOW() - INTERVAL '32 days'),
  ('expense',  950.00, 'Bills',         'Rent',               'Landlord',   1, NOW() - INTERVAL '33 days'),
  ('expense',  140.00, 'Groceries',     'Weekly groceries',   'Whole Foods',1, NOW() - INTERVAL '36 days'),
  ('expense',   58.00, 'Entertainment', 'Cinema night',       'AMC',        1, NOW() - INTERVAL '40 days'),
  ('expense',  310.00, 'Health',        'Dentist',            'SmileCare',  1, NOW() - INTERVAL '45 days'),
  ('income',   650.00, 'Freelance',     'Logo project',       'Acme Corp',  2, NOW() - INTERVAL '50 days'),
  -- 2-3 months ago
  ('income',  3200.00, 'Salary',        'Monthly salary',     'Acme Corp',  1, NOW() - INTERVAL '62 days'),
  ('expense',  950.00, 'Bills',         'Rent',               'Landlord',   1, NOW() - INTERVAL '63 days'),
  ('expense',  340.00, 'Shopping',      'New monitor',        'Amazon',     1, NOW() - INTERVAL '70 days'),
  ('expense',  180.00, 'Travel',        'Hotel stay',         'Booking',    3, NOW() - INTERVAL '78 days'),
  ('income',  3200.00, 'Salary',        'Monthly salary',     'Acme Corp',  1, NOW() - INTERVAL '92 days'),
  ('expense',  950.00, 'Bills',         'Rent',               'Landlord',   1, NOW() - INTERVAL '93 days'),
  ('expense',  410.00, 'Travel',        'Flight',             'Delta',      3, NOW() - INTERVAL '100 days'),
  -- 4-6 months ago
  ('income',  3200.00, 'Salary',        'Monthly salary',     'Acme Corp',  1, NOW() - INTERVAL '122 days'),
  ('expense',  950.00, 'Bills',         'Rent',               'Landlord',   1, NOW() - INTERVAL '123 days'),
  ('income',  1100.00, 'Freelance',     '3D render',          'Blender',    2, NOW() - INTERVAL '130 days'),
  ('expense',  260.00, 'Shopping',      'Headphones',         'Apple',      1, NOW() - INTERVAL '140 days'),
  ('income',  3200.00, 'Salary',        'Monthly salary',     'Acme Corp',  1, NOW() - INTERVAL '152 days'),
  ('expense',  950.00, 'Bills',         'Rent',               'Landlord',   1, NOW() - INTERVAL '153 days'),
  ('income',  3200.00, 'Salary',        'Monthly salary',     'Acme Corp',  1, NOW() - INTERVAL '182 days'),
  ('expense',  950.00, 'Bills',         'Rent',               'Landlord',   1, NOW() - INTERVAL '183 days');

-- ===== Mandatory expenses + payments this month =====
INSERT INTO mandatory_expenses (name, amount, due_day, category, color, icon, currency, active, notes) VALUES
  ('Rent',          950.00, 5,  'Bills',         '#A89BF5', 'home',       'USD', true, 'Apartment rent'),
  ('Internet',       55.00, 10, 'Bills',         '#5EC9F2', 'wifi',       'USD', true, 'Fiber 1 Gbps'),
  ('Gym membership', 49.00, 12, 'Health',        '#7CF0BD', 'dumbbell',   'USD', true, 'Includes pool'),
  ('Phone plan',     35.00, 18, 'Bills',         '#F2C879', 'phone',      'USD', true, NULL),
  ('Cloud storage',  9.99,  22, 'Subscriptions', '#F291C8', 'cloud',      'USD', true, NULL);

-- A couple have already been paid this month
INSERT INTO mandatory_payments (expense_id, paid_at, amount, notes) VALUES
  (1, date_trunc('month', NOW()) + INTERVAL '4 days',  950.00, 'Bank transfer'),
  (2, date_trunc('month', NOW()) + INTERVAL '9 days',   55.00, 'Auto-pay');

-- ===== Debts & credits (with partial payments) =====
INSERT INTO debts (name, kind, original_amount, paid_amount, currency, lender, due_date, apr_pct, color, notes) VALUES
  ('Car loan',         'credit', 12000.00, 4200.00, 'USD', 'Bank ABC',     CURRENT_DATE + INTERVAL '720 days', 6.50, '#A89BF5', '36 months'),
  ('Laptop financing', 'credit',  1800.00,  900.00, 'USD', 'Best Buy',     CURRENT_DATE + INTERVAL '180 days', 0.00, '#7CF0BD', '0% intro'),
  ('Loan to brother',  'debt',     500.00,  150.00, 'USD', 'Brother',      CURRENT_DATE + INTERVAL '60 days',  0.00, '#F2C879', NULL);

INSERT INTO debt_payments (debt_id, paid_at, amount, notes) VALUES
  (1, NOW() - INTERVAL '20 days', 350.00, 'Monthly payment'),
  (1, NOW() - INTERVAL '50 days', 350.00, 'Monthly payment'),
  (2, NOW() - INTERVAL '15 days', 150.00, 'Monthly payment'),
  (3, NOW() - INTERVAL '30 days', 150.00, 'Partial repayment');

-- ===== Calendar events =====
INSERT INTO calendar_events (title, kind, scheduled_at, duration_min, done, color, notes) VALUES
  ('Team standup',           'task',        NOW() + INTERVAL '1 day'   + INTERVAL '9 hours', 30, false, '#A89BF5', 'Daily sync'),
  ('Morning workout',        'workout',     NOW() + INTERVAL '2 days'  + INTERVAL '7 hours', 60, false, '#7CF0BD', 'Push day'),
  ('Body measurement',       'measurement', NOW() + INTERVAL '3 days'  + INTERVAL '8 hours', 15, false, '#5EC9F2', 'Monthly check'),
  ('Project deadline',       'task',        NOW() + INTERVAL '5 days'  + INTERVAL '17 hours', 0, false, '#F291C8', 'Ship MVP'),
  ('Dinner with friends',    'other',       NOW() + INTERVAL '7 days'  + INTERVAL '19 hours', 120, false, '#F2C879', 'Italian place'),
  ('Pay rent',               'task',        date_trunc('month', NOW() + INTERVAL '1 month') + INTERVAL '4 days', 0, false, '#A89BF5', 'Mandatory: Rent'),
  ('Pay internet',           'task',        date_trunc('month', NOW() + INTERVAL '1 month') + INTERVAL '9 days', 0, false, '#5EC9F2', 'Mandatory: Internet'),
  ('Evening run',            'workout',     NOW() - INTERVAL '1 day'   + INTERVAL '18 hours', 45, true,  '#7CF0BD', '5km easy');

-- ===== Work shifts (synced via event_id) =====
INSERT INTO work_shifts (started_at, ended_at, hourly_rate, hours, earned, notes) VALUES
  (NOW() - INTERVAL '2 days' + INTERVAL '9 hours',  NOW() - INTERVAL '2 days' + INTERVAL '17 hours', 35.00, 8.00,  280.00, 'Office day'),
  (NOW() - INTERVAL '3 days' + INTERVAL '9 hours',  NOW() - INTERVAL '3 days' + INTERVAL '17 hours', 35.00, 8.00,  280.00, 'Remote'),
  (NOW() - INTERVAL '4 days' + INTERVAL '9 hours',  NOW() - INTERVAL '4 days' + INTERVAL '15 hours', 35.00, 6.00,  210.00, 'Half day');

-- ===== Friends =====
INSERT INTO friends (name, role, email, status, color, notes) VALUES
  ('Anna Petrova',  'colleague', 'anna@acme.com',     'active', '#7CF0BD', 'Designer, sits next desk'),
  ('Mark Lee',      'friend',    'mark@example.com',  'active', '#A89BF5', 'College buddy'),
  ('Olga Ivanova',  'colleague', 'olga@acme.com',     'active', '#F2C879', 'PM on side project'),
  ('Daniel Cohen',  'friend',    'daniel@example.com','active', '#5EC9F2', 'Gym partner');

-- ===== Boards (helpdesk) =====
INSERT INTO boards (name, description, color, owner_label) VALUES
  ('Personal tasks',    'My weekly to-dos and chores',   '#7CF0BD', 'me'),
  ('Side project: Diary','Shared with Anna and Mark',    '#A89BF5', 'me');

INSERT INTO board_columns (board_id, name, position, color) VALUES
  (1, 'Backlog',     0, '#9CA3AF'),
  (1, 'In progress', 1, '#A89BF5'),
  (1, 'Done',        2, '#7CF0BD'),
  (2, 'Ideas',       0, '#5EC9F2'),
  (2, 'Doing',       1, '#A89BF5'),
  (2, 'Shipped',     2, '#7CF0BD');

INSERT INTO board_cards (column_id, title, description, position, priority, due_date) VALUES
  (1, 'Renew passport',           'Book embassy slot',          0, 'high',   NOW() + INTERVAL '14 days'),
  (1, 'Replace bike tire',        NULL,                         1, 'medium', NOW() + INTERVAL '7 days'),
  (2, 'Plan summer trip',         'Pick destination, dates',    0, 'medium', NOW() + INTERVAL '30 days'),
  (3, 'Sort old photos',          NULL,                         0, 'low',    NULL),
  (4, 'Add knowledge graph view', 'Obsidian-style network',     0, 'high',   NULL),
  (4, 'Calendar drag-and-drop',   NULL,                         1, 'medium', NULL),
  (5, 'Polish dashboard cards',   'New mandatory + debt block', 0, 'high',   NOW() + INTERVAL '5 days'),
  (6, 'Initial release',          'v0.1 to friends',            0, 'high',   NULL);

INSERT INTO board_members (board_id, friend_id) VALUES
  (2, 1),
  (2, 2);

-- ===== Workouts =====
INSERT INTO workout_sessions (event_id, scheduled_at, name, notes, duration_min) VALUES
  (NULL, NOW() - INTERVAL '7 days',  'Push day',  'Chest + triceps', 60),
  (NULL, NOW() - INTERVAL '4 days',  'Pull day',  'Back + biceps',   55),
  (NULL, NOW() - INTERVAL '1 day',   'Leg day',   'Quads + glutes',  70);

INSERT INTO workout_exercises (session_id, name, sets, reps, weight_kg, position) VALUES
  (1, 'Bench press',     4, 8,  60.00, 0),
  (1, 'Incline dumbbell',3, 10, 22.00, 1),
  (1, 'Tricep pushdown', 3, 12, 30.00, 2),
  (2, 'Pull-ups',        4, 8,  NULL,  0),
  (2, 'Barbell row',     4, 8,  55.00, 1),
  (2, 'Bicep curl',      3, 12, 14.00, 2),
  (3, 'Squat',           5, 5,  90.00, 0),
  (3, 'Romanian deadlift',4, 8, 75.00, 1),
  (3, 'Leg press',       3, 12,140.00, 2);

-- ===== Body metrics =====
INSERT INTO body_metrics (recorded_at, weight_kg, body_fat_pct, muscle_pct, waist_cm, chest_cm, hips_cm, notes) VALUES
  (CURRENT_DATE - INTERVAL '90 days', 78.5, 18.5, 41.0, 84.0, 102.0, 95.0, 'Starting line'),
  (CURRENT_DATE - INTERVAL '60 days', 77.8, 17.8, 41.5, 83.0, 102.5, 95.0, NULL),
  (CURRENT_DATE - INTERVAL '30 days', 77.0, 17.0, 42.0, 82.0, 103.0, 94.5, NULL),
  (CURRENT_DATE,                       76.4, 16.5, 42.5, 81.5, 103.0, 94.0, 'Feeling good');

-- ===== Investments =====
INSERT INTO investments (name, ticker, kind, quantity, buy_price, current_price, purchased_at) VALUES
  ('Apple Inc.',          'AAPL', 'stock',   10.0,    150.00, 195.00, CURRENT_DATE - INTERVAL '300 days'),
  ('Vanguard S&P 500',    'VOO',  'etf',      5.0,    400.00, 460.00, CURRENT_DATE - INTERVAL '200 days'),
  ('Bitcoin',             'BTC',  'crypto',   0.05, 28000.00,65000.00,CURRENT_DATE - INTERVAL '150 days'),
  ('US Treasury 10Y',     'UST10','bond',    20.0,     98.00, 101.00, CURRENT_DATE - INTERVAL '100 days');

-- ===== Notes =====
INSERT INTO notes (title, content, color, pinned) VALUES
  ('Welcome', 'Use this diary to track money, workouts, ideas and tasks.', '#7CF0BD', true),
  ('Shopping list', 'milk, eggs, oats, bananas, chicken, broccoli', '#A89BF5', false);

-- ===== Knowledge base (Obsidian-style) =====
INSERT INTO knowledge_notes (title, content, color, tags, x, y) VALUES
  ('Personal finance',     'Track spending, build emergency fund, invest the rest.', '#7CF0BD', 'finance,money', 100, 100),
  ('Compound interest',    'Money grows on money. Start early.',                    '#A89BF5', 'finance',       300, 60),
  ('Index funds',          'Diversified, low fees, long-term winners.',            '#A89BF5', 'finance',       300, 180),
  ('Workout plan',         'Push / Pull / Legs split, 3-4 days per week.',         '#5EC9F2', 'fitness',       100, 320),
  ('Progressive overload', 'Add small weight/reps each week.',                     '#5EC9F2', 'fitness',       300, 320),
  ('Reading list',         'Atomic Habits, Deep Work, Psychology of Money.',       '#F2C879', 'books',         100, 500);

INSERT INTO knowledge_links (from_note_id, to_note_id, label) VALUES
  (1, 2, 'depends on'),
  (1, 3, 'invest via'),
  (2, 3, 'example'),
  (4, 5, 'principle'),
  (1, 6, 'see also');

-- ===== Forecast =====
INSERT INTO forecast_entries (source, amount, expected_date, recurrence, notes) VALUES
  ('Salary',          3200.00, CURRENT_DATE + INTERVAL '20 days', 'monthly', 'Acme paycheck'),
  ('Freelance gig',    600.00, CURRENT_DATE + INTERVAL '10 days', 'once',    'Logo project'),
  ('Tax refund',       420.00, CURRENT_DATE + INTERVAL '45 days', 'once',    NULL);

COMMIT;
